import type { ReactNode } from 'react';

/**
 * PageLayout (U6) — SATU kerangka halaman untuk semua daftar/form:
 * kepala (judul + subjudul satu baris + aksi) → toolbar (satu baris,
 * flex-wrap) → isi (tabel lebar penuh, menggulir di dalam) → kaki paginasi
 * (satu baris di kanan bawah, menempel pada kartu).
 *
 * Jarak & lebar seragam di seluruh aplikasi karena semua halaman melewati
 * komponen ini (spasi mengikuti token `--gap-kartu` / `--padding-kartu`).
 */
export function PageLayout({
  judul,
  deskripsi,
  aksi,
  alat,
  isi,
  paginasi,
  kelas,
}: {
  /** Judul halaman (h3). */
  judul: ReactNode;
  /** Subjudul/keterangan — satu baris, elipsis bila panjang. */
  deskripsi?: ReactNode;
  /** Tombol aksi di kanan kepala (ikon + Tambah). */
  aksi?: ReactNode;
  /** Toolbar: pencarian, filter, ringkasan. Satu baris dengan wrap. */
  alat?: ReactNode;
  /** Isi halaman: tabel, grid kartu, formulir. */
  isi: ReactNode;
  /** Kaki: paginasi (ringkasan + kontrol) — satu baris di kanan bawah. */
  paginasi?: ReactNode;
  kelas?: string;
}) {
  return (
    <div className={`halaman ${kelas ?? ''}`.trim()}>
      <section className="kartu">
        {(judul || aksi) && (
          <div className="kartu__kepala">
            <div>
              <h3>{judul}</h3>
              {deskripsi && <p className="teks-redup teks-kecil">{deskripsi}</p>}
            </div>
            {aksi && <div className="tombol-baris">{aksi}</div>}
          </div>
        )}
        {alat && <div className="alat-tabel">{alat}</div>}
        {isi}
        {paginasi && <div className="paginasi">{paginasi}</div>}
      </section>
    </div>
  );
}
