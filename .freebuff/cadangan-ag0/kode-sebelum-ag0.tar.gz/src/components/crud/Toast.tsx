import { useEffect, useState } from 'react';

type Jenis = 'sukses' | 'galat' | 'info';

interface Toast {
  id: number;
  pesan: string;
  jenis: Jenis;
}

let daftar: Toast[] = [];
let dengar: ((t: Toast[]) => void) | null = null;
let berikutnya = 1;

function ubah(fn: (t: Toast[]) => Toast[]): void {
  daftar = fn(daftar);
  dengar?.(daftar);
}

/** Tampilkan notifikasi. */
export function beritahu(pesan: string, jenis: Jenis = 'sukses', lamaMs = 4500): void {
  const id = berikutnya++;
  ubah((t) => [...t, { id, pesan, jenis }]);
  window.setTimeout(() => ubah((t) => t.filter((x) => x.id !== id)), lamaMs);
}

/** Rak notifikasi — pasang sekali di dekat root aplikasi. */
export function ToastRak() {
  const [t, setT] = useState<Toast[]>(daftar);
  useEffect(() => {
    dengar = setT;
    return () => {
      dengar = null;
    };
  }, []);

  if (t.length === 0) return null;
  return (
    <div className="toast-rak" role="status" aria-live="polite">
      {t.map((x) => (
        <div key={x.id} className={`toast toast--${x.jenis}`}>
          {x.pesan}
        </div>
      ))}
    </div>
  );
}
