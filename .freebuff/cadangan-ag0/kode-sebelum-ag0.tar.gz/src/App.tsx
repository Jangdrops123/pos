import { Navigate, Route, Routes, useParams } from 'react-router-dom';
import { AppLayout } from './layout/AppLayout';
import { HalamanAwal } from './pages/HalamanAwal';
import { ModulKerangka } from './pages/ModulKerangka';
import { TidakDitemukan } from './pages/TidakDitemukan';
import { ToastRak } from './components/crud/Toast';
import { MENU } from './config/menu';
import { ProdukPage } from './pages/master/ProdukPage';
import { KonversiPage } from './pages/master/KonversiPage';
import { PaketPage } from './pages/master/PaketPage';
import { GudangPage } from './pages/master/GudangPage';
import { HalamanUmum } from './pages/master/HalamanUmum';
import { AlihTabLama } from './pages/AlihTabLama';
import { HalamanSaldo } from './pages/stok/HalamanSaldo';
import { HalamanKartu } from './pages/stok/HalamanKartu';
import { HalamanTransfer } from './pages/stok/HalamanTransfer';
import { HalamanOpname } from './pages/opname/HalamanOpname';
import { SesiOpname } from './pages/opname/SesiOpname';
import { HalamanPersediaan } from './pages/persediaan/HalamanPersediaan';
import { PosFoto } from './pages/pos/PosFoto';
import { PosCepat } from './pages/pos/PosCepat';
import { PenjualanPage } from './pages/penjualan/PenjualanPage';
import { PembelianPage } from './pages/pembelian/PembelianPage';
import { DaftarDokumen } from './pages/faktur/DaftarDokumen';
import { DetailFaktur } from './pages/faktur/DetailFaktur';
import { PengaturanLayout } from './pages/pengaturan/PengaturanLayout';
import { TemplateFakturPage } from './pages/pengaturan/TemplateFakturPage';
import { AturanKodiPage } from './pages/pengaturan/AturanKodiPage';
import { StrukPage } from './pages/pengaturan/StrukPage';
import { HalamanAwalPage } from './pages/pengaturan/HalamanAwalPage';
import { ProsesTahunanPage } from './pages/pengaturan/ProsesTahunanPage';
import { LaporanLayout } from './pages/laporan/LaporanLayout';
import { RingkasanLaporan } from './pages/laporan/Ringkasan';
import { DaftarKategoriLaporan } from './pages/laporan/DaftarKategori';
import { HalamanLaporan } from './pages/laporan/HalamanLaporan';
import { TersimpanLaporan } from './pages/laporan/Tersimpan';
import { KasBankPage } from './pages/akuntansi/KasBankPage';
import { BiayaPage } from './pages/akuntansi/BiayaPage';
import { PemasukanPage } from './pages/akuntansi/PemasukanPage';
import { TagihanPage } from './pages/akuntansi/TagihanPage';
import { LaporanDasarPage } from './pages/akuntansi/LaporanDasarPage';
import { HalamanTabPengaturan } from './pages/pengaturan/HalamanTabPengaturan';
import { useSesi } from './lib/sesi';
import { useIdentitas } from './lib/identitas';
import { HalamanLogin } from './pages/auth/HalamanLogin';
import { HalamanLupaSandi } from './pages/auth/HalamanLupaSandi';
import { HalamanResetSandi } from './pages/auth/HalamanResetSandi';
import { HalamanWajibGantiSandi } from './pages/auth/HalamanWajibGantiSandi';

/** O2/R1 — Alias /opname/:id → /stok/opname/:id (tautan lama di dalam aplikasi). */
function AlihOpnameId() {
  const { id } = useParams();
  return <Navigate to={`/stok/opname/${id}`} replace />;
}

/** Rute aplikasi mengikuti menu sidebar (Dashboard + 9 modul). */
function RuteMasuk() {
  return (
    <>
      <Routes>
        <Route element={<AppLayout />}>
          {/* M6 — halaman awal setelah login (per peran; sekali per sesi). */}
          <Route index element={<HalamanAwal />} />

          {/* Z1/Z2 — Master Data: TANPA ribon tab; tiap sub-menu = rute mandiri.
              Layout ber-ribbon (MasterLayout) dihapus; halaman langsung di bawah
              AppLayout sehingga kartu naik ke bawah header (Z4).
              AlihTabLama: alamat lama ?tab=kategori / #kategori → rute baru. */}
          <Route
            path="master"
            element={
              <AlihTabLama
                peta={{
                  produk: '/master/produk',
                  konversi: '/master/konversi',
                  'konversi-satuan': '/master/konversi',
                  paket: '/master/paket',
                  'paket-box': '/master/paket',
                  kategori: '/master/kategori',
                  merek: '/master/merek',
                  satuan: '/master/satuan',
                  pelanggan: '/master/pelanggan',
                  pemasok: '/master/pemasok',
                  gudang: '/master/gudang',
                  'gudang-lokasi': '/master/gudang',
                }}
                selain={<Navigate to="produk" replace />}
              />
            }
          />
          <Route path="master/produk" element={<ProdukPage />} />
          <Route path="master/konversi" element={<KonversiPage />} />
          <Route path="master/paket" element={<PaketPage />} />
          <Route path="master/kategori" element={<HalamanUmum kode="kategori" />} />
          <Route path="master/merek" element={<HalamanUmum kode="merek" />} />
          <Route path="master/satuan" element={<HalamanUmum kode="satuan" />} />
          <Route path="master/pelanggan" element={<HalamanUmum kode="pelanggan" />} />
          <Route path="master/pemasok" element={<HalamanUmum kode="pemasok" />} />
          <Route path="master/gudang" element={<GudangPage />} />
          {/* Z2 — alamat lama tab → rute baru (supaya tautan/bookmark lama tidak rusak). */}
          <Route path="master/konversi-satuan" element={<Navigate to="/master/konversi" replace />} />
          <Route path="master/paket-box" element={<Navigate to="/master/paket" replace />} />
          <Route path="master/gudang-lokasi" element={<Navigate to="/master/gudang" replace />} />

          {/* Z1/Z2 — Stok: tanpa ribon; Stok Saat Ini (indeks), Kartu, Transfer,
              Masuk, Keluar, dan Opname semuanya rute mandiri. */}
          <Route
            path="stok"
            element={
              <AlihTabLama
                peta={{
                  saldo: '/stok',
                  kartu: '/stok/kartu',
                  transfer: '/stok/transfer',
                  masuk: '/stok/masuk',
                  keluar: '/stok/keluar',
                  opname: '/stok/opname',
                }}
                selain={<HalamanSaldo />}
              />
            }
          />
          <Route path="stok/kartu" element={<HalamanKartu />} />
          <Route path="stok/transfer" element={<HalamanTransfer />} />

          {/* R1 — item bekas grup "Persediaan Sub" pindah ke grup Stok.
              Isi halaman TIDAK berubah; hanya alamatnya yang bertambah. */}
          <Route path="stok/masuk" element={<HalamanPersediaan arah="masuk" />} />
          <Route path="stok/keluar" element={<HalamanPersediaan arah="keluar" />} />
          <Route path="stok/opname">
            <Route index element={<HalamanOpname />} />
            <Route path=":id" element={<SesiOpname />} />
          </Route>

          {/* Pembelian / Inbound: modul sudah diimplementasikan */}
          <Route path="pembelian" element={<PembelianPage />} />

          {/* R1 — Pengalihan sisi klien untuk alamat lama (bookmark & tautan lama).
              Redirect HTTP 301 untuk pemuatan halaman langsung ada di server & Vite
              (lihat server/alihPos.ts). */}
          <Route path="persediaan-sub" element={<Navigate to="/stok/masuk" replace />} />
          <Route path="persediaan-sub/masuk" element={<Navigate to="/stok/masuk" replace />} />
          <Route path="persediaan-sub/keluar" element={<Navigate to="/stok/keluar" replace />} />
          <Route path="persediaan/opname" element={<Navigate to="/stok/opname" replace />} />
          <Route path="persediaan/opname/:id" element={<AlihOpnameId />} />

          <Route path="opname" element={<Navigate to="/stok/opname" replace />} />
          <Route path="opname/:id" element={<AlihOpnameId />} />

          {/* M2/Z1 — Modul Penjualan: riwayat (indeks) + retur + piutang.
              Ribon tab sudah dihapus; ketiganya halaman mandiri. */}
          <Route path="penjualan">
            <Route
              index
              element={
                <AlihTabLama
                  peta={{
                    riwayat: '/penjualan',
                    retur: '/penjualan/retur',
                    piutang: '/penjualan/piutang',
                    'pos-foto': '/penjualan/pos/foto',
                    'pos-tanpa-foto': '/penjualan/pos/tanpa-foto',
                  }}
                  selain={<PenjualanPage tab="riwayat" />}
                />
              }
            />
            <Route path="retur" element={<PenjualanPage tab="retur" />} />
            <Route path="piutang" element={<PenjualanPage tab="piutang" />} />
          </Route>

          {/* BAGIAN I — Daftar Dokumen & detail faktur */}
          <Route path="dokumen">
            <Route index element={<DaftarDokumen />} />
            <Route path=":id" element={<DetailFaktur />} />
          </Route>

          {/* Pengaturan: template faktur (ukuran kertas) & aturan kodi */}
          <Route path="pengaturan" element={<PengaturanLayout />}>
            <Route index element={<Navigate to="template-faktur" replace />} />
            <Route path="template-faktur" element={<TemplateFakturPage />} />
            <Route path="aturan-kodi" element={<AturanKodiPage />} />
            <Route path="struk" element={<StrukPage />} />
            <Route path="halaman-awal" element={<HalamanAwalPage />} />
            <Route path="proses-tahunan" element={<ProsesTahunanPage />} />
            {/* AKUNTANSI DASAR — pemetaan akun COA & jurnal dihapus; metode bayar
                → rekening kas diatur di tab Kas & Bank. */}
            <Route path="pemetaan-akun" element={<Navigate to="/pengaturan/t/kas-bank" replace />} />
            {/* Tab baru per grup (Grup Umum & Grup Transaksi) — form dari registry */}
            <Route path="t/:kode" element={<HalamanTabPengaturan />} />
          </Route>

          {/* BAGIAN N — Laporan: filter global + ringkasan + kategori + generik + tersimpan */}
          <Route path="laporan" element={<LaporanLayout />}>
            <Route index element={<RingkasanLaporan />} />
            <Route path="tersimpan" element={<TersimpanLaporan />} />
            <Route path="l/:kode" element={<HalamanLaporan />} />
            <Route path=":kategori" element={<DaftarKategoriLaporan />} />
          </Route>

          {/* Z1/Z2 — Akuntansi: tanpa ribon "pengaturan-nav"; tiap halaman rute mandiri. */}
          <Route
            path="akuntansi"
            element={
              <AlihTabLama
                peta={{
                  kas: '/akuntansi/kas',
                  pengeluaran: '/akuntansi/pengeluaran',
                  pemasukan: '/akuntansi/pemasukan',
                  piutang: '/akuntansi/piutang',
                  hutang: '/akuntansi/hutang',
                  laporan: '/akuntansi/laporan',
                }}
                selain={<Navigate to="/akuntansi/kas" replace />}
              />
            }
          />
          <Route path="akuntansi/kas" element={<KasBankPage />} />
          <Route path="akuntansi/pengeluaran" element={<BiayaPage />} />
          <Route path="akuntansi/pemasukan" element={<PemasukanPage />} />
          <Route path="akuntansi/piutang" element={<TagihanPage tipe="piutang" />} />
          <Route path="akuntansi/hutang" element={<TagihanPage tipe="hutang" />} />
          <Route path="akuntansi/laporan" element={<LaporanDasarPage />} />
          {/* Alamat lama modul akuntansi → dialihkan ke halaman dasar terkait. */}
          <Route path="akuntansi/coa" element={<Navigate to="/akuntansi/kas" replace />} />
          <Route path="akuntansi/jurnal" element={<Navigate to="/akuntansi/kas" replace />} />
          <Route path="akuntansi/buku-besar" element={<Navigate to="/akuntansi/laporan" replace />} />
          <Route path="akuntansi/neraca-saldo" element={<Navigate to="/akuntansi/laporan" replace />} />
          <Route path="akuntansi/periode" element={<Navigate to="/akuntansi/kas" replace />} />

          {/* Modul lain: masih kerangka */}
          {MENU.filter((m) =>
            !['/', '/master', '/stok', '/pembelian', '/dokumen', '/pengaturan', '/penjualan', '/laporan', '/akuntansi'].includes(
              m.path,
            ),
          ).map((m) => (
            <Route key={m.kode} path={m.path.replace(/^\//, '')} element={<ModulKerangka kode={m.kode} />} />
          ))}

          <Route path="*" element={<TidakDitemukan />} />
        </Route>

        {/* M2 — POS di dalam modul Penjualan: layar penuh kasir — di luar shell sidebar. */}
        <Route path="penjualan/pos/foto" element={<PosFoto />} />
        <Route path="penjualan/pos/tanpa-foto" element={<PosCepat />} />

        {/* M2 — Rute lama dialihkan ke rute baru (bookmark & tautan lama tetap hidup).
            Pengalihan HTTP 301 terjadi di server Express & middleware Vite dev;
            berikut pengalihan sisi-klien untuk navigasi dalam aplikasi. */}
        <Route path="pos" element={<Navigate to="/penjualan" replace />} />
        <Route path="pos/foto" element={<Navigate to="/penjualan/pos/foto" replace />} />
        <Route path="pos/cepat" element={<Navigate to="/penjualan/pos/tanpa-foto" replace />} />
        <Route path="pos/tanpa-foto" element={<Navigate to="/penjualan/pos/tanpa-foto" replace />} />
      </Routes>
    </>
  );
}

/**
 * TAHAP 1 — Penjaga sesi (guard rute):
 *
 *  * sesi masih diperiksa  → layar muat (gaya .splash dari index.html),
 *  * belum masuk / habis   → halaman Log In (penuh layar) + Lupa/Reset sandi,
 *  * wajib ganti password  → layar paksa ganti password (tombol Keluar),
 *  * masuk                 → aplikasi normal (rute per modul + gerbang izin).
 */
export function App() {
  const sesi = useSesi();
  const tamu = sesi.status !== 'masuk' || !sesi.info;

  return (
    <>
      <ToastRak />
      {sesi.status === 'memuat' ? (
        <LayarMuat />
      ) : tamu ? (
        <Routes>
          <Route path="/login" element={<HalamanLogin />} />
          <Route path="/lupa-sandi" element={<HalamanLupaSandi />} />
          <Route path="/reset-sandi" element={<HalamanResetSandi />} />
          {/* Alamat lain saat keluar → kembali ke Log In (URL asal jadi tujuan). */}
          <Route path="*" element={<HalamanLogin />} />
        </Routes>
      ) : sesi.info?.pengguna.wajibGanti ? (
        <HalamanWajibGantiSandi />
      ) : (
        <RuteMasuk />
      )}
    </>
  );
}

/** Layar muat sesi — memakai gaya .splash bawaan index.html (tanpa kedip). */
function LayarMuat() {
  const identitas = useIdentitas();
  return (
    <div className="splash" role="status" aria-label="Memuat sesi">
      <div className="splash__logo">{identitas.nama.charAt(0) || 'N'}</div>
      <div className="splash__nama">{identitas.nama}</div>
      <div className="splash__bar" />
    </div>
  );
}
