// BAGIAN X1/Y2 — Identitas aplikasi (nama, tagline, judul tab, favicon,
// aksen, warna latar ikon, logo varian Siang/Malam/Ikon) sebagai SATU SUMBER
// DATA: diambil dari /api/tampilan/identitas, di-cache per perangkat dengan
// nomor versi (logo memakai ?v=versi agar tidak menampilkan logo lama), dan
// dipakai sidebar, favicon, judul tab, layar muat, serta kop cetak.
import { useEffect, useState } from 'react';
import { apiGet } from './api';

export type CakupanIdentitas = 'semua' | 'per-toko';

export interface Identitas {
  nama: string;
  tagline: string;
  /** Judul tab browser — kosong = ikuti nama aplikasi (Y2.1). */
  judulTab: string;
  /** Favicon khusus — kosong = ikon kecil / favicon bawaan. */
  favicon: string;
  /** Warna aksen aplikasi ('' = aksen bawaan). */
  aksen: string;
  /** Token warna latar ikon logo ('' = otomatis). */
  latar: string;
  logoSiang: string;
  logoMalam: string;
  ikon: string;
  /** Pakai logo & nama ini juga untuk faktur dan struk (Y2.2). */
  pakaiFaktur: boolean;
  cakupan: CakupanIdentitas;
  toko: string | null;
  versi: string;
}

const KUNCI = 'nusapos.identitas';

export const IDENTITAS_BAWAAN: Identitas = {
  nama: 'NusaSuite',
  tagline: 'POS · WMS · Akuntansi',
  judulTab: '',
  favicon: '',
  aksen: '',
  latar: '',
  logoSiang: '',
  logoMalam: '',
  ikon: '',
  pakaiFaktur: false,
  cakupan: 'semua',
  toko: null,
  versi: '0',
};

/** Kode toko aktif (dipilih di Pengaturan ▸ Data Toko & Gudang / halaman toko). */
export function tokoAktif(): string {
  try {
    return localStorage.getItem('nusapos.tokoAktif') ?? '';
  } catch {
    return '';
  }
}

let data: Identitas = bacaLokal();
const pendengar = new Set<() => void>();

function bacaLokal(): Identitas {
  try {
    const v = localStorage.getItem(KUNCI);
    if (!v) return { ...IDENTITAS_BAWAAN };
    const j = JSON.parse(v) as Partial<Identitas>;
    return {
      nama: j.nama?.trim() || IDENTITAS_BAWAAN.nama,
      tagline: j.tagline ?? IDENTITAS_BAWAAN.tagline,
      judulTab: j.judulTab ?? '',
      favicon: j.favicon ?? '',
      aksen: j.aksen ?? '',
      latar: j.latar ?? '',
      logoSiang: j.logoSiang ?? '',
      logoMalam: j.logoMalam ?? '',
      ikon: j.ikon ?? '',
      pakaiFaktur: Boolean(j.pakaiFaktur),
      cakupan: j.cakupan === 'per-toko' ? 'per-toko' : 'semua',
      toko: j.toko ?? null,
      versi: j.versi ?? '0',
    };
  } catch {
    return { ...IDENTITAS_BAWAAN };
  }
}

function umumkan(next: Identitas) {
  data = next;
  try {
    localStorage.setItem(KUNCI, JSON.stringify(next));
  } catch {
    /* penyimpanan nonaktif — abaikan */
  }
  terapkan(next);
  for (const f of pendengar) f();
}

/** Judul tab = judul khusus, atau nama aplikasi bila belum diisi (Y2.1). */
export function judulTab(i: Identitas = data): string {
  return i.judulTab.trim() || i.nama;
}

/** URL favicon efektif (favicon khusus → ikon kecil → bawaan aplikasi). */
export function faviconEfektif(i: Identitas = data): string {
  return i.favicon || i.ikon || '/favicon.svg';
}

/** Warna aksen efektif: preferensi per pengguna menang atas aksen aplikasi. */
export function aksenEfektif(): string {
  let pengguna = '';
  try {
    pengguna = localStorage.getItem('nusapos.aksen') ?? '';
  } catch {
    /* penyimpanan nonaktif */
  }
  return pengguna || data.aksen;
}

/** Aksen aplikasi dari identitas (dipakai modul tema sebagai nilai dasar). */
export function aksenAplikasi(): string {
  return data.aksen;
}

/**
 * Terapkan identitas ke judul tab, favicon, warna aksen, serta layar muat
 * (splash di index.html) — dipanggil saat modul dimuat (cache) dan setiap
 * identitas berubah supaya perubahan langsung tampil tanpa muat ulang.
 */
function terapkan(i: Identitas) {
  if (typeof document === 'undefined') return;

  document.title = judulTab(i);

  const href = faviconEfektif(i);
  let link = document.querySelector<HTMLLinkElement>('link[rel="icon"]');
  if (!link) {
    link = document.createElement('link');
    link.rel = 'icon';
    document.head.appendChild(link);
  }
  if (link.getAttribute('href') !== href) link.setAttribute('href', href);

  // Aksen: preferensi per pengguna (Pengaturan ▸ Tampilan) bila ada, selain
  // itu ikuti aksen aplikasi (Y2.1).
  const aksen = aksenEfektif();
  const el = document.documentElement;
  if (aksen) el.dataset.aksen = aksen;
  else delete el.dataset.aksen;

  // Layar muat (splash) memakai identitas dari cache sebelum data tiba.
  const splashNama = document.querySelector('.splash__nama');
  if (splashNama) splashNama.textContent = i.nama;
  const splashLogo = document.querySelector<HTMLElement>('.splash__logo');
  if (splashLogo) {
    const gambar = i.ikon || i.logoSiang || i.logoMalam;
    if (gambar) {
      splashLogo.innerHTML = `<img src="${gambar.replace(/"/g, '"')}" alt="" />`;
      splashLogo.classList.add('splash__logo--gambar');
    } else {
      splashLogo.textContent = i.nama.trim().charAt(0).toUpperCase() || 'N';
      splashLogo.classList.remove('splash__logo--gambar');
    }
  }
}

/** Ambil identitas terbaru dari server (tanpa memaksa UI menunggu). */
export async function muatIdentitas(): Promise<Identitas> {
  const toko = tokoAktif();
  const r = await apiGet<Identitas>(
    `/api/tampilan/identitas${toko ? `?toko=${encodeURIComponent(toko)}` : ''}`,
  );
  const next: Identitas = {
    nama: r.nama?.trim() || IDENTITAS_BAWAAN.nama,
    tagline: r.tagline ?? '',
    judulTab: r.judulTab ?? '',
    favicon: r.favicon ?? '',
    aksen: r.aksen ?? '',
    latar: r.latar ?? '',
    logoSiang: r.logoSiang ?? '',
    logoMalam: r.logoMalam ?? '',
    ikon: r.ikon ?? '',
    pakaiFaktur: Boolean(r.pakaiFaktur),
    cakupan: r.cakupan === 'per-toko' ? 'per-toko' : 'semua',
    toko: r.toko ?? null,
    versi: r.versi ?? '1',
  };
  if (JSON.stringify(next) !== JSON.stringify(data)) umumkan(next);
  return next;
}

/** Simpan identitas (hasil PUT dari Pengaturan) & sebarkan tanpa muat ulang. */
export function setIdentitas(next: Identitas) {
  umumkan(next);
}

export function bacaIdentitas(): Identitas {
  return data;
}

/** React hook: identitas terkini + muat ulang sekali saat mount. */
export function useIdentitas(): Identitas {
  const [, paksa] = useState(0);
  useEffect(() => {
    const f = () => paksa((n) => n + 1);
    pendengar.add(f);
    void muatIdentitas().catch(() => {
      /* offline / server belum siap — pakai cache lokal */
    });
    return () => {
      pendengar.delete(f);
    };
  }, []);
  return data;
}

/** Logo yang dipakai untuk tema aktif sekarang (X1.1 — varian siang/malam). */
export function logoUntukTema(i: Identitas = data): string {
  const gelap = document.documentElement.dataset.theme === 'dark';
  const utama = gelap ? i.logoMalam || i.logoSiang : i.logoSiang || i.logoMalam;
  return utama || i.ikon;
}

/** Logo untuk sebuah tema tertentu (dipakai pratinjau Halaman Identitas). */
export function logoUntukTemaTertentu(i: Identitas, tema: 'siang' | 'malam'): string {
  const utama = tema === 'malam' ? i.logoMalam || i.logoSiang : i.logoSiang || i.logoMalam;
  return utama || i.ikon;
}

// Terapkan SEGERA dari cache localStorage: judul tab, favicon, dan layar muat
// memakai identitas terakhir tanpa menunggu jawaban server.
terapkan(data);
