// Preferensi tampilan tambahan dari Pengaturan ▸ Tampilan:
// kepadatan (nyaman/padat/longgar), ukuran font, dan sidebar ciut otomatis.
// Disimpan di localStorage agar pemuatan tanpa kedip, dan di tabel settings
// lewat /api/pengaturan/tampilan agar mengikuti database.

import { apiGet } from './api';

const KUNCI = 'nusapos.tampilanBaru';

/**
 * Kepadatan tampilan (U2). `nyaman` = bawaan; `padat` = baris tabel 36px &
 * font 13px; `longgar` = baris tabel 52px. Nilai lama (`normal`, `ringkas`)
 * masih dibaca agar preferensi pengguna lama tidak hilang — dipetakan ke
 * padat/norman baru.
 */
export type Kepadatan = 'nyaman' | 'padat' | 'longgar';

export interface TampilanBaru {
  kepadatan: Kepadatan;
  ukuran_font: string;
  sidebar_ciut: boolean;
}

const BAWAAN: TampilanBaru = { kepadatan: 'nyaman', ukuran_font: '100', sidebar_ciut: false };

/** Petakan nilai lama → nilai baru. */
function keKepadatan(v: unknown): Kepadatan {
  const s = String(v ?? '');
  if (s === 'padat' || s === 'longgar' || s === 'nyaman') return s;
  if (s === 'ringkas') return 'padat'; // nilai lama
  return 'nyaman'; // 'normal' dan apa pun yang tak dikenal
}

export function bacaTampilanBaru(): TampilanBaru {
  try {
    const v = localStorage.getItem(KUNCI);
    if (!v) return BAWAAN;
    const j = JSON.parse(v) as Partial<TampilanBaru>;
    return {
      kepadatan: keKepadatan(j.kepadatan),
      ukuran_font: ['87', '100', '112'].includes(String(j.ukuran_font)) ? String(j.ukuran_font) : '100',
      sidebar_ciut: j.sidebar_ciut === true,
    };
  } catch {
    return BAWAAN;
  }
}

/** Terapkan ke <html> sebagai atribut & variabel CSS. */
export function terapkanTampilanBaru(p: TampilanBaru = bacaTampilanBaru()): void {
  const el = document.documentElement;
  el.dataset.kepadatan = p.kepadatan;
  el.dataset.sidebarCiut = p.sidebar_ciut ? 'ya' : 'tidak';
  const skala = (Number(p.ukuran_font) || 100) / 100;
  el.style.setProperty('--skala-font', String(skala));
}

export function simpanTampilanBaru(p: TampilanBaru): void {
  try {
    localStorage.setItem(KUNCI, JSON.stringify(p));
  } catch {
    /* penyimpanan nonaktif — abaikan */
  }
  terapkanTampilanBaru(p);
}

/**
 * Sinkron dari database saat aplikasi dibuka (perangkat baru / sesi bersih).
 * Lokal menang bila sudah ada pilihan — sama seperti preferensi tema.
 */
export async function sinkronTampilanBaru(): Promise<void> {
  try {
    if (localStorage.getItem(KUNCI)) return;
    const r = await apiGet<{ nilai: Record<string, unknown> }>('/api/pengaturan/tampilan');
    const n = r.nilai ?? {};
    simpanTampilanBaru({
      kepadatan: keKepadatan(n.kepadatan),
      ukuran_font: ['87', '100', '112'].includes(String(n.ukuran_font)) ? String(n.ukuran_font) : '100',
      sidebar_ciut: n.sidebar_ciut === true || n.sidebar_ciut === 1 || n.sidebar_ciut === '1',
    });
  } catch {
    /* server belum siap — pakai bawaan lokal */
  }
}
