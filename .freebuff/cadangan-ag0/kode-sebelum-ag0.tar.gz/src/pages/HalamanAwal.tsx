import { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { Dashboard } from './Dashboard';
import { peranAktif, tujuanHalamanAwal } from '../lib/pengguna';

// Diperiksa sekali per sesi muat peramban — agar pengguna tetap bisa membuka
// Dashboard lewat menu walaupun halaman awalnya POS/Penjualan.
let sudahDiperiksa = false;

/**
 * Rute indeks (/) — M6: "Halaman awal setelah login" per peran.
 * Kasir bawaannya langsung POS; Admin/Manajer tetap Dashboard.
 * Modul login belum ada: peran dipilih manual di Pengaturan → Halaman Awal.
 */
export function HalamanAwal() {
  const [tujuan, setTujuan] = useState<string | null>(null);

  useEffect(() => {
    if (sudahDiperiksa) return;
    sudahDiperiksa = true;
    const t = tujuanHalamanAwal(peranAktif());
    if (t !== '/') setTujuan(t);
  }, []);

  if (tujuan) return <Navigate to={tujuan} replace />;
  return <Dashboard />;
}
