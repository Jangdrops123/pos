import { useMemo, useRef, useState } from 'react';
import { Icon } from '../../components/Icon';
import { formatRupiah } from '../../lib/format';
import type { KolomLaporan } from './tipe';

/**
 * Tabel laporan generik (N4):
 * urut kolom · pencarian · pengelompokan (group by) · baris total · paginasi ·
 * kolom bisa disembunyikan · angka nowrap rata kanan format Rp.
 */

const PER_HAL = [25, 50, 100];

function selFormat(v: unknown, tipe: KolomLaporan['tipe']): string {
  if (v === null || v === undefined) return '—';
  switch (tipe) {
    case 'rupiah':
      return formatRupiah(Number(v));
    case 'persen':
      return `${Number(v).toLocaleString('id-ID', { maximumFractionDigits: 1 })}%`;
    case 'angka':
      return Number(v).toLocaleString('id-ID', { maximumFractionDigits: 2 });
    case 'waktu':
      return String(v).replace('T', ' ').slice(0, 16);
    default:
      return String(v);
  }
}

const nilaiUrut = (v: unknown): number | string =>
  typeof v === 'number' ? v : String(v ?? '').toLowerCase();

export function TabelLaporan({
  kolom,
  rows,
  total,
  judul,
  adaDrill,
  onDrill,
  terbatas,
}: {
  kolom: KolomLaporan[];
  rows: Record<string, unknown>[];
  total: Record<string, unknown> | null;
  judul: string;
  adaDrill?: (row: Record<string, unknown>) => boolean;
  onDrill?: (row: Record<string, unknown>) => void;
  terbatas?: boolean;
}) {
  const [urut, setUrut] = useState<{ kunci: string; arah: 1 | -1 } | null>(null);
  const [cari, setCari] = useState('');
  const [kelompok, setKelompok] = useState('');
  const [hal, setHal] = useState(0);
  const [per, setPer] = useState(PER_HAL[0]);
  const [sembunyi, setSembunyi] = useState<Set<string>>(new Set());
  const [bukaKolom, setBukaKolom] = useState(false);
  const menuKolom = useRef<HTMLDivElement>(null);

  const terlihat = useMemo(() => kolom.filter((k) => !sembunyi.has(k.kunci)), [kolom, sembunyi]);

  const tersaring = useMemo(() => {
    const q = cari.trim().toLowerCase();
    let r = rows;
    if (q) r = r.filter((row) => kolom.some((k) => String(row[k.kunci] ?? '').toLowerCase().includes(q)));
    if (urut) {
      const { kunci, arah } = urut;
      const tipe = kolom.find((k) => k.kunci === kunci)?.tipe ?? 'teks';
      r = [...r].sort((a, b) => {
        const va = nilaiUrut(a[kunci]);
        const vb = nilaiUrut(b[kunci]);
        if (typeof va === 'number' && typeof vb === 'number') return (va - vb) * arah;
        return String(va).localeCompare(String(vb), 'id') * arah;
      });
      void tipe;
    }
    return r;
  }, [rows, cari, urut, kolom]);

  // Pengelompokan (group by): ringkas kolom numerik per nilai kolom terpilih.
  const { kelompokan, kolomKelompok } = useMemo(() => {
    if (!kelompok) return { kelompokan: null as Record<string, unknown>[] | null, kolomKelompok: '' };
    const indeks = new Map<string, Record<string, unknown>>();
    for (const row of tersaring) {
      const kunci = String(row[kelompok] ?? '(kosong)');
      const ada = indeks.get(kunci);
      if (ada) {
        for (const k of kolom) {
          if (k.tipe === 'rupiah' || k.tipe === 'angka') ada[k.kunci] = Number(ada[k.kunci] ?? 0) + Number(row[k.kunci] ?? 0);
        }
      } else {
        const baru: Record<string, unknown> = { ...row };
        for (const k of kolom) {
          if (k.tipe === 'rupiah' || k.tipe === 'angka') baru[k.kunci] = Number(row[k.kunci] ?? 0);
        }
        indeks.set(kunci, baru);
      }
    }
    return { kelompokan: [...indeks.values()], kolomKelompok: kelompok };
  }, [tersaring, kelompok, kolom]);

  const dasar = kelompokan ?? tersaring;
  const jumlahHal = Math.max(1, Math.ceil(dasar.length / per));
  const halAman = Math.min(hal, jumlahHal - 1);
  const page = dasar.slice(halAman * per, halAman * per + per);

  const totalSemua = useMemo(() => {
    if (kelompokan) return null; // baris kelompok bukan angka mentah — total dihitung dari rows asli
    const t: Record<string, unknown> = { _total: true };
    for (const k of kolom) {
      if (k.tipe === 'rupiah' || k.tipe === 'angka') t[k.kunci] = tersaring.reduce((a, r) => a + Number(r[k.kunci] ?? 0), 0);
      else if (k.tipe === 'persen' && tersaring.length)
        t[k.kunci] = tersaring.reduce((a, r) => a + Number(r[k.kunci] ?? 0), 0) / tersaring.length;
    }
    return Object.keys(t).length > 1 ? t : null;
  }, [tersaring, kolom, kelompokan]);

  const kunciTotal = totalSemua ?? total;

  const klikUrut = (kunci: string) => {
    setUrut((u) => (u?.kunci !== kunci ? { kunci, arah: 1 } : u.arah === 1 ? { kunci, arah: -1 } : null));
    setHal(0);
  };

  return (
    <section className="laporan-tabel">
      <div className="laporan-tabel__alat">
        <input
          className="input-cari"
          type="search"
          placeholder="Cari dalam tabel…"
          aria-label={`Cari dalam ${judul}`}
          value={cari}
          onChange={(e) => {
            setCari(e.target.value);
            setHal(0);
          }}
        />
        <label className="laporan-tabel__kelompok">
          <span>Kelompokkan:</span>
          <select
            className="input-pilih"
            value={kelompok}
            onChange={(e) => {
              setKelompok(e.target.value);
              setHal(0);
            }}
          >
            <option value="">Tidak</option>
            {kolom
              .filter((k) => k.tipe === 'teks' || k.tipe === 'tanggal')
              .map((k) => (
                <option key={k.kunci} value={k.kunci}>
                  {k.label}
                </option>
              ))}
          </select>
        </label>
        <div className="laporan-tabel__kolom" ref={menuKolom}>
          <button
            type="button"
            className="tombol tombol--kecil"
            aria-expanded={bukaKolom}
            onClick={() => setBukaKolom((b) => !b)}
          >
            Kolom
          </button>
          {bukaKolom && (
            <div className="laporan-tabel__kolom-menu">
              {kolom.map((k) => (
                <label key={k.kunci}>
                  <input
                    type="checkbox"
                    checked={!sembunyi.has(k.kunci)}
                    onChange={(e) =>
                      setSembunyi((s) => {
                        const n = new Set(s);
                        if (e.target.checked) n.delete(k.kunci);
                        else n.add(k.kunci);
                        return n;
                      })
                    }
                  />
                  {k.label}
                </label>
              ))}
            </div>
          )}
        </div>
        <span className="teks-redup teks-kecil">
          {dasar.length.toLocaleString('id-ID')} baris{kelompok ? ` · ${kolomKelompok}` : ''}
          {terbatas ? ' · dibatasi server' : ''}
        </span>
      </div>

      <div className="tabel-bungkus laporan-tabel__bungkus">
        <table className="tabel laporan-tabel__tabel">
          <thead>
            <tr>
              {terlihat.map((k) => (
                <th
                  key={k.kunci}
                  className={k.tipe === 'teks' ? '' : 'rata-kanan nowrap'}
                  aria-sort={urut?.kunci === k.kunci ? (urut.arah === 1 ? 'ascending' : 'descending') : 'none'}
                >
                  <button type="button" className="laporan-tabel__urut" onClick={() => klikUrut(k.kunci)}>
                    {k.label}
                    <Icon
                      nama={urut?.kunci === k.kunci ? (urut.arah === 1 ? 'chevron-up' : 'chevron-down') : 'chevron-down'}
                      size={12}
                      className={urut?.kunci === k.kunci ? '' : 'redup'}
                    />
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {page.length === 0 ? (
              <tr>
                <td className="tabel-kosong" colSpan={terlihat.length || 1}>
                  {cari ? 'Tidak ada baris yang cocok.' : 'Tidak ada data pada filter & periode ini.'}
                </td>
              </tr>
            ) : (
              page.map((row, i) => (
                <tr
                  key={i}
                  className={adaDrill?.(row) ? 'baris-drill' : undefined}
                  onClick={adaDrill?.(row) ? () => onDrill?.(row) : undefined}
                  tabIndex={adaDrill?.(row) ? 0 : undefined}
                  onKeyDown={
                    adaDrill?.(row)
                      ? (e) => {
                          if (e.key === 'Enter') onDrill?.(row);
                        }
                      : undefined
                  }
                >
                  {terlihat.map((k) => (
                    <td key={k.kunci} className={k.tipe === 'teks' ? '' : 'rata-kanan nowrap'}>
                      {selFormat(row[k.kunci], k.tipe)}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
          {kunciTotal && dasar.length > 0 && (
            <tfoot>
              <tr className="laporan-tabel__total">
                <td className="nowrap">Total</td>
                {terlihat.slice(1).map((k) => (
                  <td key={k.kunci} className={k.tipe === 'teks' ? '' : 'rata-kanan nowrap'}>
                    {k.tipe === 'teks' ? '' : selFormat(kunciTotal[k.kunci], k.tipe)}
                  </td>
                ))}
              </tr>
            </tfoot>
          )}
        </table>
      </div>

      <div className="laporan-tabel__kaki">
        <label>
          Baris:
          <select
            className="input-pilih"
            value={per}
            onChange={(e) => {
              setPer(Number(e.target.value));
              setHal(0);
            }}
          >
            {PER_HAL.map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </label>
        <span className="teks-redup teks-kecil">
          Halaman {halAman + 1} / {jumlahHal}
        </span>
        <div className="baris">
          <button type="button" className="tombol tombol--kecil" disabled={halAman === 0} onClick={() => setHal(halAman - 1)}>
            Sebelumnya
          </button>
          <button
            type="button"
            className="tombol tombol--kecil"
            disabled={halAman >= jumlahHal - 1}
            onClick={() => setHal(halAman + 1)}
          >
            Berikutnya
          </button>
        </div>
      </div>
    </section>
  );
}
