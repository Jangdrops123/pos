import { useEffect, useState } from 'react';
import { IconButton } from '../../components/IconButton';
import { Modal } from '../../components/crud/Modal';
import { beritahu } from '../../components/crud/Toast';
import { apiPost } from '../../lib/api';
import { namaPeran, peranAktif } from '../../lib/pengguna';
import { bukaWa, nomorWaValid } from '../faktur/aksi';
import { cetakLaporan, OPSI_CETAK_AWAL, type MetaCetak, type OpsiCetak } from './cetak';
import { DialogCetakLaporan } from './DialogCetakLaporan';
import type { KolomLaporan } from './tipe';

/**
 * N4 — ikon aksi di kanan header laporan, semuanya IKON dengan tooltip teks
 * saat hover/fokus (IconButton): Ekspor Excel, Ekspor PDF, Cetak, Kirim,
 * Simpan Laporan, Segarkan. Ekspor & cetak dicatat ke log aktivitas (N7).
 */

export interface PropsAksi {
  kode: string;
  judul: string;
  kolom: KolomLaporan[];
  rows: Record<string, unknown>[];
  total: Record<string, unknown> | null;
  filter: [string, string][];
  /** Query string filter & periode lengkap (untuk URL ekspor). */
  ser: string;
  namaUsaha: string;
  alamatUsaha?: string;
  pesanRingkas: string;
  onSegar: () => void;
  setelahSimpan?: () => void;
}

function catat(kode: string, aksi: 'cetak' | 'kirim' | 'ekspor'): void {
  void apiPost('/api/laporan/log-aksi', { kode, aksi }).catch(() => undefined);
}

export function AksiLaporan(p: PropsAksi) {
  const [dlg, setDlg] = useState<'cetak' | 'kirim' | 'simpan' | null>(null);
  const [nomor, setNomor] = useState('');
  const [pesan, setPesan] = useState('');
  const [namaSimpan, setNamaSimpan] = useState('');
  const [jadwal, setJadwal] = useState('');
  const [sibuk, setSibuk] = useState(false);
  // N8 — layar kecil: semua ikon aksi dirapatkan ke menu titik tiga (⋮).
  const [menuBuka, setMenuBuka] = useState(false);
  const [layarKecil, setLayarKecil] = useState(() =>
    typeof window !== 'undefined' ? window.matchMedia('(max-width: 720px)').matches : false,
  );
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 720px)');
    const ubah = () => setLayarKecil(mq.matches);
    mq.addEventListener('change', ubah);
    return () => mq.removeEventListener('change', ubah);
  }, []);

  const eksporUrl = `/api/laporan/${encodeURIComponent(p.kode)}/ekspor?${p.ser}`;

  const jalanCetak = (opsi: OpsiCetak) => {
    setDlg(null);
    const w = cetakLaporan({
      judul: p.judul,
      namaUsaha: p.namaUsaha,
      alamatUsaha: p.alamatUsaha,
      kolom: p.kolom,
      rows: p.rows,
      total: p.total,
      filter: p.filter,
      opsi,
      pencetak: namaPeran(peranAktif()),
    });
    if (w) catat(p.kode, 'cetak');
    else beritahu('Popup cetak diblokir peramban — izinkan popup untuk situs ini.', 'galat');
  };

  const bukaDlg = (d: 'cetak' | 'kirim' | 'simpan') => {
    if (d === 'kirim') setPesan(p.pesanRingkas);
    if (d === 'simpan') setNamaSimpan(`${p.judul} — ${p.filter[0]?.[1] ?? ''}`.slice(0, 80));
    setDlg(d);
  };

  return (
    <>
      <div
        className={`laporan-aksi ${layarKecil ? 'laporan-aksi--kecil' : ''} ${menuBuka ? 'laporan-aksi--buka' : ''}`}
      >
        {layarKecil && (
          <IconButton
            ikon="kebab"
            label="Aksi laporan"
            ukuran="toolbar"
            aktif={menuBuka}
            onClick={() => setMenuBuka((b) => !b)}
          />
        )}
        <div className="laporan-aksi__isi" onClickCapture={() => setMenuBuka(false)}>
        <a
          className="ikon-btn ikon-btn--toolbar ikon-btn--netral tombol-tip"
          data-tip="Ekspor Excel"
          aria-label="Ekspor Excel"
          href={eksporUrl}
          download
          onClick={() => catat(p.kode, 'ekspor')}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z" />
            <path d="M14 2v6h6M8 13l2 5 2-5M16 13l-2 5-2-5" />
          </svg>
        </a>
        <IconButton
          ikon="file-down"
          label="Ekspor PDF"
          ukuran="toolbar"
          onClick={() => setDlg('cetak')}
        />
        <IconButton
          ikon="printer"
          label="Cetak"
          ukuran="toolbar"
          onClick={() => setDlg('cetak')}
        />
        <IconButton ikon="send" label="Kirim (WhatsApp / Bagikan)" ukuran="toolbar" onClick={() => bukaDlg('kirim')} />
        <IconButton ikon="archive" label="Simpan Laporan" ukuran="toolbar" onClick={() => bukaDlg('simpan')} />
        <IconButton ikon="rotate-ccw" label="Segarkan" ukuran="toolbar" onClick={p.onSegar} />
        </div>
      </div>

      {dlg === 'cetak' && (
        <DialogCetakLaporan
          meta={{
            judul: p.judul,
            namaUsaha: p.namaUsaha,
            alamatUsaha: p.alamatUsaha,
            kolom: p.kolom,
            rows: p.rows,
            total: p.total,
            filter: p.filter,
            pencetak: namaPeran(peranAktif()),
            opsi: OPSI_CETAK_AWAL,
          } satisfies MetaCetak}
          onTutup={() => setDlg(null)}
          onCetak={jalanCetak}
          onKirim={() => {
            setPesan(p.pesanRingkas);
            setDlg('kirim');
          }}
        />
      )}

      {dlg === 'kirim' && (
        <Modal
          judul={`Kirim laporan: ${p.judul}`}
          lebar="sedang"
          onTutup={() => setDlg(null)}
          aksi={
            <>
              <button type="button" className="tombol tombol--netral" onClick={() => setDlg(null)}>
                Batal
              </button>
              <button
                type="button"
                className="tombol"
                onClick={() => {
                  void navigator.clipboard
                    .writeText(pesan)
                    .then(() => beritahu('Pesan laporan disalin ke papan klip.', 'sukses'));
                }}
              >
                Salin pesan
              </button>
              <button
                type="button"
                className="tombol tombol--primer"
                onClick={async () => {
                  if (nomor && !nomorWaValid(nomor)) {
                    beritahu('Nomor WhatsApp belum valid (min. 9 digit).', 'galat');
                    return;
                  }
                  catat(p.kode, 'kirim');
                  if (nomor) {
                    bukaWa(nomor, pesan);
                    setDlg(null);
                    return;
                  }
                  if (navigator.share) {
                    try {
                      await navigator.share({ title: p.judul, text: pesan });
                      setDlg(null);
                      return;
                    } catch {
                      /* pengguna batal — biarkan dialog terbuka */
                    }
                  }
                  beritahu('Isi nomor WhatsApp atau gunakan tombol Salin pesan.', 'info');
                }}
              >
                {nomor ? 'Buka WhatsApp' : 'Bagikan'}
              </button>
            </>
          }
        >
          <label className="bidang">
            <span>Nomor WhatsApp (opsional)</span>
            <input
              type="tel"
              value={nomor}
              onChange={(e) => setNomor(e.target.value)}
              placeholder="08123456789 — kosongkan untuk memakai dialog berbagi"
            />
          </label>
          <label className="bidang">
            <span>Pesan</span>
            <textarea rows={7} value={pesan} onChange={(e) => setPesan(e.target.value)} />
          </label>
          <p className="teks-redup teks-kecil">
            Lampirkan PDF-nya dengan lebih dulu membuka ikon Cetak → “Save as PDF”.
          </p>
        </Modal>
      )}

      {dlg === 'simpan' && (
        <Modal
          judul="Simpan Laporan"
          lebar="kecil"
          onTutup={() => setDlg(null)}
          sedangKirim={sibuk}
          aksi={
            <>
              <button type="button" className="tombol tombol--netral" onClick={() => setDlg(null)} disabled={sibuk}>
                Batal
              </button>
              <button
                type="button"
                className="tombol tombol--primer"
                disabled={sibuk || !namaSimpan.trim()}
                onClick={async () => {
                  setSibuk(true);
                  try {
                    await apiPost('/api/laporan/tersimpan', {
                      nama: namaSimpan.trim(),
                      laporan: p.kode,
                      params: Object.fromEntries(new URLSearchParams(p.ser)),
                      jadwal: jadwal || null,
                    });
                    beritahu(`Laporan tersimpan${jadwal ? ` · jadwal ${jadwal}` : ''}.`, 'sukses');
                    setDlg(null);
                    p.setelahSimpan?.();
                  } catch (e) {
                    beritahu((e as Error).message, 'galat');
                  } finally {
                    setSibuk(false);
                  }
                }}
              >
                Simpan
              </button>
            </>
          }
        >
          <label className="bidang">
            <span>Nama laporan</span>
            <input value={namaSimpan} onChange={(e) => setNamaSimpan(e.target.value)} autoFocus placeholder="Contoh: Penjualan Bulan Ini - Gudang Pusat" />
          </label>
          <label className="bidang">
            <span>Penjadwalan (opsional)</span>
            <select value={jadwal} onChange={(e) => setJadwal(e.target.value)}>
              <option value="">Tanpa jadwal</option>
              <option value="harian">Harian</option>
              <option value="mingguan">Mingguan</option>
              <option value="bulanan">Bulanan</option>
            </select>
            <small className="teks-redup">
              Laporan berjadwal dijalankan dari halaman “Laporan Tersimpan” dan hasilnya masuk Daftar Dokumen.
            </small>
          </label>
        </Modal>
      )}
    </>
  );
}
