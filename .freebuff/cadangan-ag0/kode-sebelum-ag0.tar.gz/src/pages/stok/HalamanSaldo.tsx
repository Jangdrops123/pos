import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { IconButton } from '../../components/IconButton';
import { beritahu } from '../../components/crud/Toast';
import { ambilOpsi, apiGet, apiPut } from '../../lib/api';
import { formatAngka, formatRupiah } from '../../lib/format';

type Baris = Record<string, any>;
type Opsi = { id: number; label: string };
type Ringkasan = { qty_total: number; jumlah_kurang: number; nilai_halaman: number; nilai_persediaan: number };

export function HalamanSaldo() {
  const navigate = useNavigate();
  const [data, setData] = useState<Baris[]>([]);
  const [total, setTotal] = useState(0);
  const [ringkasan, setRingkasan] = useState<Ringkasan | null>(null);
  const [hal, setHal] = useState(1);
  const [per, setPer] = useState(20);
  const [cari, setCari] = useState('');
  const [cariTunda, setCariTunda] = useState('');
  const [gudang, setGudang] = useState('');
  const [kategori, setKategori] = useState('');
  const [kurangSaja, setKurangSaja] = useState(false);
  const [sibuk, setSibuk] = useState(false);

  const [opsiGudang, setOpsiGudang] = useState<Opsi[]>([]);
  const [opsiKategori, setOpsiKategori] = useState<Opsi[]>([]);
  const [pengaturan, setPengaturan] = useState<{ stok_minus_izinkan: boolean; valuasi: string } | null>(null);

  useEffect(() => {
    const t = window.setTimeout(() => {
      setCariTunda(cari);
      setHal(1);
    }, 350);
    return () => window.clearTimeout(t);
  }, [cari]);

  useEffect(() => {
    ambilOpsi('gudang').then(setOpsiGudang).catch((e: Error) => beritahu(e.message, 'galat'));
    ambilOpsi('kategori').then(setOpsiKategori).catch((e: Error) => beritahu(e.message, 'galat'));
    apiGet<{ stok_minus_izinkan: boolean; valuasi: string }>('/api/stock/pengaturan')
      .then(setPengaturan)
      .catch((e: Error) => beritahu(e.message, 'galat'));
  }, []);

  // Saldo disimpan per produk per gudang — tanpa filter lokasi (lokasi hanya
  // tercatat di mutasi/kartu stok).
  const muat = useCallback(async () => {
    setSibuk(true);
    try {
      const q = new URLSearchParams({ hal: String(hal), per: String(per), cari: cariTunda });
      if (gudang) q.set('gudang', gudang);
      if (kategori) q.set('kategori', kategori);
      if (kurangSaja) q.set('kurang', '1');
      const r = await apiGet<{ data: Baris[]; total: number; ringkasan: Ringkasan }>(`/api/stock/saldo?${q.toString()}`);
      setData(r.data);
      setTotal(r.total);
      setRingkasan(r.ringkasan);
    } catch (err) {
      beritahu((err as Error).message, 'galat');
    } finally {
      setSibuk(false);
    }
  }, [hal, per, cariTunda, gudang, kategori, kurangSaja]);

  useEffect(() => {
    void muat();
  }, [muat]);

  const totalHal = Math.max(1, Math.ceil(total / per));

  const ubahStokMinus = async (nilai: boolean) => {
    try {
      await apiPut('/api/stock/pengaturan', { stok_minus_izinkan: nilai });
      setPengaturan((p) => (p ? { ...p, stok_minus_izinkan: nilai } : p));
      beritahu(nilai ? 'Stok minus DIIZINKAN.' : 'Stok minus TIDAK diizinkan.');
    } catch (err) {
      beritahu((err as Error).message, 'galat');
      setPengaturan((p) => (p ? { ...p, stok_minus_izinkan: !nilai } : p)); // kembalikan sakelar
    }
  };

  return (
    <div className="halaman">
      <section className="kartu">
        <div className="kartu__kepala">
          <div>
            <h3>Saldo Stok</h3>
            <p className="teks-redup teks-kecil">Per produk — per gudang. Nilai memakai rata-rata bergerak.</p>
          </div>
          <div className="tombol-baris">
            {/* O4 — pintasan: buka daftar Opname dengan gudang filter terisi. */}
            <IconButton
              ikon="circle-check"
              label="Mulai Opname"
              ukuran="toolbar"
              onClick={() => navigate(gudang ? `/stok/opname?gudang=${gudang}&baru=1` : '/stok/opname?baru=1')}
            />
            <span className={`kartu-ringkas ${ringkasan && ringkasan.jumlah_kurang > 0 ? 'kartu-ringkas--bahaya' : ''}`}>
              Di bawah minimum: <strong>{formatAngka(ringkasan?.jumlah_kurang ?? 0)}</strong>
            </span>
            <span className="kartu-ringkas">
              Nilai persediaan: <strong>{formatRupiah(ringkasan?.nilai_persediaan ?? 0)}</strong>
            </span>
          </div>
        </div>

        <div className="alat-tabel">
          <input
            className="input-cari"
            type="search"
            placeholder="Cari SKU, barcode, atau nama produk…"
            value={cari}
            onChange={(e) => {
              setCari(e.target.value);
              setHal(1);
            }}
          />
          <select
            className="input-pilih"
            value={gudang}
            onChange={(e) => {
              setGudang(e.target.value);
              setHal(1);
            }}
            aria-label="Filter gudang"
          >
            <option value="">Semua gudang</option>
            {opsiGudang.map((o) => (
              <option key={o.id} value={o.id}>{o.label}</option>
            ))}
          </select>
          <select
            className="input-pilih"
            value={kategori}
            onChange={(e) => {
              setKategori(e.target.value);
              setHal(1);
            }}
            aria-label="Filter kategori"
          >
            <option value="">Semua kategori</option>
            {opsiKategori.map((o) => (
              <option key={o.id} value={o.id}>{o.label}</option>
            ))}
          </select>
          <label className="bidang--centang">
            <input
              type="checkbox"
              checked={kurangSaja}
              onChange={(e) => {
                setKurangSaja(e.target.checked);
                setHal(1);
              }}
            />
            <span>Di bawah minimum saja</span>
          </label>
        </div>

        <div className="tabel-bungkus">
          <table className="tabel">
            <thead>
              <tr>
                <th>SKU</th>
                <th>Produk</th>
                <th>Kategori</th>
                <th>Gudang</th>
                <th className="rata-kanan">Stok</th>
                <th className="rata-kanan">Minimum</th>
                <th className="rata-kanan">Nilai (rata-rata)</th>
                <th className="rata-tengah">Status</th>
                <th className="rata-kanan">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {sibuk && data.length === 0 ? (
                <tr><td colSpan={9} className="tabel-kosong">Memuat…</td></tr>
              ) : data.length === 0 ? (
                <tr><td colSpan={9} className="tabel-kosong">Tidak ada saldo stok{cariTunda ? ` untuk "${cariTunda}"` : ''}.</td></tr>
              ) : (
                data.map((b) => (
                  <tr key={b.id}>
                    <td>
                      <code>{b.sku}</code>
                      {b.barcode && <div className="teks-redup teks-kecil">{b.barcode}</div>}
                    </td>
                    <td>
                      <strong>{b.produk}</strong>
                    </td>
                    <td>{b.kategori ?? '—'}</td>
                    <td>{b.gudang_kode} — {b.gudang_nama}</td>
                    <td className="rata-kanan"><strong>{formatAngka(Number(b.qty))}</strong></td>
                    <td className="rata-kanan">{formatAngka(Number(b.stok_min ?? 0))}</td>
                    <td className="rata-kanan">{formatRupiah(Number(b.nilai_total ?? 0))}</td>
                    <td className="rata-tengah">
                      {Number(b.di_bawah_minimum) === 1 ? (
                        <span className="lencana lencana--bahaya">Di bawah minimum</span>
                      ) : (
                        <span className="lencana lencana--aktif">Aman</span>
                      )}
                    </td>
                    <td className="rata-kanan">
                      <Link className="tombol tombol--kecil tombol--netral" to={`/stok/kartu?product_id=${b.product_id}&gudang=${b.warehouse_id}`}>
                        Kartu Stok
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="paginasi">
          <span className="teks-redup teks-kecil">
            Hal {hal} dari {totalHal} · {total} baris · stok halaman ini {formatAngka(ringkasan?.qty_total ?? 0)} pcs · nilai {formatRupiah(ringkasan?.nilai_halaman ?? 0)}
          </span>
          <div className="paginasi__kontrol">
            <select className="input-pilih input-pilih--kecil" value={per} onChange={(e) => { setPer(Number(e.target.value)); setHal(1); }}>
              {[20, 50, 100].map((n) => (<option key={n} value={n}>{n}/hal</option>))}
            </select>
            <button type="button" className="tombol tombol--kecil" disabled={hal <= 1} onClick={() => setHal(hal - 1)}>‹ Sebelumnya</button>
            <button type="button" className="tombol tombol--kecil" disabled={hal >= totalHal} onClick={() => setHal(hal + 1)}>Berikutnya ›</button>
          </div>
        </div>
      </section>

      <section className="kartu">
        <div className="kartu__kepala">
          <div>
            <h3>Pengaturan Stok</h3>
            <p className="teks-redup teks-kecil">Berlaku untuk semua transaksi stok.</p>
          </div>
        </div>
        <div className="pengaturan-baris">
          <label className="bidang--centang">
            <input
              type="checkbox"
              checked={Boolean(pengaturan?.stok_minus_izinkan)}
              onChange={(e) => void ubahStokMinus(e.target.checked)}
            />
            <span>
              <strong>Izinkan stok minus</strong>
              <div className="teks-redup teks-kecil">Default tidak — pengeluaran melebihi saldo akan ditolak.</div>
            </span>
          </label>
          <div className="pengaturan-baris__nilai">
            <span className="teks-redup teks-kecil">Metode valuasi</span>
            <strong>Rata-rata bergerak</strong>
          </div>
        </div>
      </section>
    </div>
  );
}
