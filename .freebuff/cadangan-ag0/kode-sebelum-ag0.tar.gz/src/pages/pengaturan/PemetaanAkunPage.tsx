import { useCallback, useEffect, useState } from 'react';
import { apiGet, apiPut } from '../../lib/api';
import { beritahu } from '../../components/crud/Toast';

/** Bentuk balasan GET /api/akuntansi/pemetaan. */
interface PemetaanRespons {
  pemetaan: { peran: Record<string, string>; metode: Record<string, string> };
  ppn: { aktif: boolean; tarif: number; hargaTermasuk: boolean };
  peran: { kunci: string; label: string }[];
  metode: string[];
  akunOpsi: { id: number; kode: string; nama: string; tipe: string; aktif: number }[];
}

/** Default metode bayar → peran akun (sesuai spesifikasi Bagian B). */
const METODE_BAWAAN: Record<string, string> = {
  tunai: 'kas_kasir',
  transfer: 'bank',
  qris: 'kas_dalam_penyelesaian',
  kredit: 'piutang',
};

const LABEL_METODE: Record<string, string> = {
  tunai: 'Tunai → Kas Kasir',
  transfer: 'Transfer → Bank',
  qris: 'QRIS / EDC / e-Wallet → Kas Dalam Penyelesaian',
  kredit: 'Kredit (tempo) → Piutang Usaha',
};

/**
 * Pemetaan Akun (Pengaturan): seluruh jurnal otomatis membaca akun dari sini —
 * kode jurnal TIDAK pernah ditulis mati di rute transaksi.
 * Nilai peran = kode akun COA; nilai metode = kunci peran akun.
 */
export function PemetaanAkunPage() {
  const [data, setData] = useState<PemetaanRespons | null>(null);
  const [peran, setPeran] = useState<Record<string, string>>({});
  const [metode, setMetode] = useState<Record<string, string>>({});
  const [ppn, setPpn] = useState({ aktif: false, tarif: 11, hargaTermasuk: false });
  const [sibuk, setSibuk] = useState(false);

  const muat = useCallback(async () => {
    const r = await apiGet<PemetaanRespons>('/api/akuntansi/pemetaan');
    setData(r);
    // Metode: nilai tersimpan, atau default bila belum pernah diatur.
    const m: Record<string, string> = {};
    for (const k of r.metode) m[k] = r.pemetaan.metode[k] ?? METODE_BAWAAN[k] ?? '';
    setMetode(m);
    setPeran(r.pemetaan.peran);
    setPpn(r.ppn);
  }, []);

  useEffect(() => {
    void muat().catch((e: Error) => beritahu(e.message, 'galat'));
  }, [muat]);

  const belum = data ? data.peran.filter((p) => !peran[p.kunci]) : [];

  const simpanPemetaan = async () => {
    setSibuk(true);
    try {
      await apiPut('/api/akuntansi/pemetaan', { peran, metode });
      beritahu('Pemetaan akun disimpan. Jurnal otomatis selanjutnya memakai akun ini.', 'sukses');
      await muat();
    } catch (e) {
      beritahu((e as Error).message, 'galat');
    } finally {
      setSibuk(false);
    }
  };

  const simpanPpn = async () => {
    setSibuk(true);
    try {
      await apiPut('/api/akuntansi/ppn', {
        aktif: ppn.aktif,
        tarif: ppn.tarif,
        harga_termasuk: ppn.hargaTermasuk,
      });
      beritahu('Pengaturan PPN disimpan.', 'sukses');
      await muat();
    } catch (e) {
      beritahu((e as Error).message, 'galat');
    } finally {
      setSibuk(false);
    }
  };

  if (!data) return <div className="halaman"><p className="teks-redup">Memuat pemetaan akun…</p></div>;

  return (
    <div className="halaman">
      <section className="kartu">
        <div className="kartu__kepala">
          <h3>Pemetaan Akun</h3>
          <div className="aksi-kartu">
            <button
              type="button"
              className="tombol tombol--primer"
              disabled={sibuk || belum.length > 0}
              onClick={() => void simpanPemetaan()}
            >
              {sibuk ? 'Menyimpan…' : 'Simpan Pemetaan'}
            </button>
          </div>
        </div>
        <p className="teks-redup teks-kecil">
          Setiap peran akun dipetakan ke akun COA. Kode jurnal otomatis (POS, pembelian, retur, opname,
          tutup kasir, pelunasan) selalu dibaca dari pemetaan ini — tidak pernah ditulis mati di kode program.
          {belum.length > 0 && (
            <strong className="teks-bahaya"> Masih ada peran belum dipetakan: {belum.map((b) => b.label).join(', ')}.</strong>
          )}
        </p>

        <div className="grup-pemetaan">
          {data.peran.map((p) => (
            <label key={p.kunci} className="baris-pemetaan">
              <span className="baris-pemetaan__label">{p.label}</span>
              <select
                className="input-pilih"
                value={peran[p.kunci] ?? ''}
                onChange={(e) => setPeran({ ...peran, [p.kunci]: e.target.value })}
              >
                <option value="">— pilih akun —</option>
                {data.akunOpsi.map((a) => (
                  <option key={a.id} value={a.kode} disabled={Number(a.aktif) === 0}>
                    {a.kode} · {a.nama}{Number(a.aktif) === 0 ? ' (nonaktif)' : ''}
                  </option>
                ))}
              </select>
            </label>
          ))}
        </div>

        <h4 style={{ marginTop: 16 }}>Metode Bayar → Peran Akun</h4>
        <div className="grup-pemetaan">
          {data.metode.map((k) => (
            <label key={k} className="baris-pemetaan">
              <span className="baris-pemetaan__label">{LABEL_METODE[k] ?? k}</span>
              <select
                className="input-pilih"
                value={metode[k] ?? ''}
                onChange={(e) => setMetode({ ...metode, [k]: e.target.value })}
              >
                {data.peran.map((p) => (
                  <option key={p.kunci} value={p.kunci}>{p.label}</option>
                ))}
              </select>
            </label>
          ))}
        </div>
      </section>

      <section className="kartu">
        <div className="kartu__kepala">
          <h3>Pengaturan PPN</h3>
          <div className="aksi-kartu">
            <button type="button" className="tombol tombol--primer" disabled={sibuk} onClick={() => void simpanPpn()}>
              {sibuk ? 'Menyimpan…' : 'Simpan PPN'}
            </button>
          </div>
        </div>
        <p className="teks-redup teks-kecil">
          Nonaktifkan bila toko bukan PKP. Tarif dan cara perhitungan harga mengikuti pengaturan ini di
          seluruh dokumen penjualan/pembelian.
        </p>
        <div className="form-grid">
          <label className="baris-pemetaan">
            <span className="baris-pemetaan__label">Status PKP (PPN aktif)</span>
            <input
              type="checkbox"
              checked={ppn.aktif}
              onChange={(e) => setPpn({ ...ppn, aktif: e.target.checked })}
            />
          </label>
          <label>
            Tarif PPN (%)
            <input
              type="number"
              min={0}
              max={100}
              className="input-cari"
              value={ppn.tarif}
              onChange={(e) => setPpn({ ...ppn, tarif: Number(e.target.value) })}
            />
          </label>
          <label className="baris-pemetaan">
            <span className="baris-pemetaan__label">Harga sudah termasuk PPN</span>
            <input
              type="checkbox"
              checked={ppn.hargaTermasuk}
              onChange={(e) => setPpn({ ...ppn, hargaTermasuk: e.target.checked })}
            />
          </label>
        </div>
      </section>
    </div>
  );
}
