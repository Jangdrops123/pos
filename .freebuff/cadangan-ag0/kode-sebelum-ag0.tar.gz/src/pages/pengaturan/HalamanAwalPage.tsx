import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { beritahu } from '../../components/crud/Toast';
import { IconButton } from '../../components/IconButton';
import { Modal } from '../../components/crud/Modal';
import { apiDelete, apiGet, apiPost, apiPut } from '../../lib/api';
import { useSesi } from '../../lib/sesi';
import {
  halamanAwalSemua,
  modePosTerakhir,
  namaPeran,
  peranAktif,
  setHalamanAwal,
  setModePosTerakhir,
  type HalamanAwal,
  type ModePos,
  type Peran,
} from '../../lib/pengguna';

const PERAN_LIST: Peran[] = ['admin', 'manajer', 'akuntan', 'kasir', 'gudang'];

const HALAMAN_OPSI: { nilai: HalamanAwal; teks: string }[] = [
  { nilai: 'dashboard', teks: 'Dashboard' },
  { nilai: 'pos', teks: 'POS (mode terakhir)' },
  { nilai: 'penjualan', teks: 'Penjualan (riwayat)' },
];

const MODE_OPSI: { nilai: ModePos; teks: string }[] = [
  { nilai: 'cepat', teks: 'POS Mode Tanpa Foto (bawaan)' },
  { nilai: 'foto', teks: 'POS Mode Foto' },
];

/** Label modul matriks (kunci = role_permissions.menu). */
const LABEL_MODUL: Record<string, string> = {
  penjualan: 'Penjualan (riwayat)',
  pos: 'POS (Penjualan)',
  pembelian: 'Pembelian / Inbound',
  stok: 'Stok (Persediaan)',
  opname: 'Opname',
  'persediaan-sub': 'Item Masuk / Keluar',
  dokumen: 'Daftar Dokumen',
  akuntansi: 'Akuntansi',
  laporan: 'Laporan',
  master: 'Master Data (produk, pelanggan, …)',
  pengaturan: 'Pengaturan',
  'proses-tahunan': 'Proses Tahunan',
};

/** Label kolom matriks. Kolom Lihat = modul tampil di sidebar peran ini. */
const LABEL_AKSI: Record<string, string> = {
  lihat: 'Lihat (sidebar)',
  tambah: 'Tambah',
  ubah: 'Ubah',
  hapus: 'Hapus',
  cetak: 'Cetak',
  ekspor: 'Ekspor',
  impor: 'Impor',
  sahkan: 'Sahkan / Batalkan',
};

interface Khusus {
  lihat_hpp: number;
  ubah_harga_kasir: number;
  diskon_maks: number;
  hapus_transaksi: number;
  proses_tahunan: number;
}

interface PeranRow {
  id: number;
  nama: string;
  bawaan: boolean;
  cakupan_toko: string[] | null;
  jumlah_pengguna: number;
  /** Record modul → daftar aksi koma-separated ("lihat,tambah,…"). */
  hak: Record<string, string>;
  khusus: Khusus;
}

interface BalasanPeran {
  data: PeranRow[];
  modul: string[];
  aksi: string[];
  toko: { kode: string; nama: string }[];
}

/**
 * TAHAP 2 — Pengaturan ▸ "Halaman Awal & Peran":
 *  1. daftar peran + tambah/ubah nama/hapus peran (Admin),
 *  2. matriks Hak Akses per peran (modul × aksi — kolom "Lihat" mengontrol
 *     sidebar), 3. Hak Khusus (HPP, ubah harga kasir, batas diskon %,
 *     hapus transaksi, Proses Tahunan) + cakupan toko/gudang — satu Simpan
 *     langsung berlaku tanpa login ulang,
 *  4. halaman awal setelah login per peran + mode POS terakhir.
 * Peran TIDAK lagi dipilih manual di sini — peran datang dari sesi Log In.
 */
export function HalamanAwalPage() {
  const info = useSesi().info;
  const admin = info?.pengguna.admin ?? false;

  const [balasan, setBalasan] = useState<BalasanPeran | null>(null);
  const [galat, setGalat] = useState<string | null>(null);
  const [terpilihId, setTerpilihId] = useState<number | null>(null);
  const [hak, setHak] = useState<Record<string, string[]>>({});
  const [khusus, setKhusus] = useState({
    lihat_hpp: true,
    ubah_harga_kasir: true,
    diskon_maks: 100,
    hapus_transaksi: true,
    proses_tahunan: false,
  });
  const [cakupan, setCakupan] = useState<string[]>([]);
  const [kotor, setKotor] = useState(false);
  const [sibuk, setSibuk] = useState(false);

  const [formPeran, setFormPeran] = useState<{ id: number | null; nama: string; galat: string | null } | null>(null);
  const [hapusTarget, setHapusTarget] = useState<PeranRow | null>(null);

  const [halaman, setHalaman] = useState(() => halamanAwalSemua());
  const [modePos, setModePos] = useState<ModePos>(() => modePosTerakhir());

  const muat = useCallback(async () => {
    try {
      const r = await apiGet<BalasanPeran>('/api/pengguna/peran');
      setBalasan(r);
      setGalat(null);
      setTerpilihId((id) => (id !== null && r.data.some((x) => x.id === id) ? id : (r.data[0]?.id ?? null)));
    } catch (e) {
      setGalat(e instanceof Error ? e.message : 'Gagal memuat peran & hak akses.');
    }
  }, []);

  useEffect(() => {
    void muat();
  }, [muat]);

  // Muat matriks per peran yang dipilih.
  useEffect(() => {
    const row = balasan?.data.find((r) => r.id === terpilihId);
    if (!row || !balasan) return;
    const h: Record<string, string[]> = {};
    for (const m of balasan.modul) {
      const flat = row.hak[m];
      h[m] = flat ? flat.split(',').filter(Boolean) : [];
    }
    setHak(h);
    setKhusus({
      lihat_hpp: row.khusus.lihat_hpp === 1,
      ubah_harga_kasir: row.khusus.ubah_harga_kasir === 1,
      diskon_maks: Number(row.khusus.diskon_maks) || 0,
      hapus_transaksi: row.khusus.hapus_transaksi === 1,
      proses_tahunan: row.khusus.proses_tahunan === 1,
    });
    setCakupan(row.cakupan_toko ?? []);
    setKotor(false);
  }, [balasan, terpilihId]);

  const peranTerpilih = balasan?.data.find((r) => r.id === terpilihId) ?? null;

  /* ------------------------------ matriks ------------------------------ */

  function toggleAksi(modul: string, aksi: string) {
    setHak((h) => {
      const kini = h[modul] ?? [];
      const baru = kini.includes(aksi) ? kini.filter((x) => x !== aksi) : [...kini, aksi];
      return { ...h, [modul]: baru };
    });
    setKotor(true);
  }

  function toggleBaris(modul: string, aktif: boolean) {
    setHak((h) => ({ ...h, [modul]: aktif ? [...balasan!.aksi] : [] }));
    setKotor(true);
  }

  /** Pilih semua per KOLOM: centang/batal satu aksi di seluruh modul. */
  function toggleKolom(aksi: string, aktif: boolean) {
    setHak((h) => {
      const baru: Record<string, string[]> = {};
      for (const m of balasan!.modul) {
        const kini = h[m] ?? [];
        baru[m] = aktif
          ? kini.includes(aksi)
            ? kini
            : [...kini, aksi]
          : kini.filter((x) => x !== aksi);
      }
      return { ...h, ...baru };
    });
    setKotor(true);
  }

  async function simpan() {
    if (terpilihId === null || sibuk) return;
    setSibuk(true);
    try {
      const r = await apiPut<{ pesan: string }>(`/api/pengguna/matriks/${terpilihId}`, {
        hak,
        khusus,
        cakupan_toko: cakupan,
      });
      beritahu(r.pesan, 'sukses');
      setKotor(false);
      await muat();
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Gagal menyimpan hak akses.', 'galat');
    } finally {
      setSibuk(false);
    }
  }

  /* ------------------------------- peran ------------------------------- */

  async function simpanPeran(e: FormEvent) {
    e.preventDefault();
    if (!formPeran || sibuk) return;
    const nama = formPeran.nama.trim();
    if (!nama) {
      setFormPeran({ ...formPeran, galat: 'Nama peran wajib diisi.' });
      return;
    }
    setSibuk(true);
    try {
      const r =
        formPeran.id === null
          ? await apiPost<{ pesan: string }>('/api/pengguna/peran', { nama })
          : await apiPut<{ pesan: string }>(`/api/pengguna/peran/${formPeran.id}`, { nama });
      beritahu(r.pesan, 'sukses');
      setFormPeran(null);
      await muat();
    } catch (err) {
      setFormPeran({ ...formPeran, galat: err instanceof Error ? err.message : 'Gagal menyimpan peran.' });
    } finally {
      setSibuk(false);
    }
  }

  async function hapusPeran() {
    if (!hapusTarget || sibuk) return;
    setSibuk(true);
    try {
      const r = await apiDelete<{ pesan: string }>(`/api/pengguna/peran/${hapusTarget.id}`);
      beritahu(r.pesan, 'sukses');
      setHapusTarget(null);
      await muat();
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Gagal menghapus peran.', 'galat');
    } finally {
      setSibuk(false);
    }
  }

  /* --------------------------- halaman awal ---------------------------- */

  const gantiHalaman = (p: Peran, h: HalamanAwal) => {
    setHalaman((prev) => ({ ...prev, [p]: h }));
    setHalamanAwal(p, h);
    const teks = HALAMAN_OPSI.find((o) => o.nilai === h)?.teks ?? h;
    beritahu(`Halaman awal ${namaPeran(p)}: ${teks}.`, 'sukses', 3000);
  };

  const gantiModePos = (m: ModePos) => {
    setModePos(m);
    setModePosTerakhir(m);
    beritahu('Mode POS terakhir diperbarui — tombol POS/F9 memakai mode ini.', 'sukses', 3000);
  };

  if (galat) {
    return (
      <section className="kartu">
        <div className="kartu__kepala">
          <h3>Halaman Awal &amp; Peran</h3>
        </div>
        <p className="login-pesan login-pesan--galat" role="alert">
          {galat}
        </p>
        <div className="tombol-baris">
          <button type="button" className="tombol" onClick={() => void muat()}>
            Coba lagi
          </button>
        </div>
      </section>
    );
  }

  return (
    <div>
      {/* 1 — Daftar peran + CRUD */}
      <section className="kartu" style={{ marginBottom: 14 }}>
        <div className="kartu__kepala">
          <div>
            <h3>Peran</h3>
            <p className="teks-redup teks-kecil">
              Peran sesi: <strong>{info?.pengguna.peranNama ?? namaPeran(peranAktif())}</strong> ({info?.pengguna.username ?? '—'}) —
              peran ditentukan saat Log In. Pilih peran untuk mengatur hak aksesnya di bawah.
            </p>
          </div>
          <div className="tombol-baris">
            <button
              type="button"
              className="tombol tombol--primer tombol--kecil"
              disabled={!admin}
              title={admin ? undefined : 'Hanya Admin yang boleh mengelola peran.'}
              onClick={() => setFormPeran({ id: null, nama: '', galat: null })}
            >
              + Tambah Peran
            </button>
          </div>
        </div>
        {!balasan ? (
          <p className="teks-redup">Memuat peran…</p>
        ) : (
          <table className="aturan-tabel">
            <thead>
              <tr>
                <th style={{ width: 34 }} />
                <th>Peran</th>
                <th>Pengguna</th>
                <th>Cakupan toko</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {balasan.data.map((r) => (
                <tr key={r.id} style={r.id === terpilihId ? { background: 'var(--primer-lembut)' } : undefined}>
                  <td>
                    <input
                      type="radio"
                      name="peran-terpilih"
                      aria-label={`Pilih peran ${r.nama}`}
                      checked={r.id === terpilihId}
                      onChange={() => setTerpilihId(r.id)}
                    />
                  </td>
                  <td>
                    <strong>{r.nama}</strong>
                    {r.bawaan && <span className="lencana lencana--netral" style={{ marginLeft: 6 }}>Bawaan</span>}
                  </td>
                  <td>{r.jumlah_pengguna}</td>
                  <td>{r.cakupan_toko?.length ? r.cakupan_toko.join(', ') : 'Semua toko'}</td>
                  <td>
                    <span className="aksi-baris">
                      <IconButton
                        label={`Ubah nama ${r.nama}`}
                        ikon="pencil"
                        disabled={!admin}
                        alasan={admin ? undefined : 'Hanya Admin'}
                        onClick={() => setFormPeran({ id: r.id, nama: r.nama, galat: null })}
                      />
                      <IconButton
                        label={`Hapus ${r.nama}`}
                        ikon="trash"
                        warna="bahaya"
                        disabled={!admin}
                        alasan={admin ? undefined : 'Hanya Admin'}
                        onClick={() => setHapusTarget(r)}
                      />
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      {/* 2 — Matriks hak akses */}
      <section className="kartu" style={{ marginBottom: 14 }}>
        <div className="kartu__kepala">
          <div>
            <h3>Hak Akses — {peranTerpilih?.nama ?? '…'}</h3>
            <p className="teks-redup teks-kecil">
              Kolom <strong>Lihat (sidebar)</strong> menentukan modul mana (Master Data, Stok/Persediaan,
              Pembelian, Penjualan/POS, Laporan, Pengaturan, …) yang tampil di sidebar peran ini — URL langsung
              pun ikut diblokir bila dicentang kosong.
            </p>
          </div>
          {admin && kotor && (
            <div className="tombol-baris">
              <button type="button" className="tombol tombol--primer" disabled={sibuk} onClick={() => void simpan()}>
                {sibuk ? 'Menyimpan…' : 'Simpan Perubahan'}
              </button>
            </div>
          )}
        </div>
        {!admin && (
          <p className="teks-redup">
            Mode lihat saja — hanya Admin yang boleh mengubah Hak Akses, Hak Khusus, dan cakupan toko.
          </p>
        )}
        {!balasan || !peranTerpilih ? (
          <p className="teks-redup">Memuat matriks…</p>
        ) : (
          <div className="matriks-akses">
            <table className="aturan-tabel">
              <thead>
                <tr>
                  <th>Modul</th>
                  {balasan.aksi.map((a) => {
                    const semuaKolom = balasan.modul.every((m) => (hak[m] ?? []).includes(a));
                    return (
                      <th key={a}>
                        <label
                          className="login-ingat"
                          style={{ margin: 0, gap: 4 }}
                          title={`Pilih semua — ${LABEL_AKSI[a] ?? a}`}
                        >
                          <input
                            type="checkbox"
                            aria-label={`Pilih semua kolom ${LABEL_AKSI[a] ?? a}`}
                            checked={semuaKolom}
                            disabled={!admin}
                            onChange={(e) => toggleKolom(a, e.target.checked)}
                          />
                          <span>{LABEL_AKSI[a] ?? a}</span>
                        </label>
                      </th>
                    );
                  })}
                  <th>Semua</th>
                </tr>
              </thead>
              <tbody>
                {balasan.modul.map((m) => {
                  const isi = hak[m] ?? [];
                  const semua = balasan.aksi.every((a) => isi.includes(a));
                  return (
                    <tr key={m}>
                      <td>{LABEL_MODUL[m] ?? m}</td>
                      {balasan.aksi.map((a) => (
                        <td key={a}>
                          <input
                            type="checkbox"
                            aria-label={`${LABEL_MODUL[m] ?? m} — ${LABEL_AKSI[a] ?? a}`}
                            checked={isi.includes(a)}
                            disabled={!admin}
                            onChange={() => toggleAksi(m, a)}
                          />
                        </td>
                      ))}
                      <td>
                        <input
                          type="checkbox"
                          aria-label={`Semua aksi ${LABEL_MODUL[m] ?? m}`}
                          checked={semua}
                          disabled={!admin}
                          onChange={(e) => toggleBaris(m, e.target.checked)}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* 3 — Hak khusus + cakupan toko */}
      <section className="kartu" style={{ marginBottom: 14 }}>
        <div className="kartu__kepala">
          <div>
            <h3>Hak Khusus &amp; Cakupan Toko — {peranTerpilih?.nama ?? '…'}</h3>
            <p className="teks-redup teks-kecil">Berlaku langsung untuk seluruh pengguna peran ini.</p>
          </div>
          {admin && (
            <div className="tombol-baris">
              <button
                type="button"
                className="tombol tombol--primer"
                disabled={!kotor || sibuk}
                onClick={() => void simpan()}
              >
                {sibuk ? 'Menyimpan…' : kotor ? 'Simpan Perubahan' : 'Tersimpan'}
              </button>
            </div>
          )}
        </div>
        <div className="form-grid">
          <label className="login-ingat">
            <input
              type="checkbox"
              checked={khusus.lihat_hpp}
              disabled={!admin}
              onChange={(e) => {
                setKhusus({ ...khusus, lihat_hpp: e.target.checked });
                setKotor(true);
              }}
            />
            <span>Lihat harga beli / HPP</span>
          </label>
          <label className="login-ingat">
            <input
              type="checkbox"
              checked={khusus.ubah_harga_kasir}
              disabled={!admin}
              onChange={(e) => {
                setKhusus({ ...khusus, ubah_harga_kasir: e.target.checked });
                setKotor(true);
              }}
            />
            <span>Boleh mengubah harga jual di kasir</span>
          </label>
          <label className="login-ingat">
            <input
              type="checkbox"
              checked={khusus.hapus_transaksi}
              disabled={!admin}
              onChange={(e) => {
                setKhusus({ ...khusus, hapus_transaksi: e.target.checked });
                setKotor(true);
              }}
            />
            <span>Hapus / batalkan transaksi</span>
          </label>
          <label className="login-ingat">
            <input
              type="checkbox"
              checked={khusus.proses_tahunan}
              disabled
              title="Proses Tahunan hanya untuk Admin."
              onChange={() => undefined}
            />
            <span>Proses Tahunan (hanya Admin)</span>
          </label>
          <label className="bidang" style={{ maxWidth: 220 }}>
            <span>Batas diskon kasir (%)</span>
            <input
              type="number"
              min={0}
              max={100}
              value={khusus.diskon_maks}
              disabled={!admin}
              onChange={(e) => {
                setKhusus({ ...khusus, diskon_maks: Math.max(0, Math.min(100, Number(e.target.value) || 0)) });
                setKotor(true);
              }}
            />
          </label>
        </div>

        {balasan && balasan.toko.length > 0 && (
          <div className="bidang" style={{ marginTop: 12 }}>
            <span>Cakupan toko/gudang (kosongkan semua = semua toko)</span>
            <div className="tombol-baris">
              {balasan.toko.map((t) => (
                <label key={t.kode} className="login-ingat" style={{ marginRight: 12 }}>
                  <input
                    type="checkbox"
                    checked={cakupan.includes(t.kode)}
                    disabled={!admin}
                    onChange={(e) => {
                      setCakupan((c) => (e.target.checked ? [...c, t.kode] : c.filter((x) => x !== t.kode)));
                      setKotor(true);
                    }}
                  />
                  <span>{t.nama}</span>
                </label>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* 4 — Halaman awal setelah login */}
      <section className="kartu" style={{ marginBottom: 14 }}>
        <div className="kartu__kepala">
          <div>
            <h3>Halaman awal setelah login</h3>
            <p className="teks-redup teks-kecil">
              Halaman yang dibuka pertama kali untuk tiap peran — berlaku saat aplikasi dimuat.
            </p>
          </div>
        </div>
        <table className="aturan-tabel">
          <thead>
            <tr>
              <th>Peran</th>
              <th>Halaman awal</th>
            </tr>
          </thead>
          <tbody>
            {PERAN_LIST.map((p) => (
              <tr key={p}>
                <td>{namaPeran(p)}</td>
                <td>
                  <select
                    className="input-pilih"
                    value={halaman[p]}
                    onChange={(e) => gantiHalaman(p, e.target.value as HalamanAwal)}
                    aria-label={`Halaman awal ${namaPeran(p)}`}
                  >
                    {HALAMAN_OPSI.map((o) => (
                      <option key={o.nilai} value={o.nilai}>
                        {o.teks}
                      </option>
                    ))}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {/* 5 — Mode POS terakhir */}
      <section className="kartu">
        <div className="kartu__kepala">
          <div>
            <h3>Mode POS terakhir</h3>
            <p className="teks-redup teks-kecil">
              Dipakai tombol “Transaksi Baru (POS)”, tombol keranjang di topbar, dan pintasan F9.
            </p>
          </div>
        </div>
        <label className="bidang" style={{ maxWidth: 360 }}>
          <span>Mode POS bawaan</span>
          <select className="input-pilih" value={modePos} onChange={(e) => gantiModePos(e.target.value as ModePos)}>
            {MODE_OPSI.map((o) => (
              <option key={o.nilai} value={o.nilai}>
                {o.teks}
              </option>
            ))}
          </select>
          <small className="teks-redup">Pilihan juga diperbarui otomatis setiap kali sebuah mode POS dibuka.</small>
        </label>
      </section>

      {/* Form tambah/ubah nama peran */}
      {formPeran && (
        <Modal
          judul={formPeran.id === null ? 'Tambah Peran' : 'Ubah Nama Peran'}
          lebar="kecil"
          onTutup={() => setFormPeran(null)}
          sedangKirim={sibuk}
          aksi={
            <>
              <button type="button" className="tombol tombol--netral" onClick={() => setFormPeran(null)} disabled={sibuk}>
                Batal
              </button>
              <button type="submit" form="form-peran" className="tombol tombol--primer" disabled={sibuk}>
                {sibuk ? 'Menyimpan…' : 'Simpan'}
              </button>
            </>
          }
        >
          <form id="form-peran" onSubmit={(e) => void simpanPeran(e)}>
            <label className="bidang">
              <span>Nama peran *</span>
              <input
                data-fokus-awal
                value={formPeran.nama}
                onChange={(e) => setFormPeran({ ...formPeran, nama: e.target.value })}
                disabled={sibuk}
                required
              />
            </label>
            <p className="teks-redup teks-kecil">
              Peran baru mulai dengan hak akses KOSONG (default deny) — buka matriks di bawah lalu centang modul
              yang boleh ia akses.
            </p>
            {formPeran.galat && (
              <p className="login-pesan login-pesan--galat" role="alert">
                {formPeran.galat}
              </p>
            )}
          </form>
        </Modal>
      )}

      {/* Konfirmasi hapus peran */}
      {hapusTarget && (
        <Modal
          judul="Hapus peran"
          lebar="kecil"
          onTutup={() => setHapusTarget(null)}
          sedangKirim={sibuk}
          aksi={
            <>
              <button type="button" className="tombol tombol--netral" onClick={() => setHapusTarget(null)} disabled={sibuk}>
                Batal
              </button>
              <button type="button" className="tombol tombol--bahaya" onClick={() => void hapusPeran()} disabled={sibuk}>
                {sibuk ? 'Menghapus…' : 'Hapus peran'}
              </button>
            </>
          }
        >
          <p>
            Hapus peran <strong>{hapusTarget.nama}</strong>?
            {hapusTarget.jumlah_pengguna > 0 &&
              ` Peran ini masih dipakai ${hapusTarget.jumlah_pengguna} pengguna — pindahkan mereka ke peran lain dulu (server menolak selama masih dipakai).`}
          </p>
          <p className="teks-redup">Matriks hak akses &amp; hak khusus peran ini ikut dihapus.</p>
        </Modal>
      )}
    </div>
  );
}
