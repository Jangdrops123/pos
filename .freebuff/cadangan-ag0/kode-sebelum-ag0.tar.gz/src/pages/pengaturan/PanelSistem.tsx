import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { beritahu } from '../../components/crud/Toast';
import { IconButton } from '../../components/IconButton';
import { Modal } from '../../components/crud/Modal';
import { apiDelete, apiGet, apiPost, apiPut } from '../../lib/api';
import { formatAngka, formatTanggalPanjang } from '../../lib/format';
import { useIdentitas } from '../../lib/identitas';
import { useSesi } from '../../lib/sesi';
import { IndikatorSandi } from '../auth/IndikatorSandi';
import type { DaftarPengaturan } from './tipePengaturan';
import { PanelResetData } from './PanelResetData';

const fmtUkuran = (b: number): string =>
  b >= 1_048_576 ? `${(b / 1_048_576).toFixed(1)} MB` : b >= 1024 ? `${(b / 1024).toFixed(1)} KB` : `${b} B`;

/** Panel data yang belum tersedia — menampilkan petunjuk, bukan galat. */
function Kosong({ judul, pesan }: { judul: string; pesan: string }) {
  return (
    <section className="kartu">
      <div className="kartu__kepala">
        <h3>{judul}</h3>
      </div>
      <p className="teks-redup">{pesan}</p>
    </section>
  );
}

/* =================== Grup Keuangan ▸ Kas & Bank ======================= */

interface RekKas {
  id: number;
  kode: string;
  nama: string;
  jenis: 'kas' | 'bank' | 'e-wallet';
  aktif: number;
}

interface MetodeBayar {
  metode: string;
  cash_account_id: number;
  akun_nama: string;
}

const JENIS_LABEL: Record<string, string> = { kas: 'Kas', bank: 'Bank', 'e-wallet': 'E-Wallet' };
const METODE_LABEL: Record<string, string> = { tunai: 'Tunai', transfer: 'Transfer', qris: 'QRIS / EDC' };

/**
 * Kas & Bank (Akuntansi Dasar): rekening bawaan per metode bayar (tunai/
 * transfer/qris → rekening kas) — penjualan tunai & pembayaran piutang/hutang
 * otomatis memakai rekening ini. Kategori biaya & pemasukan juga dikelola di
 * halaman Akuntansi ▸ Pengeluaran / Pemasukan Lain.
 */
export function PanelKasBank({ nilai }: { nilai: Record<string, unknown> }) {
  const [rek, setRek] = useState<RekKas[]>([]);
  const [metode, setMetode] = useState<MetodeBayar[]>([]);
  const [sibuk, setSibuk] = useState(false);
  const daftarMetode = Array.isArray(nilai.metode_bayar) ? (nilai.metode_bayar as string[]) : ['tunai', 'transfer', 'qris'];

  const muat = useCallback(async () => {
    const r = await apiGet<{ data: RekKas[] }>('/api/akuntansi/kas/akun').catch(() => ({ data: [] as RekKas[] }));
    setRek(r.data.filter((a) => a.aktif !== 0));
    const m = await apiGet<{ data: MetodeBayar[] }>('/api/akuntansi/metode-bayar').catch(() => ({ data: [] as MetodeBayar[] }));
    setMetode(m.data);
  }, []);

  useEffect(() => {
    void muat();
  }, [muat]);

  const simpanMetode = async (m: string, akunId: number) => {
    setSibuk(true);
    try {
      await apiPut('/api/akuntansi/metode-bayar', { metode: m, akun_id: akunId });
      beritahu(`Metode bayar "${METODE_LABEL[m] ?? m}" ditautkan ke rekening.`);
      await muat();
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Gagal menyimpan pemetaan metode bayar.', 'galat');
    } finally {
      setSibuk(false);
    }
  };

  if (rek.length === 0) {
    return (
      <Kosong
        judul="Rekening Kas & Bank"
        pesan="Belum ada rekening kas/bank. Tambahkan lewat Akuntansi ▸ Kas & Bank — penjualan tunai dan pembayaran piutang/hutang otomatis memakai rekening sesuai metode bayar."
      />
    );
  }

  return (
    <section className="kartu">
      <div className="kartu__kepala">
        <h3>Rekening per Metode Bayar</h3>
        <Link to="/akuntansi/kas" className="teks-redup">
          Kelola rekening di Kas &amp; Bank →
        </Link>
      </div>
      <p className="teks-redup">
        Penjualan tunai &amp; pembayaran piutang menambah Kas Masuk; pembelian &amp; pembayaran hutang menjadi Kas Keluar —
        memakai rekening di bawah ini sesuai metode bayar.
      </p>
      <div className="form-grid">
        {daftarMetode.map((m) => {
          const aktif = metode.find((x) => x.metode === m)?.cash_account_id ?? '';
          return (
            <div className="bidang" key={m}>
              <label htmlFor={`mb-${m}`}>{METODE_LABEL[m] ?? m}</label>
              <select
                id={`mb-${m}`}
                value={aktif}
                disabled={sibuk}
                onChange={(e) => void simpanMetode(m, Number(e.target.value))}
              >
                <option value="">— pilih rekening —</option>
                {rek.map((a) => (
                  <option key={a.id} value={a.id}>{a.kode} · {a.nama}</option>
                ))}
              </select>
            </div>
          );
        })}
      </div>
      <h4 className="teks-redup" style={{ marginTop: 14 }}>Rekening kas/bank aktif</h4>
      <table className="aturan-tabel">
        <thead>
          <tr>
            <th>Kode</th>
            <th>Nama</th>
            <th>Jenis</th>
          </tr>
        </thead>
        <tbody>
          {rek.map((a) => (
            <tr key={a.id}>
              <td><strong>{a.kode}</strong></td>
              <td>{a.nama}</td>
              <td>{JENIS_LABEL[a.jenis] ?? a.jenis}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}

/* ================= Grup Keamanan & Sistem ▸ 16. Keamanan ================ */

interface BarisSesi {
  id: number;
  perangkat: string | null;
  terakhir: string;
  ip: string | null;
  nama: string;
  username: string;
}

interface StatusKode {
  ada: boolean;
  dibuat: number;
  sisa: number;
  waktu: string | null;
}

/**
 * TAHAP 1 & 2 — Keamanan:
 *  • daftar sesi/perangkat aktif + Keluar Paksa per sesi (ada penanda
 *    "Sesi ini" supaya Admin tidak salah mengeluarkan dirinya sendiri),
 *  • Kode Pemulihan Admin utama: 10 kode sekali pakai — tampil SEKALI saat
 *    dibuat, dengan salin/unduh.
 */
export function PanelKeamanan() {
  const { info } = useSesi();
  const sesiSaya = info?.sesiId ?? null;
  const admin = info?.pengguna.admin ?? false;

  const [baris, setBaris] = useState<BarisSesi[] | null>(null);
  const [status, setStatus] = useState<StatusKode | null>(null);
  const [kodeBaru, setKodeBaru] = useState<string[] | null>(null);
  const [keluarTarget, setKeluarTarget] = useState<BarisSesi | null>(null);
  const [sibuk, setSibuk] = useState(false);

  const muat = useCallback(async () => {
    try {
      const r = await apiGet<{ data: BarisSesi[] }>('/api/pengaturan/keamanan/sesi');
      setBaris(r.data);
    } catch {
      setBaris([]);
    }
    try {
      setStatus(await apiGet<StatusKode>('/api/pengaturan/keamanan/kode-pemulihan'));
    } catch {
      setStatus(null);
    }
  }, []);

  useEffect(() => {
    void muat();
  }, [muat]);

  async function keluarkan(b: BarisSesi) {
    setSibuk(true);
    try {
      const r = await apiDelete<{ pesan: string }>(`/api/pengaturan/keamanan/sesi/${b.id}`);
      beritahu(r.pesan);
      setKeluarTarget(null);
      await muat();
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Gagal mengeluarkan sesi.', 'galat');
    } finally {
      setSibuk(false);
    }
  }

  async function buatKode() {
    setSibuk(true);
    try {
      const r = await apiPost<{ kode: string[]; pesan: string }>('/api/pengaturan/keamanan/kode-pemulihan', {});
      setKodeBaru(r.kode);
      beritahu(r.pesan);
      await muat();
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Gagal membuat Kode Pemulihan.', 'galat');
    } finally {
      setSibuk(false);
    }
  }

  async function salinKode() {
    try {
      await navigator.clipboard.writeText((kodeBaru ?? []).join('\n'));
      beritahu('Kesepuluh kode disalin ke papan klip.');
    } catch {
      beritahu('Peramban menolak papan klip — gunakan tombol Unduh.', 'galat');
    }
  }

  function unduhKode() {
    const isi =
      `Kode Pemulihan — ${formatTanggalPanjang(new Date().toISOString())}\n\n` +
      `${(kodeBaru ?? []).join('\n')}\n\n` +
      'Simpan di tempat aman. Tiap kode hanya bisa dipakai sekali untuk menyetel ulang password Admin utama.\n';
    const url = URL.createObjectURL(new Blob([isi], { type: 'text/plain;charset=utf-8' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = 'kode-pemulihan.txt';
    a.click();
    URL.revokeObjectURL(url);
  }

  if (baris === null) return <p className="teks-redup">Memuat sesi…</p>;

  return (
    <>
      <section className="kartu">
        <div className="kartu__kepala">
          <h3>Perangkat &amp; Sesi Aktif</h3>
          <span className="teks-redup">Keluarkan paksa perangkat yang tidak dikenali.</span>
        </div>
        {baris.length === 0 ? (
          <p className="teks-redup">Belum ada sesi aktif — tidak ada perangkat yang sedang masuk saat ini.</p>
        ) : (
          <table className="aturan-tabel">
            <thead>
              <tr>
                <th>Pengguna</th>
                <th>Perangkat</th>
                <th>Alamat IP</th>
                <th>Terakhir aktif</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {baris.map((s) => (
                <tr key={s.id}>
                  <td>
                    <strong>{s.nama}</strong>
                    <div className="teks-redup teks-kecil">{s.username}</div>
                  </td>
                  <td>
                    {s.perangkat ?? '—'}
                    {s.id === sesiSaya && (
                      <span className="lencana lencana--aktif" style={{ marginLeft: 6 }}>
                        Sesi ini
                      </span>
                    )}
                  </td>
                  <td>{s.ip ?? '—'}</td>
                  <td>{formatTanggalPanjang(s.terakhir)}</td>
                  <td>
                    <IconButton
                      label={s.id === sesiSaya ? 'Keluar dari sesi ini' : 'Keluarkan paksa'}
                      ikon="power"
                      onClick={() => setKeluarTarget(s)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      <section className="kartu">
        <div className="kartu__kepala">
          <h3>Kode Pemulihan Admin</h3>
          {admin ? (
            <button type="button" className="tombol tombol--kecil" disabled={sibuk} onClick={() => void buatKode()}>
              {sibuk ? 'Membuat…' : 'Buat 10 kode baru'}
            </button>
          ) : (
            <span className="teks-redup">Hanya Admin yang bisa membuat kode baru.</span>
          )}
        </div>
        <p className="teks-redup">
          Kode Pemulihan dipakai saat lupa password dan email/WhatsApp belum tersambung: masukkan satu kode di
          halaman Lupa password untuk membuat password baru. Membuat kode baru otomatis membatalkan kode lama.
        </p>
        {status === null ? (
          <p className="teks-redup">Status kode belum tersedia.</p>
        ) : (
          <dl className="info-sistem">
            <div>
              <dt>Pernah dibuat</dt>
              <dd>{status.ada ? `${status.dibuat} kode` : 'Belum pernah'}</dd>
            </div>
            <div>
              <dt>Sisa belum dipakai</dt>
              <dd>{status.sisa}</dd>
            </div>
            <div>
              <dt>Dibuat terakhir</dt>
              <dd>{status.waktu ? formatTanggalPanjang(status.waktu) : '—'}</dd>
            </div>
          </dl>
        )}
      </section>

      {keluarTarget && (
        <Modal
          judul="Keluarkan sesi"
          lebar="kecil"
          onTutup={() => setKeluarTarget(null)}
          sedangKirim={sibuk}
          aksi={
            <>
              <button type="button" className="tombol tombol--netral" onClick={() => setKeluarTarget(null)} disabled={sibuk}>
                Batal
              </button>
              <button type="button" className="tombol tombol--bahaya" onClick={() => void keluarkan(keluarTarget)} disabled={sibuk}>
                {sibuk ? 'Mengeluarkan…' : 'Keluarkan'}
              </button>
            </>
          }
        >
          <p>
            Keluarkan sesi <strong>{keluarTarget.nama}</strong> ({keluarTarget.username}) di perangkat{' '}
            <strong>{keluarTarget.perangkat ?? 'tanpa nama'}</strong>?
            {keluarTarget.id === sesiSaya && ' Ini adalah sesi Anda sendiri — Anda akan keluar dari aplikasi.'}
          </p>
          <p className="teks-redup">Perangkat tersebut harus masuk kembali dengan password setelah dikeluarkan.</p>
        </Modal>
      )}

      {kodeBaru && (
        <Modal
          judul="Kode Pemulihan — tampil sekali"
          lebar="sedang"
          onTutup={() => setKodeBaru(null)}
          aksi={
            <>
              <button type="button" className="tombol tombol--netral" onClick={unduhKode}>
                Unduh .txt
              </button>
              <button type="button" className="tombol" onClick={() => void salinKode()}>
                Salin semua
              </button>
              <button type="button" className="tombol tombol--primer" onClick={() => setKodeBaru(null)}>
                Sudah saya simpan
              </button>
            </>
          }
        >
          <p className="peringatan-dampak">
            Kesepuluh kode ini HANYA tampil sekali ini dan tidak bisa dilihat lagi. Simpan di tempat aman
            (cetak/unduh) sekarang juga — tiap kode hanya bisa dipakai satu kali.
          </p>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
              gap: 8,
              fontFamily: 'ui-monospace, monospace',
              fontSize: 14,
              letterSpacing: '0.05em',
            }}
          >
            {kodeBaru.map((k) => (
              <span
                key={k}
                style={{ border: '1px solid var(--border)', borderRadius: 8, padding: '8px 10px', textAlign: 'center' }}
              >
                {k}
              </span>
            ))}
          </div>
        </Modal>
      )}
    </>
  );
}

/* ================== Keamanan & Sistem ▸ 17. Pengguna ==================== */

interface BarisPengguna {
  id: number;
  nama: string;
  username: string;
  email: string | null;
  wa: string | null;
  peran_id: number;
  peran: string;
  cakupan_toko: string[] | null;
  cakupan_efektif: string[] | null;
  status: 'aktif' | 'nonaktif' | 'terkunci';
  kunci_sampai: string | null;
  login_terakhir: string | null;
  wajib_ganti: boolean;
  admin_utama: boolean;
  jumlah_sesi: number;
}

interface OpsiPeran {
  id: number;
  nama: string;
}

interface OpsiToko {
  kode: string;
  nama: string;
}

interface FormPengguna {
  id: number | null;
  nama: string;
  username: string;
  email: string;
  wa: string;
  peran_id: string;
  cakupan: string[];
  sandi: string;
  konfirmasi: string;
  wajib_ganti: boolean;
}

const LABEL_STATUS: Record<BarisPengguna['status'], string> = {
  aktif: 'Aktif',
  nonaktif: 'Nonaktif',
  terkunci: 'Terkunci',
};

/**
 * TAHAP 2 — Pengguna & Hak Akses (Pengaturan ▸ Pengguna):
 *  • tabel pengguna + pencarian/filter peran & status + pilih massal,
 *  • form Tambah/Ubah (nama, username, kontak, peran, cakupan toko, password,
 *    wajib ganti),
 *  • aksi baris: ubah, reset password (tampil sekali), aktif/nonaktif, buka
 *    kunci, hapus — plus aksi massal (aktifkan/nonaktifkan/buka kunci/hapus),
 *  • matriks izin tab Pengaturan per peran (Admin memberi izin per tab).
 */
export function PanelPengguna({ daftar }: { daftar: DaftarPengaturan }) {
  const info = useSesi().info;
  const sayaId = info?.pengguna.id ?? null;

  const [pengguna, setPengguna] = useState<BarisPengguna[]>([]);
  const [peran, setPeran] = useState<OpsiPeran[]>([]);
  const [toko, setToko] = useState<OpsiToko[]>([]);
  const [izin, setIzin] = useState<Record<string, string[]>>({});

  const [cari, setCari] = useState('');
  const [fltPeran, setFltPeran] = useState('');
  const [fltStatus, setFltStatus] = useState('');
  const [pilih, setPilih] = useState<Set<number>>(new Set());

  const [form, setForm] = useState<FormPengguna | null>(null);
  const [galatForm, setGalatForm] = useState<string | null>(null);
  const [sandiBaru, setSandiBaru] = useState<{ nama: string; sandi: string } | null>(null);
  const [konfirmasi, setKonfirmasi] = useState<{
    judul: string;
    pesan: string;
    jalan: () => Promise<void>;
  } | null>(null);
  const [sibuk, setSibuk] = useState(false);

  const tab = daftar.tab.filter((t) => !t.informatif);

  const muat = useCallback(async () => {
    try {
      const r = await apiGet<{ data: BarisPengguna[]; peran: OpsiPeran[]; toko: OpsiToko[] }>(
        '/api/pengguna/daftar',
      );
      setPengguna(r.data);
      setPeran(r.peran);
      setToko(r.toko);
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Gagal memuat daftar pengguna.', 'galat');
    }
  }, []);

  useEffect(() => {
    void muat();
    void apiGet<Record<string, string[]>>('/api/pengaturan/pengguna/izin')
      .then(setIzin)
      .catch(() => setIzin({}));
  }, [muat]);

  /* ------------------------------ daftar ------------------------------- */

  const terlihat = pengguna.filter((u) => {
    const k = cari.trim().toLowerCase();
    if (k && !`${u.nama} ${u.username} ${u.email ?? ''} ${u.peran}`.toLowerCase().includes(k)) return false;
    if (fltPeran && String(u.peran_id) !== fltPeran) return false;
    if (fltStatus && u.status !== fltStatus) return false;
    return true;
  });
  const semuaTerpilih = terlihat.length > 0 && terlihat.every((u) => pilih.has(u.id));

  function togglePilih(id: number) {
    setPilih((p) => {
      const baru = new Set(p);
      if (baru.has(id)) baru.delete(id);
      else baru.add(id);
      return baru;
    });
  }

  function toggleSemua() {
    setPilih((p) => {
      const baru = new Set(p);
      if (semuaTerpilih) for (const u of terlihat) baru.delete(u.id);
      else for (const u of terlihat) baru.add(u.id);
      return baru;
    });
  }

  /* ------------------------------- aksi -------------------------------- */

  async function jalankan(fn: () => Promise<void>) {
    setSibuk(true);
    try {
      await fn();
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Terjadi kesalahan.', 'galat');
    } finally {
      setSibuk(false);
    }
  }

  function bukaForm(u: BarisPengguna | null) {
    setGalatForm(null);
    setForm(
      u
        ? {
            id: u.id,
            nama: u.nama,
            username: u.username,
            email: u.email ?? '',
            wa: u.wa ?? '',
            peran_id: String(u.peran_id),
            cakupan: u.cakupan_toko ?? [],
            sandi: '',
            konfirmasi: '',
            wajib_ganti: u.wajib_ganti,
          }
        : {
            id: null,
            nama: '',
            username: '',
            email: '',
            wa: '',
            peran_id: String(peran[0]?.id ?? ''),
            cakupan: [],
            sandi: '',
            konfirmasi: '',
            wajib_ganti: false,
          },
    );
  }

  async function simpanForm(e: FormEvent) {
    e.preventDefault();
    if (!form || sibuk) return;
    setGalatForm(null);
    if (!form.nama.trim() || !form.username.trim()) {
      setGalatForm('Nama dan username wajib diisi.');
      return;
    }
    if (form.id === null) {
      if (!form.sandi) {
        setGalatForm('Password awal wajib diisi.');
        return;
      }
      if (form.sandi !== form.konfirmasi) {
        setGalatForm('Konfirmasi password tidak sama.');
        return;
      }
    } else if (form.sandi && form.sandi !== form.konfirmasi) {
      setGalatForm('Konfirmasi password tidak sama.');
      return;
    }
    setSibuk(true);
    try {
      const body = {
        nama: form.nama.trim(),
        username: form.username.trim(),
        email: form.email.trim() || null,
        wa: form.wa.trim() || null,
        peran_id: Number(form.peran_id),
        cakupan_toko: form.cakupan.length > 0 ? form.cakupan : null,
        sandi: form.sandi,
        wajib_ganti: form.wajib_ganti,
      };
      const r =
        form.id === null
          ? await apiPost<{ pesan: string }>('/api/pengguna', body)
          : await apiPut<{ pesan: string }>(`/api/pengguna/${form.id}`, body);
      beritahu(r.pesan, 'sukses');
      setForm(null);
      await muat();
    } catch (err) {
      setGalatForm(err instanceof Error ? err.message : 'Gagal menyimpan pengguna.');
    } finally {
      setSibuk(false);
    }
  }

  async function resetSandi(u: BarisPengguna) {
    setSibuk(true);
    try {
      const r = await apiPost<{ sandi: string; pesan: string }>(`/api/pengguna/${u.id}/sandi`, {});
      setSandiBaru({ nama: u.nama, sandi: r.sandi });
      await muat();
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Gagal mereset password.', 'galat');
    } finally {
      setSibuk(false);
    }
  }

  function mintaStatus(u: BarisPengguna, aktif: boolean) {
    setKonfirmasi({
      judul: aktif ? 'Aktifkan pengguna' : 'Nonaktifkan pengguna',
      pesan: aktif
        ? `Aktifkan "${u.nama}"? Ia bisa masuk kembali.`
        : `Nonaktifkan "${u.nama}"? Ia tidak bisa masuk dan seluruh sesinya dikeluarkan.`,
      jalan: async () => {
        const r = await apiPost<{ pesan: string }>(`/api/pengguna/${u.id}/status`, { aktif });
        beritahu(r.pesan, 'sukses');
        setKonfirmasi(null);
        await muat();
      },
    });
  }

  async function bukaKunci(u: BarisPengguna) {
    await jalankan(async () => {
      const r = await apiPost<{ pesan: string }>(`/api/pengguna/${u.id}/buka`, {});
      beritahu(r.pesan, 'sukses');
      await muat();
    });
  }

  function mintaHapus(u: BarisPengguna) {
    setKonfirmasi({
      judul: 'Hapus pengguna',
      pesan: `Hapus "${u.nama}" (${u.username})? Bila akun ini memiliki riwayat transaksi, server menolak — pakai Nonaktifkan sebagai gantinya.`,
      jalan: async () => {
        const r = await apiDelete<{ pesan: string }>(`/api/pengguna/${u.id}`);
        beritahu(r.pesan, 'sukses');
        setKonfirmasi(null);
        setPilih((p) => {
          const baru = new Set(p);
          baru.delete(u.id);
          return baru;
        });
        await muat();
      },
    });
  }

  async function massal(aksi: 'aktifkan' | 'nonaktifkan' | 'buka' | 'hapus') {
    const ids = [...pilih];
    if (ids.length === 0) return;
    const jalan = async () => {
      const r = await apiPost<{ pesan: string }>('/api/pengguna/massal', { aksi, ids });
      beritahu(r.pesan, 'sukses');
      setKonfirmasi(null);
      setPilih(new Set());
      await muat();
    };
    if (aksi === 'nonaktifkan' || aksi === 'hapus') {
      setKonfirmasi({
        judul: aksi === 'hapus' ? `Hapus ${ids.length} pengguna` : `Nonaktifkan ${ids.length} pengguna`,
        pesan:
          aksi === 'hapus'
            ? `${ids.length} pengguna dihapus permanen. Akun dengan riwayat transaksi akan ditolak server.`
            : `${ids.length} pengguna dinonaktifkan dan seluruh sesinya dikeluarkan.`,
        jalan,
      });
      return;
    }
    await jalankan(jalan);
  }

  /* ------------------------- matriks izin tab -------------------------- */

  function toggle(tabKode: string, namaPeran: string) {
    const kini = izin[tabKode] ?? [];
    const ada = kini.includes(namaPeran);
    setIzin({ ...izin, [tabKode]: ada ? kini.filter((x) => x !== namaPeran) : [...kini, namaPeran] });
  }

  async function simpanIzin(tabKode: string) {
    try {
      const r = await apiPut<{ pesan: string }>(`/api/pengaturan/pengguna/akses/${tabKode}`, {
        peran: izin[tabKode] ?? [],
      });
      beritahu(r.pesan, 'sukses');
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Gagal menyimpan izin.', 'galat');
    }
  }

  const peranLain = peran.filter((r) => !['owner', 'administrator'].includes(r.nama.toLowerCase()));

  return (
    <>
      <section className="kartu">
        <div className="kartu__kepala">
          <div>
            <h3>Daftar Pengguna</h3>
            <p className="teks-redup teks-kecil">
              Peran &amp; hak akses modul dikelola di Pengaturan ▸ Halaman Awal &amp; Peran.
            </p>
          </div>
          <div className="tombol-baris">
            <button type="button" className="tombol tombol--primer tombol--kecil" onClick={() => bukaForm(null)}>
              + Tambah Pengguna
            </button>
          </div>
        </div>

        <div className="alat-tabel">
          <input
            className="input-cari"
            type="search"
            placeholder="Cari nama / username / email…"
            aria-label="Cari pengguna"
            value={cari}
            onChange={(e) => setCari(e.target.value)}
          />
          <select
            className="input-pilih"
            aria-label="Filter peran"
            value={fltPeran}
            onChange={(e) => setFltPeran(e.target.value)}
          >
            <option value="">Semua peran</option>
            {peran.map((r) => (
              <option key={r.id} value={r.id}>
                {r.nama}
              </option>
            ))}
          </select>
          <select
            className="input-pilih"
            aria-label="Filter status"
            value={fltStatus}
            onChange={(e) => setFltStatus(e.target.value)}
          >
            <option value="">Semua status</option>
            <option value="aktif">Aktif</option>
            <option value="nonaktif">Nonaktif</option>
            <option value="terkunci">Terkunci</option>
          </select>
        </div>

        {pilih.size > 0 && (
          <div className="alat-tabel" role="group" aria-label="Aksi massal">
            <strong>{pilih.size} pengguna dipilih</strong>
            <button type="button" className="tombol tombol--kecil" onClick={() => void massal('aktifkan')}>
              Aktifkan
            </button>
            <button type="button" className="tombol tombol--kecil" onClick={() => void massal('nonaktifkan')}>
              Nonaktifkan
            </button>
            <button type="button" className="tombol tombol--kecil" onClick={() => void massal('buka')}>
              Buka kunci
            </button>
            <button type="button" className="tombol tombol--kecil tombol--bahaya" onClick={() => void massal('hapus')}>
              Hapus
            </button>
            <button type="button" className="tombol tombol--kecil tombol--netral" onClick={() => setPilih(new Set())}>
              Batalkan pilihan
            </button>
          </div>
        )}

        <table className="aturan-tabel">
          <thead>
            <tr>
              <th style={{ width: 34 }}>
                <input
                  type="checkbox"
                  aria-label="Pilih semua pengguna tampil"
                  checked={semuaTerpilih}
                  onChange={toggleSemua}
                />
              </th>
              <th>Nama</th>
              <th>Username</th>
              <th>Email</th>
              <th>No. WhatsApp</th>
              <th>Peran</th>
              <th>Toko/Gudang</th>
              <th>Status</th>
              <th>Login terakhir</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {terlihat.length === 0 && (
              <tr>
                <td colSpan={9} className="teks-redup">
                  {pengguna.length === 0 ? 'Belum ada pengguna terdaftar.' : 'Tidak ada pengguna yang cocok.'}
                </td>
              </tr>
            )}
            {terlihat.map((u) => (
              <tr key={u.id}>
                <td>
                  <input
                    type="checkbox"
                    aria-label={`Pilih ${u.nama}`}
                    checked={pilih.has(u.id)}
                    onChange={() => togglePilih(u.id)}
                  />
                </td>
                <td>
                  <strong>{u.nama}</strong>
                  {u.wajib_ganti && (
                    <span className="lencana lencana--peringatan" style={{ marginLeft: 6 }}>
                      Wajib ganti sandi
                    </span>
                  )}
                </td>
                <td>{u.username}</td>
                <td>{u.email ?? '—'}</td>
                <td className={u.wa ? undefined : 'teks-redup'}>{u.wa ?? '—'}</td>
                <td>{u.peran}</td>
                <td
                  className="teks-redup teks-kecil"
                  title="Cakupan toko/gudang (irisan pengguna × peran)"
                >
                  {u.cakupan_efektif === null ? 'Semua' : u.cakupan_efektif.join(', ') || '—'}
                </td>
                <td>
                  <span className={`lencana ${u.status === 'aktif' ? 'lencana--aktif' : 'lencana--peringatan'}`}>
                    {LABEL_STATUS[u.status]}
                  </span>
                </td>
                <td>{u.login_terakhir ? formatTanggalPanjang(u.login_terakhir) : '—'}</td>
                <td>
                  <span className="aksi-baris">
                    <IconButton label={`Ubah ${u.nama}`} ikon="pencil" onClick={() => bukaForm(u)} />
                    <IconButton
                      label={`Reset password ${u.nama}`}
                      ikon="rotate-ccw"
                      onClick={() => void resetSandi(u)}
                      disabled={sibuk}
                    />
                    {u.status === 'terkunci' ? (
                      <IconButton
                        label={`Buka kunci ${u.nama}`}
                        ikon="circle-check"
                        onClick={() => void bukaKunci(u)}
                        disabled={sibuk}
                      />
                    ) : u.status === 'aktif' ? (
                      <IconButton
                        label={`Nonaktifkan ${u.nama}`}
                        ikon="power"
                        onClick={() => mintaStatus(u, false)}
                        disabled={sibuk || u.id === sayaId}
                        alasan={u.id === sayaId ? 'Tidak bisa menonaktifkan akun sendiri' : undefined}
                      />
                    ) : (
                      <IconButton
                        label={`Aktifkan ${u.nama}`}
                        ikon="circle-check"
                        onClick={() => mintaStatus(u, true)}
                        disabled={sibuk}
                      />
                    )}
                    {!u.admin_utama && (
                      <IconButton
                        label={`Hapus ${u.nama}`}
                        ikon="trash"
                        warna="bahaya"
                        onClick={() => mintaHapus(u)}
                        disabled={sibuk || u.id === sayaId}
                        alasan={u.id === sayaId ? 'Tidak bisa menghapus akun sendiri' : undefined}
                      />
                    )}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section className="kartu">
        <div className="kartu__kepala">
          <h3>Matriks Hak Akses Tab Pengaturan</h3>
          <span className="teks-redup">Admin selalu memiliki akses penuh.</span>
        </div>
        {peranLain.length === 0 ? (
          <p className="teks-redup">Belum ada peran selain Admin/Owner yang bisa diberi izin.</p>
        ) : (
          <div className="matriks-akses">
            <table className="aturan-tabel">
              <thead>
                <tr>
                  <th>Tab</th>
                  {peranLain.map((r) => (
                    <th key={r.id}>{r.nama}</th>
                  ))}
                  <th />
                </tr>
              </thead>
              <tbody>
                {tab.map((t) => (
                  <tr key={t.kode}>
                    <td>{t.label}</td>
                    {peranLain.map((r) => (
                      <td key={r.id}>
                        <input
                          type="checkbox"
                          aria-label={`${t.label} — ${r.nama}`}
                          checked={(izin[t.kode] ?? []).includes(r.nama)}
                          onChange={() => toggle(t.kode, r.nama)}
                        />
                      </td>
                    ))}
                    <td>
                      <IconButton
                        label={`Simpan izin ${t.label}`}
                        ikon="check"
                        onClick={() => void simpanIzin(t.kode)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Form tambah/ubah pengguna */}
      {form && (
        <Modal
          judul={form.id === null ? 'Tambah Pengguna' : `Ubah — ${form.nama}`}
          lebar="sedang"
          onTutup={() => setForm(null)}
          sedangKirim={sibuk}
          aksi={
            <>
              <button type="button" className="tombol tombol--netral" onClick={() => setForm(null)} disabled={sibuk}>
                Batal
              </button>
              <button type="submit" form="form-pengguna" className="tombol tombol--primer" disabled={sibuk}>
                {sibuk ? 'Menyimpan…' : 'Simpan'}
              </button>
            </>
          }
        >
          <form id="form-pengguna" onSubmit={(e) => void simpanForm(e)}>
            <div className="form-grid">
              <label className="bidang">
                <span>Nama lengkap *</span>
                <input
                  data-fokus-awal
                  value={form.nama}
                  onChange={(e) => setForm({ ...form, nama: e.target.value })}
                  disabled={sibuk}
                  required
                />
              </label>
              <label className="bidang">
                <span>Username *</span>
                <input
                  value={form.username}
                  onChange={(e) => setForm({ ...form, username: e.target.value })}
                  disabled={sibuk}
                  autoComplete="off"
                  required
                />
              </label>
              <label className="bidang">
                <span>Email</span>
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  disabled={sibuk}
                />
              </label>
              <label className="bidang">
                <span>No. WhatsApp</span>
                <input
                  value={form.wa}
                  placeholder="08xxxxxxxxxx"
                  onChange={(e) => setForm({ ...form, wa: e.target.value })}
                  disabled={sibuk}
                />
              </label>
              <label className="bidang">
                <span>Peran *</span>
                <select
                  value={form.peran_id}
                  onChange={(e) => setForm({ ...form, peran_id: e.target.value })}
                  disabled={sibuk}
                >
                  {peran.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.nama}
                    </option>
                  ))}
                </select>
              </label>
              <label className="bidang">
                <span>{form.id === null ? 'Password awal *' : 'Password baru (kosongkan bila tetap)'}</span>
                <input
                  type="password"
                  value={form.sandi}
                  onChange={(e) => setForm({ ...form, sandi: e.target.value })}
                  disabled={sibuk}
                  autoComplete="new-password"
                />
              </label>
              <label className="bidang">
                <span>Ulangi password</span>
                <input
                  type="password"
                  value={form.konfirmasi}
                  onChange={(e) => setForm({ ...form, konfirmasi: e.target.value })}
                  disabled={sibuk}
                  autoComplete="new-password"
                />
              </label>
            </div>

            {(form.sandi || form.id === null) && <IndikatorSandi sandi={form.sandi} />}

            {toko.length > 0 && (
              <div className="bidang" style={{ marginTop: 10 }}>
                <span>Cakupan toko/gudang (kosongkan semua = semua toko)</span>
                <div className="tombol-baris">
                  {toko.map((t) => (
                    <label key={t.kode} className="login-ingat" style={{ marginRight: 12 }}>
                      <input
                        type="checkbox"
                        checked={form.cakupan.includes(t.kode)}
                        disabled={sibuk}
                        onChange={(e) =>
                          setForm({
                            ...form,
                            cakupan: e.target.checked
                              ? [...form.cakupan, t.kode]
                              : form.cakupan.filter((x) => x !== t.kode),
                          })
                        }
                      />
                      <span>{t.nama}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            <label className="login-ingat" style={{ marginTop: 10 }}>
              <input
                type="checkbox"
                checked={form.wajib_ganti}
                disabled={sibuk}
                onChange={(e) => setForm({ ...form, wajib_ganti: e.target.checked })}
              />
              <span>Wajib ganti password saat login berikutnya</span>
            </label>

            {galatForm && (
              <p className="login-pesan login-pesan--galat" role="alert">
                {galatForm}
              </p>
            )}
          </form>
        </Modal>
      )}

      {/* Password sementara hasil reset — tampil sekali */}
      {sandiBaru && (
        <Modal
          judul="Password sementara — tampil sekali"
          lebar="kecil"
          onTutup={() => setSandiBaru(null)}
          aksi={
            <>
              <button
                type="button"
                className="tombol"
                onClick={() => {
                  void navigator.clipboard
                    .writeText(sandiBaru.sandi)
                    .then(() => beritahu('Password disalin.'))
                    .catch(() => beritahu('Peramban menolak papan klip — salin manual.', 'galat'));
                }}
              >
                Salin
              </button>
              <button type="button" className="tombol tombol--primer" onClick={() => setSandiBaru(null)}>
                Sudah saya catat
              </button>
            </>
          }
        >
          <p>
            Password sementara untuk <strong>{sandiBaru.nama}</strong>:
          </p>
          <p
            style={{
              fontFamily: 'ui-monospace, monospace',
              fontSize: 18,
              letterSpacing: '0.08em',
              border: '1px dashed var(--border)',
              borderRadius: 8,
              padding: '10px 12px',
              textAlign: 'center',
            }}
          >
            {sandiBaru.sandi}
          </p>
          <p className="teks-redup">
            Catat sekarang — hanya tampil sekali ini. Akun ditandai wajib ganti password saat login berikutnya,
            dan seluruh sesi lama pengguna ikut dikeluarkan.
          </p>
        </Modal>
      )}

      {/* Konfirmasi aksi destruktif */}
      {konfirmasi && (
        <Modal
          judul={konfirmasi.judul}
          lebar="kecil"
          onTutup={() => setKonfirmasi(null)}
          sedangKirim={sibuk}
          aksi={
            <>
              <button type="button" className="tombol tombol--netral" onClick={() => setKonfirmasi(null)} disabled={sibuk}>
                Batal
              </button>
              <button
                type="button"
                className="tombol tombol--bahaya"
                disabled={sibuk}
                onClick={() => void jalankan(konfirmasi.jalan)}
              >
                {sibuk ? 'Memproses…' : 'Lanjutkan'}
              </button>
            </>
          }
        >
          <p>{konfirmasi.pesan}</p>
        </Modal>
      )}
    </>
  );
}

/* =============== Keamanan & Sistem ▸ 18. Database & Backup ============== */

interface InfoSistem {
  versi: string; namaDatabase: string; ukuranDb: number; waktuDatabase: string;
  migrasi: number; ringkasan: { nama: string; jumlah: number }[];
  cadangan: { nama: string; ukuran: number; waktu: string }[];
}

/** Info database, cadangan manual/terjadwal, dan pemulihan (dengan peringatan). */
export function PanelDatabase({ nilai }: { nilai: Record<string, unknown> }) {
  const [info, setInfo] = useState<InfoSistem | null>(null);
  const [pulih, setPulih] = useState<string | null>(null);
  const [konfirmasi, setKonfirmasi] = useState('');

  const muat = useCallback(async () => {
    try {
      setInfo(await apiGet<InfoSistem>('/api/pengaturan/sistem/info'));
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Gagal memuat info database.', 'galat');
    }
  }, []);

  useEffect(() => {
    void muat();
  }, [muat]);

  async function cadangkan() {
    try {
      const r = await apiPost<{ pesan: string }>('/api/pengaturan/sistem/backup', {});
      beritahu(r.pesan);
      await muat();
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Gagal membuat cadangan.', 'galat');
    }
  }

  async function pulihkan(nama: string) {
    try {
      const r = await apiPost<{ pesan: string }>('/api/pengaturan/sistem/pulihkan', { nama, konfirmasi });
      beritahu(r.pesan);
      setPulih(null);
      setKonfirmasi('');
      await muat();
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Gagal memulihkan.', 'galat');
    }
  }

  if (!info) return <p className="teks-redup">Memuat info database…</p>;

  return (
    <>
      <section className="kartu">
        <div className="kartu__kepala">
          <h3>Database Aktif</h3>
          <IconButton label="Buat cadangan sekarang" ikon="download" onClick={() => void cadangkan()} />
        </div>
        <dl className="info-sistem">
          <div><dt>Berkas</dt><dd>{info.namaDatabase}</dd></div>
          <div><dt>Ukuran</dt><dd>{fmtUkuran(info.ukuranDb)}</dd></div>
          <div><dt>Perubahan terakhir</dt><dd>{info.waktuDatabase ? formatTanggalPanjang(info.waktuDatabase) : '—'}</dd></div>
          <div><dt>Migrasi diterapkan</dt><dd>{info.migrasi}</dd></div>
          <div><dt>Jadwal backup</dt><dd>{String(nilai.backup_otomatis ?? 'mati')} {String(nilai.backup_otomatis ?? 'mati') !== 'mati' ? `pukul ${String(nilai.backup_jam ?? '02:00')}` : ''}</dd></div>
          <div><dt>Disimpan</dt><dd>{info.cadangan.length} / {String(nilai.jumlah_backup ?? 14)} berkas</dd></div>
        </dl>
      </section>

      <section className="kartu">
        <div className="kartu__kepala">
          <h3>Riwayat Cadangan</h3>
          <span className="teks-redup">Unduh atau pulihkan.</span>
        </div>
        {info.cadangan.length === 0 ? (
          <p className="teks-redup">Belum ada cadangan. Klik ikon unduh di atas untuk membuat cadangan pertama.</p>
        ) : (
          <table className="aturan-tabel">
            <thead>
              <tr><th>Nama berkas</th><th>Ukuran</th><th>Dibuat</th><th /></tr>
            </thead>
            <tbody>
              {info.cadangan.map((c) => (
                <tr key={c.nama}>
                  <td>{c.nama}</td>
                  <td>{fmtUkuran(c.ukuran)}</td>
                  <td>{formatTanggalPanjang(c.waktu)}</td>
                  <td>
                    <span className="aksi-baris">
                      <a className="tombol tombol--kecil" href={`/api/pengaturan/sistem/backup/unduh?nama=${encodeURIComponent(c.nama)}`}>
                        Unduh
                      </a>
                      <IconButton label={`Pulihkan dari ${c.nama}`} ikon="rotate-ccw" onClick={() => setPulih(c.nama)} />
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      {/* Reset Data — wizard 4 langkah, hanya Admin utama (panel & server). */}
      <PanelResetData />

      {pulih && (
        <section className="kartu kartu--bahaya">
          <div className="kartu__kepala">
            <h3>Pulihkan dari “{pulih}”</h3>
          </div>
          <p className="peringatan-dampak">
            Peringatan: pemulihan menimpa SELURUH isi database aktif dengan isi cadangan ini.
            Data yang dibuat setelah cadangan dibuat akan hilang. Sebelum melanjutkan, sebuah
            cadangan pengaman dari keadaan sekarang dibuat otomatis.
          </p>
          <div className="bidang">
            <label htmlFor="konf-pulih">Ketik <strong>PULIHKAN</strong> untuk melanjutkan</label>
            <input id="konf-pulih" value={konfirmasi} onChange={(e) => setKonfirmasi(e.target.value)} autoComplete="off" />
          </div>
          <div className="tombol-baris tombol-baris--kanan">
            <button type="button" className="tombol tombol--netral" onClick={() => { setPulih(null); setKonfirmasi(''); }}>
              Batal
            </button>
            <button
              type="button"
              className="tombol tombol--bahaya"
              disabled={konfirmasi !== 'PULIHKAN'}
              onClick={() => void pulihkan(pulih)}
            >
              Pulihkan Sekarang
            </button>
          </div>
        </section>
      )}

      <section className="kartu">
        <div className="kartu__kepala">
          <h3>Tutup Tahun</h3>
        </div>
        <p className="teks-redup">
          Penutupan buku tahunan (menghapus riwayat transaksi &amp; membuat saldo awal) dijalankan dari
          modul Proses Tahunan.
        </p>
        <div className="tombol-baris">
          <Link to="/pengaturan/proses-tahunan" className="tombol tombol--netral">
            Buka Proses Tahunan
          </Link>
        </div>
      </section>
    </>
  );
}

/* =============== Keamanan & Sistem ▸ 19. Impor & Ekspor ================= */

interface ModulImpor {
  kode: string; label: string; kolom: { key: string; label: string }[];
  template: string; tersedia: boolean; ket: string | null;
}
interface BarisRiwayat {
  id: number; modul: string; nama_file: string; total_baris: number;
  baris_valid: number; baris_error: number; status: string; waktu: string; nama: string | null;
}

/** Contoh file impor tiap modul + riwayat impor. */
export function PanelImpor() {
  const [modul, setModul] = useState<ModulImpor[]>([]);
  const [riwayat, setRiwayat] = useState<BarisRiwayat[]>([]);

  const muat = useCallback(async () => {
    try {
      const [m, r] = await Promise.all([
        apiGet<{ data: ModulImpor[] }>('/api/pengaturan/impor/modul').catch(() => ({ data: [] as ModulImpor[] })),
        apiGet<{ data: BarisRiwayat[] }>('/api/pengaturan/impor/riwayat').catch(() => ({ data: [] as BarisRiwayat[] })),
      ]);
      setModul(m.data);
      setRiwayat(r.data);
    } catch {
      setModul([]);
      setRiwayat([]);
    }
  }, []);

  useEffect(() => {
    void muat();
  }, [muat]);

  return (
    <>
      <section className="kartu">
        <div className="kartu__kepala">
          <h3>Contoh File Impor</h3>
          <span className="teks-redup">Kolom mengikuti skema terbaru.</span>
        </div>
        <table className="aturan-tabel">
          <thead>
            <tr><th>Modul</th><th>Kolom</th><th>Keterangan</th><th /></tr>
          </thead>
          <tbody>
            {modul.map((m) => (
              <tr key={m.kode}>
                <td>{m.label}</td>
                <td>{m.tersedia ? (m.kolom.length || '—') : '—'}</td>
                <td className="teks-redup">
                  {m.ket ?? (m.kolom.length ? `${m.kolom.slice(0, 4).map((k) => k.label).join(', ')}…` : '—')}
                </td>
                <td>
                  {m.tersedia ? (
                    <a className="tombol tombol--kecil" href={m.template}>Unduh contoh</a>
                  ) : (
                    <span className="teks-redup">Tidak tersedia</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section className="kartu">
        <div className="kartu__kepala">
          <h3>Riwayat Impor</h3>
          <IconButton label="Muat ulang riwayat" ikon="rotate-ccw" onClick={() => void muat()} />
        </div>
        {riwayat.length === 0 ? (
          <p className="teks-redup">Belum ada impor yang dijalankan.</p>
        ) : (
          <table className="aturan-tabel">
            <thead>
              <tr><th>Waktu</th><th>Modul</th><th>Berkas</th><th>Baris</th><th>Sah</th><th>Error</th><th>Status</th><th>Oleh</th></tr>
            </thead>
            <tbody>
              {riwayat.map((b) => (
                <tr key={b.id}>
                  <td>{formatTanggalPanjang(b.waktu)}</td>
                  <td>{b.modul}</td>
                  <td>{b.nama_file}</td>
                  <td>{b.total_baris}</td>
                  <td>{b.baris_valid}</td>
                  <td>{b.baris_error}</td>
                  <td>{b.status}</td>
                  <td>{b.nama ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </>
  );
}

/* ============== Keamanan & Sistem ▸ 20. Notifikasi & Pesan ============== */

/**
 * Notifikasi & Pesan: status koneksi WhatsApp/email dan pratinjau template.
 *
 * Kedua layanan luar belum tersambung, jadi tombol tes dinonaktifkan dan
 * petunjuk pengaturannya ditampilkan — bukan pesan galat.
 */
export function PanelNotifikasi({ nilai }: { nilai: Record<string, unknown> }) {
  const [tes, setTes] = useState<string | null>(null);

  const waAktif = nilai.wa_aktif === true && String(nilai.wa_nomor_pengirim ?? '') !== '';
  const smtpAktif =
    nilai.smtp_aktif === true &&
    String(nilai.smtp_host ?? '') !== '' &&
    String(nilai.smtp_pengguna ?? '') !== '';

  async function kirimTes(kanal: 'wa' | 'email') {
    try {
      const r = await apiPost<{ pesan: string }>('/api/pengaturan/notifikasi/tes', { kanal });
      setTes(r.pesan);
      beritahu(r.pesan, 'info');
    } catch (e) {
      const pesan = e instanceof Error ? e.message : 'Gagal mengirim tes.';
      setTes(pesan);
      beritahu(pesan, 'galat');
    }
  }

  const variabel = '{NAMA} {NOMOR} {TOTAL} {JATUH_TEMPO}';

  return (
    <>
      <section className="kartu">
        <div className="kartu__kepala">
          <h3>Koneksi Kanal Kirim</h3>
        </div>
        <ul className="daftar-kanal">
          <li>
            <strong>WhatsApp</strong>
            <span className={`status-kanal ${waAktif ? 'status-kanal--nyala' : 'status-kanal--mati'}`}>
              {waAktif ? 'Aktif' : 'Belum tersambung'}
            </span>
            <p className="teks-redup">
              Pengiriman otomatis memerlukan akun WhatsApp Business API (Cloud API). Selama belum
              tersambung, kasir mengirim lewat tautan wa.me yang dibuka di WhatsApp perangkat.
            </p>
            <IconButton
              label="Tes kirim WhatsApp"
              ikon="whatsapp"
              disabled={!waAktif}
              alasan={waAktif ? undefined : 'aktifkan & isi nomor dulu'}
              onClick={() => void kirimTes('wa')}
            />
          </li>
          <li>
            <strong>Email (SMTP)</strong>
            <span className={`status-kanal ${smtpAktif ? 'status-kanal--nyala' : 'status-kanal--mati'}`}>
              {smtpAktif ? 'Aktif' : 'Belum tersambung'}
            </span>
            <p className="teks-redup">
              Isi host, port, pengguna, dan kata sandi aplikasi email Anda lalu aktifkan. Dipakai
              untuk mengirim faktur dan tautan reset password.
            </p>
            <IconButton
              label="Tes kirim email"
              ikon="send"
              disabled={!smtpAktif}
              alasan={smtpAktif ? undefined : 'lengkapi SMTP dulu'}
              onClick={() => void kirimTes('email')}
            />
          </li>
        </ul>
        {tes && <p className="teks-redup">{tes}</p>}
      </section>

      <section className="kartu">
        <div className="kartu__kepala">
          <h3>Pratinjau Template</h3>
          <span className="teks-redup">Variabel: {variabel}</span>
        </div>
        <div className="form-grid">
          {[
            { k: 'template_faktur', l: 'Faktur' },
            { k: 'template_pengingat', l: 'Pengingat jatuh tempo' },
            { k: 'template_struk', l: 'Struk' },
          ].map((t) => (
            <div className="bidang" key={t.k}>
              <span>{t.l}</span>
              <div className="pratinjau-pesan">{String(nilai[t.k] ?? '')}</div>
            </div>
          ))}
        </div>
        <p className="teks-redup">
          Jadwal pengingat: piutang {String(nilai.pengingat_piutang_hari ?? 3)} hari dan hutang{' '}
          {String(nilai.pengingat_hutang_hari ?? 3)} hari sebelum jatuh tempo.
        </p>
      </section>
    </>
  );
}

/* ================= Keamanan & Sistem ▸ 22. Tentang ====================== */

/** Versi aplikasi, nama database, ringkasan jumlah data, pemeriksaan pembaruan. */
export function PanelTentang() {
  // Y2.4 — identitas aplikasi dari satu sumber data.
  const identitas = useIdentitas();
  const [info, setInfo] = useState<InfoSistem | null>(null);
  const [pembaruan, setPembaruan] = useState<{ versi: string; tersedia: boolean; pesan: string } | null>(null);
  const [sibuk, setSibuk] = useState(false);

  useEffect(() => {
    void apiGet<InfoSistem>('/api/pengaturan/sistem/info').then(setInfo).catch(() => setInfo(null));
  }, []);

  async function periksa() {
    setSibuk(true);
    try {
      setPembaruan(await apiGet<{ versi: string; tersedia: boolean; pesan: string }>('/api/pengaturan/sistem/pembaruan'));
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Gagal memeriksa pembaruan.', 'galat');
    } finally {
      setSibuk(false);
    }
  }

  if (!info) return <p className="teks-redup">Memuat info sistem…</p>;

  return (
    <section className="kartu">
      <div className="kartu__kepala">
        <h3>Tentang Sistem</h3>
        <IconButton label="Periksa Pembaruan" ikon="rotate-ccw" disabled={sibuk} alasan={sibuk ? 'memeriksa…' : undefined} onClick={() => void periksa()} />
      </div>
      <dl className="info-sistem">
        <div><dt>Aplikasi</dt><dd>{identitas.nama} — {identitas.tagline || 'POS · WMS · Akuntansi'}</dd></div>
        <div><dt>Versi</dt><dd>{info.versi}</dd></div>
        <div><dt>Nama database</dt><dd>{info.namaDatabase}</dd></div>
        <div><dt>Ukuran database</dt><dd>{fmtUkuran(info.ukuranDb)}</dd></div>
        <div><dt>Jumlah migrasi</dt><dd>{info.migrasi}</dd></div>
      </dl>

      <h4 className="teks-redup">Ringkasan jumlah data</h4>
      <div className="ringkasan-data">
        {info.ringkasan.map((r) => (
          <div key={r.nama}>
            <strong>{formatAngka(r.jumlah)}</strong>
            <span>{r.nama}</span>
          </div>
        ))}
      </div>

      {pembaruan && (
        <p className={`teks-redup ${pembaruan.tersedia ? 'pembaruan-tersedia' : ''}`}>{pembaruan.pesan}</p>
      )}
    </section>
  );
}
