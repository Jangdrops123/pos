import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icon } from '../../components/Icon';
import { IconButton } from '../../components/IconButton';
import { Modal } from '../../components/crud/Modal';
import { beritahu } from '../../components/crud/Toast';
import { apiGet } from '../../lib/api';
import { formatRupiah, formatTanggal, formatTanggalWaktu } from '../../lib/format';
import { modePosTerakhir, rutePos, setModePosTerakhir } from '../../lib/pengguna';
import { DialogWa } from '../faktur/DialogWa';
import { DialogLayanan, strukDariSale, type BarisRiwayat, type DetailJual } from '../pos/DialogPos';
import { cetakStruk, pesanWaStruk, PROFIL_STRUK_BAWAAN, type ProfilStruk, type StrukData } from '../pos/struk';
import './penjualan.css';

type Tab = 'riwayat' | 'retur' | 'piutang';

interface BarisRetur {
  id: number;
  no_dokumen: string;
  tanggal: string;
  alasan: string | null;
  total: number;
  status: string;
  no_penjualan: string;
  pelanggan: string | null;
  kasir: string | null;
}

interface BarisPiutang {
  id: number;
  jatuh_tempo: string | null;
  total: number;
  terbayar: number;
  status: string;
  no_dokumen: string;
  tanggal: string;
  pelanggan: string | null;
  sisa: number;
}

const lencanaStatus = (s: string) =>
  s === 'disahkan' || s === 'lunas'
    ? 'lencana--aktif'
    : s === 'batal'
      ? 'lencana--bahaya'
      : 'lencana--netral';

/**
 * M3 + M7 — Tombol split "Transaksi Baru (POS)":
 * klik utama = buka POS mode terakhir; panah kecil = pilih mode (Foto / Tanpa Foto).
 * Tooltip teks saat hover/fokus, label aksesibilitas "Buka POS".
 */
function TombolPos({ tengah = false }: { tengah?: boolean }) {
  const navigate = useNavigate();
  const [buka, setBuka] = useState(false);
  const wadah = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!buka) return;
    const onDown = (e: MouseEvent) => {
      if (!wadah.current?.contains(e.target as Node)) setBuka(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setBuka(false);
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [buka]);

  const bukaMode = (mode: 'foto' | 'cepat') => {
    setModePosTerakhir(mode);
    setBuka(false);
    navigate(rutePos(mode));
  };

  return (
    <div className={`pos-split ${tengah ? 'pos-split--tengah' : ''}`} ref={wadah}>
      <button
        type="button"
        className="tombol tombol--primer pos-split__utama tombol-tip"
        data-tip="Buka POS"
        aria-label="Buka POS"
        onClick={() => navigate(rutePos(modePosTerakhir()))}
      >
        <Icon nama="pos" size={17} />
        Transaksi Baru (POS)
      </button>
      <button
        type="button"
        className="tombol tombol--primer pos-split__panah"
        data-tip="Pilih mode POS"
        aria-label="Pilih mode POS"
        aria-haspopup="menu"
        aria-expanded={buka}
        onClick={() => setBuka((b) => !b)}
      >
        <Icon nama={buka ? 'chevron-up' : 'chevron-down'} size={16} />
      </button>
      {buka && (
        <div className="pos-split__menu" role="menu">
          <button type="button" role="menuitem" onClick={() => bukaMode('foto')}>
            POS Mode Foto
          </button>
          <button type="button" role="menuitem" onClick={() => bukaMode('cepat')}>
            POS Mode Tanpa Foto
          </button>
        </div>
      )}
    </div>
  );
}

/** Halaman Penjualan: Riwayat | Retur | Piutang (tab = rute). */
export function PenjualanPage({ tab }: { tab: Tab }) {
  const [sibuk, setSibuk] = useState(true);
  const [riwayat, setRiwayat] = useState<BarisRiwayat[]>([]);
  const [retur, setRetur] = useState<BarisRetur[]>([]);
  const [piutang, setPiutang] = useState<BarisPiutang[]>([]);

  const [namaUsaha, setNamaUsaha] = useState('Toko Retail');
  const [profil, setProfil] = useState<ProfilStruk | null>(null);

  const [lihatId, setLihatId] = useState<number | null>(null);
  const [detail, setDetail] = useState<DetailJual | null>(null);
  const [waStruk, setWaStruk] = useState<StrukData | null>(null);
  const [layanan, setLayanan] = useState<BarisRiwayat | null>(null);

  const muat = useCallback(() => {
    setSibuk(true);
    return Promise.all([
      apiGet<{ data: BarisRiwayat[] }>('/api/pos/sales?per=100'),
      apiGet<{ data: BarisRetur[] }>('/api/pos/returns?per=100'),
      apiGet<{ data: BarisPiutang[] }>('/api/pos/receivables?per=100'),
    ])
      .then(([rw, rt, pg]) => {
        setRiwayat(rw.data);
        setRetur(rt.data);
        setPiutang(pg.data);
      })
      .catch((e: Error) => beritahu(e.message, 'galat'))
      .finally(() => setSibuk(false));
  }, []);

  useEffect(() => {
    void muat();
  }, [muat]);

  // Identitas toko + profil struk untuk cetak ulang / kirim (J3/J4).
  useEffect(() => {
    void Promise.all([
      apiGet<{ pengaturan: Record<string, string> }>('/api/meta'),
      apiGet<{ data: ProfilStruk[] }>('/api/struk/profil').catch(() => null),
    ])
      .then(([meta, sp]) => {
        setNamaUsaha(meta.pengaturan['nama_usaha'] || 'Toko Retail');
        if (sp) setProfil(sp.data.find((x) => x.bawaan) ?? sp.data[0] ?? null);
      })
      .catch(() => undefined);
  }, []);

  // Dialog "Lihat" — detail penjualan tersimpan.
  useEffect(() => {
    if (lihatId == null) {
      setDetail(null);
      return;
    }
    apiGet<{ data: DetailJual }>(`/api/pos/sales/${lihatId}`)
      .then((r) => setDetail(r.data))
      .catch((e: Error) => {
        beritahu(e.message, 'galat');
        setLihatId(null);
      });
  }, [lihatId]);

  const cetakUlang = async (s: BarisRiwayat) => {
    try {
      cetakStruk(await strukDariSale(s.id, namaUsaha), profil ?? PROFIL_STRUK_BAWAAN);
    } catch (e) {
      beritahu((e as Error).message, 'galat');
    }
  };

  const kirimStruk = async (s: BarisRiwayat) => {
    try {
      setWaStruk(await strukDariSale(s.id, namaUsaha));
    } catch (e) {
      beritahu((e as Error).message, 'galat');
    }
  };

  // Z1 — ribon "Riwayat | Retur | Piutang" DIHAPUS: ketiganya kini halaman
  // mandiri dari sub-menu sidebar (/penjualan, /penjualan/retur, /penjualan/piutang).
  const judulTab =
    tab === 'retur' ? 'Retur Penjualan' : tab === 'piutang' ? 'Piutang Penjualan' : 'Riwayat Penjualan';

  return (
    <div className="halaman">
      <section className="kartu">
        <div className="kartu__kepala">
          <div>
            <h3>{judulTab}</h3>
            <p className="teks-redup teks-kecil">
              {tab === 'retur'
                ? 'Daftar retur penjualan yang tercatat di POS.'
                : tab === 'piutang'
                  ? 'Piutang penjualan (kredit) beserta jatuh tempo dan pelunasannya.'
                  : 'Transaksi POS langsung tersimpan di sini — lihat, cetak ulang, kirim, atau retur.'}
            </p>
          </div>
          <TombolPos />
        </div>

        {/* ------------------------------ Riwayat ---------------------------- */}
        {tab === 'riwayat' &&
          (sibuk ? (
            <p className="teks-redup">Memuat…</p>
          ) : riwayat.length === 0 ? (
            <div className="penjualan-kosong">
              <p>Belum ada penjualan. Mulai transaksi pertama</p>
              <TombolPos tengah />
            </div>
          ) : (
            <div className="tabel-bungkus">
              <table className="tabel tabel--aksi">
                <thead>
                  <tr>
                    <th>No. Dokumen</th>
                    <th>Waktu</th>
                    <th>Pelanggan</th>
                    <th>Kasir</th>
                    <th>Metode</th>
                    <th className="rata-kanan">Total</th>
                    <th>Status</th>
                    <th className="kolom-aksi">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {riwayat.map((s) => (
                    <tr key={s.id}>
                      <td>{s.no_dokumen}</td>
                      <td className="whitespace-nowrap">{formatTanggalWaktu(s.tanggal)}</td>
                      <td>{s.pelanggan ?? 'Umum'}</td>
                      <td>{s.kasir ?? '—'}</td>
                      <td>{s.metode ?? '—'}</td>
                      <td className="rata-kanan whitespace-nowrap">
                        {formatRupiah(Number(s.total))}
                      </td>
                      <td>
                        <span className={`lencana ${lencanaStatus(s.status)}`}>{s.status}</span>
                      </td>
                      <td className="kolom-aksi">
                        <IconButton
                          label="Lihat detail"
                          ikon="eye"
                          ukuran="baris"
                          onClick={() => setLihatId(s.id)}
                        />
                        <IconButton
                          label="Cetak ulang struk"
                          ikon="printer"
                          ukuran="baris"
                          onClick={() => void cetakUlang(s)}
                        />
                        <IconButton
                          label="Kirim struk"
                          ikon="send"
                          ukuran="baris"
                          onClick={() => void kirimStruk(s)}
                        />
                        {s.status === 'disahkan' && (
                          <IconButton
                            label="Retur penjualan"
                            ikon="rotate-ccw"
                            ukuran="baris"
                            onClick={() => setLayanan(s)}
                          />
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}

        {/* ------------------------------- Retur ----------------------------- */}
        {tab === 'retur' && (
          <div className="tabel-bungkus">
            <table className="tabel">
              <thead>
                <tr>
                  <th>No. Retur</th>
                  <th>Tanggal</th>
                  <th>No. Penjualan</th>
                  <th>Pelanggan</th>
                  <th>Kasir</th>
                  <th>Alasan</th>
                  <th className="rata-kanan">Total</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {sibuk ? (
                  <tr>
                    <td className="tabel-kosong" colSpan={8}>
                      Memuat…
                    </td>
                  </tr>
                ) : retur.length === 0 ? (
                  <tr>
                    <td className="tabel-kosong" colSpan={8}>
                      Belum ada retur penjualan. Retur dibuat dari aksi Retur pada tab Riwayat.
                    </td>
                  </tr>
                ) : (
                  retur.map((x) => (
                    <tr key={x.id}>
                      <td>{x.no_dokumen}</td>
                      <td className="whitespace-nowrap">{formatTanggal(x.tanggal)}</td>
                      <td>{x.no_penjualan}</td>
                      <td>{x.pelanggan ?? 'Umum'}</td>
                      <td>{x.kasir ?? '—'}</td>
                      <td>{x.alasan ?? '—'}</td>
                      <td className="rata-kanan whitespace-nowrap">
                        {formatRupiah(Number(x.total))}
                      </td>
                      <td>
                        <span className={`lencana ${lencanaStatus(x.status)}`}>{x.status}</span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* ------------------------------ Piutang ---------------------------- */}
        {tab === 'piutang' && (
          <div className="tabel-bungkus">
            <table className="tabel">
              <thead>
                <tr>
                  <th>No. Penjualan</th>
                  <th>Tanggal</th>
                  <th>Pelanggan</th>
                  <th>Jatuh Tempo</th>
                  <th className="rata-kanan">Total</th>
                  <th className="rata-kanan">Terbayar</th>
                  <th className="rata-kanan">Sisa</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {sibuk ? (
                  <tr>
                    <td className="tabel-kosong" colSpan={8}>
                      Memuat…
                    </td>
                  </tr>
                ) : piutang.length === 0 ? (
                  <tr>
                    <td className="tabel-kosong" colSpan={8}>
                      Belum ada piutang. Piutang tercatat otomatis saat penjualan dibayar kredit.
                    </td>
                  </tr>
                ) : (
                  piutang.map((p) => (
                    <tr key={p.id}>
                      <td>{p.no_dokumen}</td>
                      <td className="whitespace-nowrap">{formatTanggal(p.tanggal)}</td>
                      <td>{p.pelanggan ?? '—'}</td>
                      <td className="whitespace-nowrap">{p.jatuh_tempo ? formatTanggal(p.jatuh_tempo) : '—'}</td>
                      <td className="rata-kanan whitespace-nowrap">{formatRupiah(Number(p.total))}</td>
                      <td className="rata-kanan whitespace-nowrap">{formatRupiah(Number(p.terbayar))}</td>
                      <td className="rata-kanan whitespace-nowrap">
                        <strong>{formatRupiah(Number(p.sisa))}</strong>
                      </td>
                      <td>
                        <span className={`lencana ${lencanaStatus(p.status)}`}>{p.status}</span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* ------------------------- Dialog "Lihat" --------------------------- */}
      {lihatId != null && (
        <Modal
          judul={detail ? `Penjualan ${detail.no_dokumen}` : 'Detail penjualan'}
          lebar="lebar"
          onTutup={() => setLihatId(null)}
        >
          {!detail ? (
            <p className="teks-redup">Memuat…</p>
          ) : (
            <div className="penjualan-detail">
              <div className="penjualan-detail__info">
                <div>
                  <span>Waktu</span>
                  <b>{formatTanggalWaktu(detail.tanggal)}</b>
                </div>
                <div>
                  <span>Pelanggan</span>
                  <b>{detail.pelanggan ?? 'Umum'}</b>
                </div>
                <div>
                  <span>Kasir</span>
                  <b>{detail.kasir ?? '—'}</b>
                </div>
                <div>
                  <span>Status</span>
                  <b>{detail.status}</b>
                </div>
                <div>
                  <span>Subtotal</span>
                  <b>{formatRupiah(Number(detail.subtotal))}</b>
                </div>
                <div>
                  <span>Diskon</span>
                  <b>{formatRupiah(Number(detail.diskon))}</b>
                </div>
                <div>
                  <span>Pajak</span>
                  <b>{formatRupiah(Number(detail.pajak))}</b>
                </div>
                <div>
                  <span>Total</span>
                  <b>{formatRupiah(Number(detail.total))}</b>
                </div>
              </div>

              <table className="tabel">
                <thead>
                  <tr>
                    <th>Produk</th>
                    <th>SKU</th>
                    <th className="rata-kanan">Qty</th>
                    <th className="rata-kanan">Harga</th>
                    <th className="rata-kanan">Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  {detail.items.map((i, n) => (
                    <tr key={`${i.product_id}-${n}`}>
                      <td>{i.nama_produk}</td>
                      <td>{i.sku}</td>
                      <td className="rata-kanan">{i.qty}</td>
                      <td className="rata-kanan">{formatRupiah(Number(i.harga))}</td>
                      <td className="rata-kanan">{formatRupiah(Number(i.subtotal))}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <h4 className="penjualan-detail__sub">Pembayaran</h4>
              <table className="tabel">
                <thead>
                  <tr>
                    <th>Metode</th>
                    <th className="rata-kanan">Jumlah</th>
                    <th>Referensi</th>
                  </tr>
                </thead>
                <tbody>
                  {detail.payments.length === 0 ? (
                    <tr>
                      <td className="tabel-kosong" colSpan={3}>
                        Belum ada pembayaran tercatat.
                      </td>
                    </tr>
                  ) : (
                    detail.payments.map((p, n) => (
                      <tr key={n}>
                        <td>{p.metode}</td>
                        <td className="rata-kanan">{formatRupiah(Number(p.jumlah))}</td>
                        <td>{p.referensi ?? '—'}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>

              {(detail.retur ?? []).length > 0 && (
                <>
                  <h4 className="penjualan-detail__sub">Retur</h4>
                  <table className="tabel">
                    <thead>
                      <tr>
                        <th>No. Retur</th>
                        <th>Tanggal</th>
                        <th className="rata-kanan">Total</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(detail.retur ?? []).map((r) => (
                        <tr key={r.id}>
                          <td>{r.no_dokumen}</td>
                          <td>{formatTanggal(r.tanggal)}</td>
                          <td className="rata-kanan">{formatRupiah(Number(r.total))}</td>
                          <td>
                            <span className={`lencana ${lencanaStatus(r.status)}`}>{r.status}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </>
              )}
            </div>
          )}
        </Modal>
      )}

      {/* ----------------- Retur dari daftar (PIN supervisor) --------------- */}
      {layanan && (
        <DialogLayanan
          namaUsaha={namaUsaha}
          profil={profil}
          langkahAwal={{ mode: 'retur', sale: layanan }}
          onSelesai={() => {
            setLayanan(null);
            void muat();
          }}
          onTutup={() => setLayanan(null)}
        />
      )}

      {/* --------------------------- Kirim struk ---------------------------- */}
      {waStruk && (
        <DialogWa
          faktur={{
            id: 0,
            no_faktur: waStruk.noDokumen,
            tanggal: waStruk.tanggal,
            total: waStruk.total,
          }}
          pihakNama={waStruk.pelanggan ?? ''}
          pesanLain={pesanWaStruk(waStruk)}
          onTutup={() => setWaStruk(null)}
        />
      )}
    </div>
  );
}
