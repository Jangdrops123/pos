import { useState } from 'react';
import { Modal } from '../../components/crud/Modal';
import { beritahu } from '../../components/crud/Toast';
import { apiPut } from '../../lib/api';
import { peranAktif, type Peran } from '../../lib/pengguna';
import { GRUP_KARTU, SEMUA_KARTU, type KartuTampil } from './tipe';

/**
 * Panel "Atur tampilan" Dashboard: tampilkan/sembunyikan setiap kartu
 * (pintasan, KPI, pengingat, grafik, tabel). Perubahan langsung disimpan
 * untuk pengguna; Admin juga bisa menetapkannya sebagai bawaan sebuah peran
 * (server: PUT /api/dashboard/kartu/bawaan).
 */
export function PanelAturTampilan({
  kartu,
  onUbah,
  onTutup,
}: {
  kartu: KartuTampil;
  onUbah: (kartu: KartuTampil) => void;
  onTutup: () => void;
}) {
  const peran = peranAktif();
  const [bawaanPeran, setBawaanPeran] = useState<Peran>('admin');

  async function simpanPerubahan(next: KartuTampil) {
    onUbah(next);
    try {
      await apiPut('/api/dashboard/kartu', { kartu: next });
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Gagal menyimpan tampilan.', 'galat');
    }
  }

  function alih(id: string) {
    void simpanPerubahan({ ...kartu, [id]: kartu[id] === false });
  }

  function aturUlang() {
    const next: KartuTampil = {};
    for (const id of SEMUA_KARTU) next[id] = true;
    void simpanPerubahan(next);
  }

  async function simpanBawaanPeran() {
    try {
      await apiPut('/api/dashboard/kartu/bawaan', { peran: bawaanPeran, kartu });
      beritahu(`Tampilan disimpan sebagai bawaan peran ${bawaanPeran}.`);
    } catch (e) {
      beritahu(e instanceof Error ? e.message : 'Gagal menyimpan bawaan peran.', 'galat');
    }
  }

  return (
    <Modal
      judul="Atur tampilan Dashboard"
      onTutup={onTutup}
      aksi={
        <>
          <button type="button" className="tombol tombol--netral" onClick={aturUlang}>
            Atur ulang (semua tampil)
          </button>
          <button type="button" className="tombol tombol--primer" onClick={onTutup}>
            Selesai
          </button>
        </>
      }
    >
      <p className="teks-redup teks-kecil" style={{ marginBottom: 14 }}>
        Pilih kartu yang ingin ditampilkan di Dashboard. Perubahan langsung tersimpan dan susunan
        kartu menyesuaikan sendiri.
      </p>

      {GRUP_KARTU.map((g) => (
        <div className="tampilan-grup" key={g.judul}>
          <h4>{g.judul}</h4>
          {g.kartu.map((k) => (
            <label className="tampilan-baris" key={k.id}>
              <input type="checkbox" checked={kartu[k.id] !== false} onChange={() => alih(k.id)} />
              <span>{k.label}</span>
            </label>
          ))}
        </div>
      ))}

      {peran === 'admin' && (
        <div className="tampilan-bawaan">
          <span>Tetapkan tampilan ini sebagai bawaan peran:</span>
          <select value={bawaanPeran} onChange={(e) => setBawaanPeran(e.target.value as Peran)}>
            <option value="admin">Admin</option>
            <option value="manajer">Manajer</option>
            <option value="kasir">Kasir</option>
          </select>
          <button type="button" className="tombol tombol--kecil" onClick={() => void simpanBawaanPeran()}>
            Simpan bawaan peran
          </button>
        </div>
      )}
    </Modal>
  );
}
