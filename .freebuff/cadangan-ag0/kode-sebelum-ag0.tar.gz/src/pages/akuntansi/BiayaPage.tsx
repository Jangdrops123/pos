import { useCallback, useEffect, useState } from 'react';
import { apiDelete, apiGet, apiPost } from '../../lib/api';
import { beritahu } from '../../components/crud/Toast';
import { Modal } from '../../components/crud/Modal';
import { peranAktif } from '../../lib/pengguna';
import { rp, type AkunKas, type KategoriKas, type MutasiKas } from './tipe';

const bisaUbah = (): boolean => ['admin', 'akuntan'].includes(peranAktif());

/**
 * PENGELUARAN / BIAYA (Akuntansi Dasar) — catat biaya operasional (kategori:
 * gaji, sewa, listrik, transport, lain-lain — bisa ditambah) dengan pilihan
 * rekening kas/bank. Setiap catatan = Kas Keluar + kategori pengeluaran.
 */
export function BiayaPage() {
  const [kategori, setKategori] = useState<KategoriKas[]>([]);
  const [akun, setAkun] = useState<AkunKas[]>([]);
  const [daftar, setDaftar] = useState<MutasiKas[]>([]);
  const [dari, setDari] = useState(`${new Date().getFullYear()}-01-01`);
  const [sampai, setSampai] = useState(new Date().toISOString().slice(0, 10));
  const [mode, setMode] = useState<false | 'biaya' | 'kategori'>(false);
  const [kirim, setKirim] = useState(false);

  const kosong = { tanggal: new Date().toISOString().slice(0, 10), akun_id: '', kategori_id: '', jumlah: '', keterangan: '' };
  const [form, setForm] = useState(kosong);
  const [namaKategori, setNamaKategori] = useState('');

  const muat = useCallback(async () => {
    const q = new URLSearchParams({ dari, sampai, tipe: 'keluar' });
    const r = await apiGet<{ data: MutasiKas[] }>(`/api/akuntansi/kas/mutasi?${q.toString()}`);
    // Hanya mutasi yang berkategori pengeluaran (biaya operasional).
    setDaftar(r.data.filter((m) => m.kategori));
  }, [dari, sampai]);

  useEffect(() => {
    void muat().catch((e: Error) => beritahu(e.message, 'galat'));
  }, [muat]);

  useEffect(() => {
    void Promise.all([
      apiGet<{ data: KategoriKas[] }>('/api/akuntansi/kategori?tipe=pengeluaran').then((r) => setKategori(r.data)),
      apiGet<{ data: AkunKas[] }>('/api/akuntansi/kas/akun').then((r) => setAkun(r.data.filter((a) => a.aktif))),
    ]).catch(() => undefined);
  }, []);

  const simpanBiaya = async () => {
    setKirim(true);
    try {
      await apiPost('/api/akuntansi/pengeluaran', {
        tanggal: form.tanggal,
        akun_id: Number(form.akun_id),
        kategori_id: Number(form.kategori_id),
        jumlah: Number(form.jumlah),
        keterangan: form.keterangan,
      });
      beritahu('Biaya tercatat sebagai Kas Keluar.', 'sukses');
      setMode(false);
      setForm(kosong);
      await muat();
    } catch (e) {
      beritahu((e as Error).message, 'galat');
    } finally {
      setKirim(false);
    }
  };

  const tambahKategori = async () => {
    setKirim(true);
    try {
      await apiPost('/api/akuntansi/kategori', { nama: namaKategori, tipe: 'pengeluaran' });
      beritahu('Kategori biaya ditambahkan.', 'sukses');
      setMode(false);
      setNamaKategori('');
      const r = await apiGet<{ data: KategoriKas[] }>('/api/akuntansi/kategori?tipe=pengeluaran');
      setKategori(r.data);
    } catch (e) {
      beritahu((e as Error).message, 'galat');
    } finally {
      setKirim(false);
    }
  };

  const hapusKategori = async (k: KategoriKas) => {
    try {
      await apiDelete(`/api/akuntansi/kategori/${k.id}`);
      beritahu(`Kategori "${k.nama}" dihapus/dinonaktifkan.`, 'sukses');
      const r = await apiGet<{ data: KategoriKas[] }>('/api/akuntansi/kategori?tipe=pengeluaran');
      setKategori(r.data);
    } catch (e) {
      beritahu((e as Error).message, 'galat');
    }
  };

  const total = daftar.reduce((n, m) => n + Number(m.jumlah), 0);

  return (
    <div className="halaman">
      <section className="kartu">
        <div className="kartu__kepala">
          <h3>Pengeluaran / Biaya</h3>
          {bisaUbah() && (
            <div className="aksi-kartu">
              <button type="button" className="tombol tombol--kecil" onClick={() => { setForm(kosong); setMode('biaya'); }}>+ Catat Biaya</button>
              <button type="button" className="tombol tombol--kecil" onClick={() => setMode('kategori')}>+ Kategori</button>
            </div>
          )}
        </div>
        <div className="alat-tabel">
          <label className="teks-kecil">Dari
            <input type="date" className="input-cari" value={dari} onChange={(e) => setDari(e.target.value)} />
          </label>
          <label className="teks-kecil">Sampai
            <input type="date" className="input-cari" value={sampai} onChange={(e) => setSampai(e.target.value)} />
          </label>
          <span className="teks-redup teks-kecil">Total biaya periode: <strong>{rp(total)}</strong></span>
        </div>
        <div className="tabel-bungkus">
          <table className="tabel">
            <thead>
              <tr>
                <th style={{ width: 100 }}>Tanggal</th>
                <th style={{ width: 150 }}>Nomor</th>
                <th>Kategori</th>
                <th>Rekening Kas</th>
                <th>Keterangan</th>
                <th className="rata-kanan" style={{ width: 130 }}>Jumlah</th>
              </tr>
            </thead>
            <tbody>
              {daftar.length === 0 && <tr><td colSpan={6} className="tabel-kosong">Belum ada biaya tercatat pada periode ini.</td></tr>}
              {daftar.map((m) => (
                <tr key={m.id}>
                  <td>{String(m.tanggal).slice(0, 10)}</td>
                  <td><code>{m.nomor}</code></td>
                  <td>{m.kategori ?? '—'}</td>
                  <td>{m.akun_kode} {m.akun_nama}</td>
                  <td>{m.keterangan ?? '—'}</td>
                  <td className="rata-kanan">{rp(m.jumlah)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="kartu">
        <div className="kartu__kepala"><h3>Kategori Biaya</h3></div>
        <div className="tabel-bungkus">
          <table className="tabel">
            <thead>
              <tr>
                <th>Nama</th>
                <th style={{ width: 90 }}>Status</th>
                <th style={{ width: 120 }}>Aksi</th>
              </tr>
            </thead>
            <tbody>
              {kategori.map((k) => (
                <tr key={k.id}>
                  <td>{k.nama}</td>
                  <td>{k.aktif ? 'Aktif' : 'Nonaktif'}</td>
                  <td>{bisaUbah() && <button type="button" className="tombol tombol--kecil" onClick={() => void hapusKategori(k)}>Hapus</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {mode === 'biaya' && (
        <Modal
          judul="Catat Pengeluaran / Biaya"
          lebar="sedang"
          onTutup={() => setMode(false)}
          aksi={
            <>
              <button type="button" className="tombol" onClick={() => setMode(false)}>Batal</button>
              <button type="button" className="tombol tombol--primer" disabled={kirim || !form.kategori_id || !form.akun_id || !(Number(form.jumlah) > 0)} onClick={() => void simpanBiaya()}>
                {kirim ? 'Menyimpan…' : 'Catat Biaya'}
              </button>
            </>
          }
        >
          <div className="form-grid">
            <label>
              Tanggal
              <input type="date" className="input-cari" value={form.tanggal} onChange={(e) => setForm({ ...form, tanggal: e.target.value })} />
            </label>
            <label>
              Jumlah (Rp)
              <input type="number" min={0} className="input-cari" value={form.jumlah} onChange={(e) => setForm({ ...form, jumlah: e.target.value })} />
            </label>
            <label>
              Kategori biaya
              <select className="input-pilih" value={form.kategori_id} onChange={(e) => setForm({ ...form, kategori_id: e.target.value })}>
                <option value="">— pilih kategori —</option>
                {kategori.filter((k) => k.aktif).map((k) => (
                  <option key={k.id} value={k.id}>{k.nama}</option>
                ))}
              </select>
            </label>
            <label>
              Rekening kas/bank (keluar)
              <select className="input-pilih" value={form.akun_id} onChange={(e) => setForm({ ...form, akun_id: e.target.value })}>
                <option value="">— pilih rekening —</option>
                {akun.map((a) => (
                  <option key={a.id} value={a.id}>{a.kode} — {a.nama}</option>
                ))}
              </select>
            </label>
            <label style={{ gridColumn: '1 / -1' }}>
              Keterangan
              <input className="input-cari" value={form.keterangan} onChange={(e) => setForm({ ...form, keterangan: e.target.value })} />
            </label>
          </div>
        </Modal>
      )}

      {mode === 'kategori' && (
        <Modal
          judul="Tambah Kategori Biaya"
          lebar="kecil"
          onTutup={() => setMode(false)}
          aksi={
            <>
              <button type="button" className="tombol" onClick={() => setMode(false)}>Batal</button>
              <button type="button" className="tombol tombol--primer" disabled={kirim || !namaKategori.trim()} onClick={() => void tambahKategori()}>
                {kirim ? 'Menyimpan…' : 'Tambah'}
              </button>
            </>
          }
        >
          <label>
            Nama kategori
            <input className="input-cari" value={namaKategori} onChange={(e) => setNamaKategori(e.target.value)} autoFocus />
          </label>
        </Modal>
      )}
    </div>
  );
}
