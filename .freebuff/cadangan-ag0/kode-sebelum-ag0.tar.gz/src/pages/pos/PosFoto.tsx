import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { beritahu } from '../../components/crud/Toast';
import { IconButton } from '../../components/IconButton';
import { Modal } from '../../components/crud/Modal';
import { ambilOpsi, apiDelete, apiGet, apiPost } from '../../lib/api';
import { formatRupiah } from '../../lib/format';
import { rutePos, setModePosTerakhir } from '../../lib/pengguna';
import {
  DialogBayar,
  DialogLayanan,
  DialogShiftBuka,
  DialogShiftTutup,
  DialogStruk,
  DialogTahan,
  DialogTertahan,
  type BarisTertahan,
} from './DialogPos';
import type { StrukData } from './struk';
import type { ProfilStruk } from './struk';
import {
  type BarisKeranjang,
  type Opsi,
  type ProdukPos,
  type ShiftAktif,
} from './tipe';
import { buangPindahMode, peekPindahMode, sebarDiskonKeBaris, simpanPindahMode } from './pindahMode';
import './pos.css';

type NamaDialog = 'bayar' | 'tahan' | 'tertahan' | 'shift-buka' | 'shift-tutup' | 'layanan' | null;

/** Debounce pencarian grid (J1) — grid hanya muncul setelah ketik. */
const DEBOUNCE_MS = 200;
/** Batas awal kartu hasil; sisanya lewat tombol "Tampilkan lebih banyak". */
const BATAS_AWAL = 24;

/**
 * X4.1/X4.2 — Foto produk dengan skeleton + fallback placeholder bertema.
 * Gagal muat (404/jaringan) jatuh ke inisial tanpa ikon rusak; peringatan
 * dicatat ke konsol, bukan ke pengguna.
 */
function FotoProduk({ src, nama, kategoriId }: { src: string | null; nama: string; kategoriId: number | null }) {
  const [adaGalat, setAdaGalat] = useState(false);
  const [sibuk, setSibuk] = useState(!!src);
  const inisial = nama
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((k) => k.charAt(0))
    .join('')
    .toUpperCase();
  // Warna aksen halus per kategori (turunkan hue dari id kategori).
  const hue = kategoriId ? (kategoriId * 47) % 360 : 220;

  if (!src || adaGalat) {
    return (
      <div
        className="pos-kartu__kosong"
        style={{ '--aksen-inisial': `hsl(${hue} 45% 55%)` } as React.CSSProperties}
        aria-hidden="true"
      >
        {inisial || ' Barang'}
      </div>
    );
  }
  return (
    <img
      className={`pos-kartu__foto ${sibuk ? 'pos-kartu__foto--skeleton' : ''}`}
      src={src}
      alt=""
      loading="lazy"
      decoding="async"
      onLoad={() => setSibuk(false)}
      onError={() => {
        console.warn(`[POS] Gagal memuat foto "${nama}" (${src}) — memakai placeholder.`);
        setAdaGalat(true);
        setSibuk(false);
      }}
    />
  );
}

/** Izinkan menjual barang stok habis? (opsi kasir, tersimpan lokal). */
const KUNCI_BOLEH_HABIS = 'nusapos.pos.boleh-habis';
const bacaBolehHabis = () => localStorage.getItem(KUNCI_BOLEH_HABIS) === 'true';

/* Y1.4 — ukuran kartu (kecil / sedang / besar): dipilih lewat ikon di bilah atas
   dan disimpan per pengguna. Nilai = lebar minimum kartu (token --kartu-min). */
type UkuranKartu = 'kecil' | 'sedang' | 'besar';
const KUNCI_UKURAN_KARTU = 'nusapos.pos.kartu-ukuran';
const URUTAN_UKURAN: UkuranKartu[] = ['kecil', 'sedang', 'besar'];
const UKURAN_PX: Record<UkuranKartu, string> = { kecil: '132px', sedang: '160px', besar: '196px' };
const LABEL_UKURAN: Record<UkuranKartu, string> = { kecil: 'Kecil', sedang: 'Sedang', besar: 'Besar' };
function bacaUkuranKartu(): UkuranKartu {
  const v = localStorage.getItem(KUNCI_UKURAN_KARTU);
  return (URUTAN_UKURAN as string[]).includes(v ?? '') ? (v as UkuranKartu) : 'sedang';
}

/**
 * POS Mode Foto — layar penuh kasir:
 *   kiri grid kartu produk (foto, nama, harga, stok), kanan keranjang;
 *   keyboard penuh (F2/F4/F8/F9, panah, +/-, Delete, Esc), scan barcode,
 *   pembayaran campuran, shift kasir, void & retur PIN supervisor.
 */
export function PosFoto() {
  const navigate = useNavigate();
  // M5 — isi keranjang dipindahkan dari mode lain (dibaca sekali saat mount).
  const [pindahan] = useState(peekPindahMode);
  const [konfirmasiMode, setKonfirmasiMode] = useState(false);
  const [produk, setProduk] = useState<ProdukPos[]>([]);
  const [pengaturan, setPengaturan] = useState({
    pajak_persen: 0,
    nama_usaha: 'Toko Retail',
    alamat_usaha: '',
    telepon_usaha: '',
    logo_usaha: '',
  });
  const [cari, setCari] = useState('');
  const [kategoriId, setKategoriId] = useState<number | null>(null);
  const [gudangOpsi, setGudangOpsi] = useState<Opsi[]>([]);
  const [gudangId, setGudangId] = useState(0);
  const [shift, setShift] = useState<ShiftAktif | null>(null);
  const [keranjang, setKeranjang] = useState<BarisKeranjang[]>(() => pindahan?.items ?? []);
  const [diskon, setDiskon] = useState(() =>
    pindahan && pindahan.diskon > 0 ? String(pindahan.diskon) : '',
  );
  const [pajakPersen, setPajakPersen] = useState(0);
  const [fokus, setFokus] = useState(0);
  const [barisTerpilih, setBarisTerpilih] = useState(0);
  const [dialog, setDialog] = useState<NamaDialog>(null);
  const [struk, setStruk] = useState<StrukData | null>(null);
  const [bantuanTerbuka, setBantuanTerbuka] = useState(false);
  // BAGIAN J1 — barang tampil hanya setelah dicari (debounce 200ms, batas 24).
  const [kataTunda, setKataTunda] = useState('');
  const [batas, setBatas] = useState(BATAS_AWAL);
  // BAGIAN J3/J4 — profil struk aktif & cetak otomatis setelah bayar.
  const [profilStruk, setProfilStruk] = useState<ProfilStruk | null>(null);
  const [cetakOtomatis, setCetakOtomatis] = useState(false);
  // X4.3 — boleh tambah barang stok habis (opsi kasir, tersimpan lokal).
  const [bolehHabis, setBolehHabis] = useState(bacaBolehHabis);
  // Y1.4 — ukuran kartu per pengguna; Y1.1 — rasio gambar dari pengaturan POS;
  // Y1.4 — keranjang menjadi laci bawah pada layar sempit (<1024px).
  const [ukuranKartu, setUkuranKartu] = useState<UkuranKartu>(bacaUkuranKartu);
  const [rasioFoto, setRasioFoto] = useState('1/1');
  const [laciBuka, setLaciBuka] = useState(false);

  const cariRef = useRef<HTMLInputElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const bufferPindai = useRef<string[]>([]);
  const waktuPindai = useRef(0);
  const stateTerbaru = useRef({ keranjang, dialog, struk, fokus, terlihat: [] as ProdukPos[], barisTerpilih, gudangId, produk });
  const cariRefValue = useRef(cari);

  const stokGudang = (p: ProdukPos): number => Number(p.stok_gudang[String(gudangId)] ?? 0);

  const kategori = useMemo(() => {
    const peta = new Map<number, string>();
    for (const p of produk) if (p.category_id && p.kategori) peta.set(p.category_id, p.kategori);
    return [...peta.entries()].sort((a, b) => a[1].localeCompare(b[1]));
  }, [produk]);

  // Debounce kata kunci → grid hanya menyala setelah pengguna mengetik (J1).
  useEffect(() => {
    const t = setTimeout(() => {
      setKataTunda(cari.trim());
      setFokus(0);
      setBatas(BATAS_AWAL);
    }, DEBOUNCE_MS);
    return () => clearTimeout(t);
  }, [cari]);

  // Pencarian multi-kata: SEMUA kata harus cocok di nama / kode / SKU / barcode.
  const terlihatSemua = useMemo(() => {
    const kata = kataTunda.toLowerCase().split(/\s+/).filter(Boolean);
    return produk.filter((p) => {
      if (kategoriId !== null && p.category_id !== kategoriId) return false;
      if (kata.length === 0) return kategoriId !== null; // tanpa kata: hanya chip kategori
      const serendah = [p.nama, p.kode_item ?? '', p.sku, p.barcode ?? ''].join(' ').toLowerCase();
      return kata.every((k) => serendah.includes(k));
    });
  }, [produk, kataTunda, kategoriId]);

  const terlihat = useMemo(() => terlihatSemua.slice(0, batas), [terlihatSemua, batas]);
  /** Grid tampil hanya bila ada kata kunci atau chip kategori terpilih (J1). */
  const gridTampil = kataTunda !== '' || kategoriId !== null;

  // Sinkronkan snapshot terbaru untuk handler keyboard global.
  stateTerbaru.current = { keranjang, dialog, struk, fokus, terlihat, barisTerpilih, gudangId, produk };
  cariRefValue.current = cari;

  /* ------------------------- muat data awal ------------------------------ */
  // M4/M6 — catat mode ini sebagai mode POS terakhir (tombol POS / F9),
  // dan buang payload pindahan mode setelah dipakai.
  useEffect(() => {
    setModePosTerakhir('foto');
    buangPindahMode();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const [g, s, go, meta, struk] = await Promise.all([
          apiGet<{
            data: ProdukPos[];
            pengaturan: { pajak_persen: number; nama_usaha: string; pos_foto_rasio?: string };
          }>('/api/pos/produk'),
          apiGet<{ data: ShiftAktif | null }>('/api/pos/shift/aktif'),
          ambilOpsi('gudang'),
          apiGet<{ pengaturan: Record<string, string> }>('/api/meta'),
          apiGet<{ data: ProfilStruk[]; pengaturan: { cetak_otomatis: boolean } }>('/api/struk/profil').catch(() => null),
        ]);
        setProduk(g.data);
        setPengaturan({
          pajak_persen: Number(g.pengaturan.pajak_persen) || 0,
          nama_usaha: g.pengaturan.nama_usaha,
          alamat_usaha: meta.pengaturan['alamat_usaha'] ?? '',
          telepon_usaha: meta.pengaturan['telepon_usaha'] ?? '',
          logo_usaha: meta.pengaturan['logo_usaha'] ?? '',
        });
        setPajakPersen(Number(g.pengaturan.pajak_persen) || 0);
        // Y1.1 — rasio gambar kartu mengikuti pengaturan POS (bawaan 1:1).
        setRasioFoto(g.pengaturan.pos_foto_rasio === '4/3' ? '4/3' : '1/1');
        setShift(s.data);
        setGudangOpsi(go);
        if (struk) {
          setProfilStruk(struk.data.find((x) => x.bawaan) ?? struk.data[0] ?? null);
          setCetakOtomatis(Boolean(struk.pengaturan?.cetak_otomatis));
        }
        // Gudang default: yang menampung stok terbanyak (agar kartu menampilkan stok nyata).
        const skor = new Map<number, number>();
        for (const p of g.data) for (const [wid, q] of Object.entries(p.stok_gudang)) skor.set(Number(wid), (skor.get(Number(wid)) ?? 0) + Number(q));
        const terbaik = [...skor.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? go[0]?.id ?? 0;
        // M5 — gudang dipertahankan dari mode lain bila ada pindahan mode.
        setGudangId(pindahan?.gudangId || terbaik);
        cariRef.current?.focus();
      } catch (e) {
        beritahu((e as Error).message, 'galat');
      }
    })();
  }, []);

  // Fokuskan kartu yang sedang dipilih keyboard.
  useEffect(() => {
    const el = gridRef.current?.children[fokus] as HTMLElement | undefined;
    el?.scrollIntoView({ block: 'nearest' });
  }, [fokus, terlihat.length]);

  /* ------------------------- aksi keranjang ------------------------------ */

  // X4.2 — foto hasil unggah (massal/tunggal) tampil tanpa muat ulang halaman:
  // daftar produk disegarkan saat jendela kembali fokus atau ada event
  // 'produk-berubah' dari Master Produk.
  const segarkanProduk = useCallback(async () => {
    try {
      const g = await apiGet<{ data: ProdukPos[] }>('/api/pos/produk');
      setProduk(g.data);
    } catch {
      /* biarkan daftar lama — jaringan/endpoint sementara tidak tersedia */
    }
  }, []);

  useEffect(() => {
    const onSegar = () => void segarkanProduk();
    window.addEventListener('focus', onSegar);
    window.addEventListener('produk-berubah', onSegar);
    return () => {
      window.removeEventListener('focus', onSegar);
      window.removeEventListener('produk-berubah', onSegar);
    };
  }, [segarkanProduk]);

  /** true bila barang benar-benar masuk keranjang — dipakai umpan balik kartu (Y1.2). */
  const tambah = (p: ProdukPos): boolean => {
    const stok = stokGudang(p);
    const harga = Number(p.harga);
    if (harga <= 0) {
      beritahu(`${p.nama} belum punya harga jual — atur di Master › Produk.`, 'galat');
      return false;
    }
    if (stok <= 0 && !bolehHabis) {
      beritahu(`Stok ${p.nama} habis di gudang terpilih.`, 'galat');
      return false;
    }
    const i = keranjang.findIndex((b) => b.productId === p.id);
    const qtySkrg = i >= 0 ? keranjang[i].qty : 0;
    if (stok > 0 && qtySkrg + 1 > stok) {
      beritahu(`Stok ${p.nama} di gudang terpilih sisa ${stok}.`, 'galat');
      return false;
    }
    if (i >= 0) {
      setKeranjang(keranjang.map((b, idx) => (idx === i ? { ...b, qty: b.qty + 1 } : b)));
      setBarisTerpilih(i);
    } else {
      setKeranjang([
        ...keranjang,
        { productId: p.id, nama: p.nama, sku: p.sku, harga, qty: 1, stok },
      ]);
      setBarisTerpilih(keranjang.length);
    }
    // J1: kolom cari tetap fokus setelah barang ditambahkan.
    cariRef.current?.focus();
    return true;
  };

  // Y1.2 — umpan balik singkat saat kartu diklik: animasi kecil sekali jalan
  // (kelas dilepas lewat onAnimationEnd agar tidak menumpuk).
  const pukulKartu = (el: HTMLElement) => {
    el.classList.remove('pos-kartu--pukul');
    void el.offsetWidth; // paksa reflow supaya animasi bisa berjalan ulang
    el.classList.add('pos-kartu--pukul');
  };

  const ubahQty = (i: number, d: number) => {
    setKeranjang(keranjang.map((b, idx) => (idx === i ? { ...b, qty: Math.max(1, Math.min(b.stok, b.qty + d)) } : b)));
  };

  const hapusBaris = (i: number) => {
    if (i < 0 || i >= keranjang.length) return;
    setKeranjang(keranjang.filter((_, idx) => idx !== i));
    setBarisTerpilih(Math.max(0, Math.min(i, keranjang.length - 2)));
  };

  const kosongkanKeranjang = () => {
    if (keranjang.length === 0) return;
    setKeranjang([]);
    setDiskon('');
    setBarisTerpilih(0);
    beritahu('Keranjang dikosongkan.', 'info', 2500);
  };

  /* ------------------------- ganti mode POS (M5) ------------------------- */
  // Isi keranjang dibawa ke Mode Tanpa Foto: diskon kasir disebar ke baris
  // sehingga subtotal − diskon tetap sama di mode tujuan.
  const gantiKeTanpaFoto = () => {
    simpanPindahMode({
      dari: 'foto',
      items: sebarDiskonKeBaris(keranjang, Number(diskon) || 0),
      diskon: 0,
      gudangId,
    });
    setModePosTerakhir('cepat');
    navigate(rutePos('cepat'));
  };

  const tanyaGantiMode = () => {
    if (keranjang.length > 0) setKonfirmasiMode(true);
    else gantiKeTanpaFoto();
  };

  const pindaiBarcode = (kode: string): boolean => {
    const kunci = kode.trim().toLowerCase();
    if (!kunci) return false;
    const p = produk.find(
      (x) =>
        (x.barcode ?? '').toLowerCase() === kunci ||
        x.sku.toLowerCase() === kunci ||
        (x.kode_item ?? '').toLowerCase() === kunci,
    );
    if (p) {
      tambah(p);
      return true;
    }
    beritahu(`Barcode "${kode}" tidak ditemukan.`, 'galat');
    return false;
  };

  /* ------------------------- transaksi tertahan --------------------------- */
  const tahanTransaksi = async (nama: string) => {
    await apiPost('/api/pos/held', {
      nama,
      data: { items: keranjang, diskon: Number(diskon) || 0, pajak_persen: pajakPersen, gudangId },
    });
    setKeranjang([]);
    setDiskon('');
    setDialog(null);
    beritahu('Transaksi ditahan — lanjutkan dengan F9.', 'sukses');
  };

  const muatTertahan = async () => {
    setDialog('tertahan');
  };

  const lanjutkanTertahan = async (b: BarisTertahan) => {
    if (!b.data) return;
    setKeranjang(b.data.items ?? []);
    setDiskon(b.data.diskon ? String(b.data.diskon) : '');
    setPajakPersen(Number(b.data.pajak_persen ?? pajakPersen));
    if (b.data.gudangId) setGudangId(b.data.gudangId);
    await apiDelete(`/api/pos/held/${b.id}`);
    setDialog(null);
    beritahu('Transaksi tertahan dimuat kembali.', 'sukses');
  };

  /* ------------------------- total ---------------------------------------- */
  const subtotal = keranjang.reduce((a, b) => a + b.qty * b.harga, 0);
  const diskonNum = Math.max(0, Number(diskon.replace(/\D/g, '')) || 0);
  const dasar = Math.max(0, subtotal - diskonNum);
  const pajak = Math.round((dasar * pajakPersen) / 100);
  const total = dasar + pajak;

  const bukaBayar = () => {
    if (keranjang.length === 0) {
      beritahu('Keranjang kosong — pilih produk dulu (Enter).', 'info', 2500);
      return;
    }
    if (!shift) {
      beritahu('Buka kasir dulu sebelum bertransaksi.', 'galat');
      setDialog('shift-buka');
      return;
    }
    setDialog('bayar');
  };

  /* ------------------------- keyboard global ------------------------------ */
  const handlerRef = useRef<(e: KeyboardEvent) => void>(() => {});
  handlerRef.current = (e: KeyboardEvent) => {
    const s = stateTerbaru.current;
    const target = e.target as HTMLElement | null;
    const diInput =
      !!target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT' || target.isContentEditable);

    // Fungsi yang selalu aktif (kecuali saat dialog terbuka — biarkan modal yang mengurus).
    if (!s.dialog && !s.struk) {
      if (e.key === 'F2') {
        e.preventDefault();
        cariRef.current?.focus();
        cariRef.current?.select();
        return;
      }
      if (e.key === 'F4') {
        e.preventDefault();
        bukaBayar();
        return;
      }
      if (e.key === 'F8') {
        e.preventDefault();
        if (s.keranjang.length > 0) setDialog('tahan');
        return;
      }
      if (e.key === 'F9') {
        e.preventDefault();
        void muatTertahan();
        return;
      }
      if (e.key === 'F1' || e.key === '?') {
        e.preventDefault();
        setBantuanTerbuka((b) => !b);
        return;
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        if (diInput) {
          (target as HTMLInputElement).blur();
          return;
        }
        kosongkanKeranjang();
        return;
      }
    }
    if (s.dialog || s.struk) return;
    if (diInput) return;

    // Enter: akhiri scan barcode bila buffer terisi, kalau tidak tambah kartu fokus.
    if (e.key === 'Enter') {
      e.preventDefault();
      const buffer = bufferPindai.current.join('');
      bufferPindai.current = [];
      if (buffer.length >= 3) {
        pindaiBarcode(buffer);
        return;
      }
      const p = s.terlihat[s.fokus];
      if (p) tambah(p);
      return;
    }

    // Buffer pengetikan cepat = scanner barcode.
    if (e.key.length === 1) {
      const now = Date.now();
      if (now - waktuPindai.current > 60) bufferPindai.current = [];
      waktuPindai.current = now;
      bufferPindai.current.push(e.key);
      return;
    }

    const kolom = () => {
      const grid = gridRef.current;
      const kartu = grid?.firstElementChild as HTMLElement | null;
      if (!grid || !kartu) return 4;
      return Math.max(1, Math.floor((grid.clientWidth + 10) / (kartu.offsetWidth + 10)));
    };

    if (e.key === 'ArrowRight') {
      e.preventDefault();
      setFokus(Math.min(s.terlihat.length - 1, s.fokus + 1));
      return;
    }
    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      setFokus(Math.max(0, s.fokus - 1));
      return;
    }
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const langkah = e.key === 'ArrowDown' ? kolom() : -kolom();
      setFokus(Math.max(0, Math.min(s.terlihat.length - 1, s.fokus + langkah)));
      return;
    }
    if (e.key === '+' || e.key === '=') {
      e.preventDefault();
      ubahQty(s.barisTerpilih, 1);
      return;
    }
    if (e.key === '-' || e.key === '_') {
      e.preventDefault();
      ubahQty(s.barisTerpilih, -1);
      return;
    }
    if (e.key === 'Delete') {
      e.preventDefault();
      hapusBaris(s.barisTerpilih);
    }
  };

  useEffect(() => {
    const f = (e: KeyboardEvent) => handlerRef.current(e);
    window.addEventListener('keydown', f);
    return () => window.removeEventListener('keydown', f);
  }, []);

  /* ------------------------- render --------------------------------------- */
  return (
    <div className="pos-shell">
      <header className="pos-kepala">
        <div className="pos-kepala__judul">
          {/* M5 — jejak: Penjualan > POS (Mode Foto) */}
          <Link className="pos-jejak" to="/penjualan">
            Penjualan
          </Link>
          <span aria-hidden="true">›</span>
          POS (Mode Foto) <span>{pengaturan.nama_usaha}</span>
        </div>
        <div className="pos-kepala__tengah">
          {shift ? (
            <div className="pos-shift">
              <span>
                Shift aktif · Kas awal <b>{formatRupiah(Number(shift.kas_awal))}</b>
              </span>
              <span>
                <b>{shift.ringkasan?.jumlah_transaksi ?? 0}</b> transaksi · tunai <b>{formatRupiah(shift.ringkasan?.tunai ?? 0)}</b>
              </span>
              <button type="button" className="tombol" onClick={() => setDialog('shift-tutup')}>
                Tutup Kasir
              </button>
            </div>
          ) : (
            <div className="pos-shift pos-shift--tutup">
              <b>Shift belum dibuka</b>
              <button type="button" className="tombol tombol--primer" onClick={() => setDialog('shift-buka')}>
                Buka Kasir
              </button>
            </div>
          )}
        </div>
        <div className="pos-kepala__kanan">
          <button type="button" className="tombol" onClick={() => setDialog('layanan')}>
            Riwayat &amp; Layanan
          </button>
          <button type="button" className="pos-tombol-keluar" onClick={tanyaGantiMode}>
            Mode Tanpa Foto
          </button>
          {/* Y1.4 — ukuran kartu (kecil → sedang → besar), tersimpan per pengguna. */}
          <IconButton
            ikon="grid"
            label={`Ukuran kartu: ${LABEL_UKURAN[ukuranKartu]} — klik untuk mengganti`}
            arah="bawah"
            ukuran="toolbar"
            aktif={ukuranKartu !== 'sedang'}
            onClick={() => {
              setUkuranKartu((u) => {
                const baru = URUTAN_UKURAN[(URUTAN_UKURAN.indexOf(u) + 1) % URUTAN_UKURAN.length];
                localStorage.setItem(KUNCI_UKURAN_KARTU, baru);
                return baru;
              });
            }}
          />
          {/* Y1.3 — tombol "Pintasan (F1)" berupa ikon keyboard di bilah atas:
              latar solid, tidak menutupi kartu. */}
          <div className="pos-bantuan">
            {bantuanTerbuka && (
              <div className="pos-bantuan__panel">
                <h4>Pintasan keyboard</h4>
                <dl>
                  <dt>F2</dt>
                  <dd>Fokus pencarian</dd>
                  <dt>← ↑ ↓ →</dt>
                  <dd>Berpindah kartu produk</dd>
                  <dt>Enter</dt>
                  <dd>Tambah ke keranjang / scan</dd>
                  <dt>+ / −</dt>
                  <dd>Ubah jumlah item terpilih</dd>
                  <dt>Delete</dt>
                  <dd>Hapus item terpilih</dd>
                  <dt>F4</dt>
                  <dd>Bayar</dd>
                  <dt>F8</dt>
                  <dd>Tahan transaksi</dd>
                  <dt>F9</dt>
                  <dd>Transaksi tertahan</dd>
                  <dt>Esc</dt>
                  <dd>Tutup dialog / kosongkan</dd>
                </dl>
              </div>
            )}
            <IconButton
              ikon="keyboard"
              label="Pintasan (F1)"
              arah="bawah"
              ukuran="toolbar"
              aktif={bantuanTerbuka}
              onClick={() => setBantuanTerbuka((b) => !b)}
            />
          </div>
          <IconButton
            ikon="chevron-left"
            label="Kembali ke Penjualan"
            arah="bawah"
            ukuran="toolbar"
            onClick={() => navigate('/penjualan')}
          />
        </div>
      </header>

      <div className="pos-badan">
        <section className="pos-kiri">
          <div className="pos-filter">
            <div className="pos-cari">
              <span className="pos-cari__ikon" aria-hidden>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="11" cy="11" r="7" />
                  <path d="m20 20-3.5-3.5" />
                </svg>
              </span>
              <input
                ref={cariRef}
                autoFocus
                value={cari}
                placeholder="Cari nama / kode / SKU / barcode… (F2)"
                aria-label="Cari produk"
                onChange={(e) => {
                  setCari(e.target.value);
                  setFokus(0);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    // Scanner mengetik barcode ke kolom ini: Enter langsung menambah.
                    if (cari && pindaiBarcode(cari)) setCari('');
                  }
                }}
              />
            </div>
            <div className="pos-gudang">
              Gudang:
              <select value={gudangId} onChange={(e) => setGudangId(Number(e.target.value))}>
                {gudangOpsi.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.label}
                  </option>
                ))}
              </select>
            </div>
            <label className="pos-izin-habis" title="Opsional: barang stok habis masih boleh dimasukkan ke keranjang">
              <input
                type="checkbox"
                checked={bolehHabis}
                onChange={(e) => {
                  setBolehHabis(e.target.checked);
                  localStorage.setItem(KUNCI_BOLEH_HABIS, String(e.target.checked));
                }}
              />
              Jual stok habis
            </label>
          </div>

          <div className="pos-kategori">
            <button type="button" className={kategoriId === null ? 'aktif' : ''} onClick={() => setKategoriId(null)}>
              Semua
            </button>
            {kategori.map(([id, nama]) => (
              <button key={id} type="button" className={kategoriId === id ? 'aktif' : ''} onClick={() => setKategoriId(id)}>
                {nama}
              </button>
            ))}
          </div>

          <div
            className="pos-grid"
            ref={gridRef}
            role="list"
            aria-label="Produk"
            style={
              {
                // Y1.1/Y1.4 — lebar minimum kartu (ukuran per pengguna) & rasio gambar
                // (pengaturan POS) diumpan ke CSS lewat variabel.
                '--kartu-pengguna': UKURAN_PX[ukuranKartu],
                '--kartu-rasio': rasioFoto === '4/3' ? '4 / 3' : '1 / 1',
              } as React.CSSProperties
            }
          >
            {/* J1: sebelum ada kata kunci, tampilkan keadaan kosong yang rapi. */}
            {!gridTampil && (
              <div className="pos-grid__kosong">
                <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
                  <circle cx="11" cy="11" r="7" />
                  <path d="m20 20-3.5-3.5" />
                </svg>
                <p>Ketik nama, kode item, SKU, atau scan barcode untuk menampilkan barang.</p>
              </div>
            )}
            {gridTampil &&
              terlihat.map((p, i) => {
              const stok = stokGudang(p);
              const harga = p.harga;
              const habis = stok <= 0;
              // Y1.2 — badge status: habis (merah) / menipis (kuning) / aman (hijau).
              const menipis = !habis && p.stok_min > 0 && stok < p.stok_min;
              const labelStok = habis ? 'Habis' : menipis ? 'Menipis' : `Stok ${stok}`;
              const kelasStok = habis ? 'pos-kartu__stok--habis' : menipis ? 'pos-kartu__stok--menipis' : 'pos-kartu__stok--ada';
              return (
                <div className="pos-kartu__wrap" key={p.id}>
                  <button
                    type="button"
                    role="listitem"
                    tabIndex={i === fokus ? 0 : -1}
                    className={`pos-kartu ${i === fokus ? 'terpilih' : ''} ${habis ? 'pos-kartu--habis' : ''}`}
                    onFocus={() => setFokus(i)}
                    onMouseDown={(e) => {
                      e.preventDefault();
                      setFokus(i);
                      // Y1.2 — klik/tap menambah 1 ke keranjang + umpan balik singkat.
                      if (tambah(p)) pukulKartu(e.currentTarget);
                    }}
                    onAnimationEnd={(e) => {
                      if (e.animationName === 'pos-pukul') e.currentTarget.classList.remove('pos-kartu--pukul');
                    }}
                    title={habis ? 'Stok habis' : undefined}
                    aria-label={`${p.nama}, ${formatRupiah(harga)}, ${habis ? 'stok habis' : `stok ${stok}`}`}
                  >
                    {/* X4.2 — foto dengan skeleton & fallback placeholder bertema. */}
                    <FotoProduk src={p.foto_url} nama={p.nama} kategoriId={p.category_id} />
                    <div className="pos-kartu__isi">
                      <div className="pos-kartu__nama">{p.nama}</div>
                      <div className="pos-kartu__sku">{p.sku}</div>
                      {/* Y1.2 — harga kiri, badge stok kanan; boleh turun baris (wrap). */}
                      <div className="pos-kartu__bawah">
                        <span className="pos-kartu__harga">{formatRupiah(harga)}</span>
                        <span
                          className={`pos-kartu__stok ${kelasStok}`}
                          title={habis ? 'Stok habis' : undefined}
                        >
                          {labelStok}
                        </span>
                      </div>
                    </div>
                  </button>
                </div>
              );
            })}
            {gridTampil && terlihatSemua.length === 0 && (
              <p className="pos-keranjang__kosong">Barang tidak ditemukan.</p>
            )}
            {gridTampil && terlihatSemua.length > batas && (
              <button
                type="button"
                className="pos-tombol-lebih"
                onClick={() => setBatas((b) => b + BATAS_AWAL)}
              >
                Tampilkan lebih banyak ({terlihatSemua.length - batas} sisanya)
              </button>
            )}
          </div>
        </section>

        {/* Y1.4 — layar sempit (<1024px): keranjang jadi laci bawah dengan
            pegangan yang menampilkan jumlah item & total tanpa membuka laci. */}
        <button
          type="button"
          className="pos-laci"
          aria-expanded={laciBuka}
          aria-label={laciBuka ? 'Tutup keranjang' : 'Buka keranjang'}
          onClick={() => setLaciBuka((b) => !b)}
        >
          <span className="pos-laci__item">{keranjang.length} item</span>
          <b>{formatRupiah(total)}</b>
          <span className="pos-laci__tanda" aria-hidden="true">
            {laciBuka ? '▾' : '▴'}
          </span>
        </button>

        <aside className={`pos-kanan ${laciBuka ? 'pos-kanan--buka' : ''}`}>
          <div className="pos-keranjang">
            {keranjang.length === 0 && <p className="pos-keranjang__kosong">Keranjang kosong — klik produk atau pindai barcode.</p>}
            {keranjang.map((b, i) => (
              <div
                key={b.productId}
                className={`pos-baris ${i === barisTerpilih ? 'terpilih' : ''}`}
                onClick={() => setBarisTerpilih(i)}
              >
                <div className="pos-baris__nama">{b.nama}</div>
                <div className="pos-baris__jumlah">{formatRupiah(b.qty * b.harga)}</div>
                <div className="pos-baris__sku">{b.sku}</div>
                <div className="pos-baris__kontrol">
                  <button type="button" onClick={() => ubahQty(i, -1)} aria-label={`Kurangi ${b.nama}`}>
                    −
                  </button>
                  <span className="pos-baris__qty">{b.qty}</span>
                  <button type="button" onClick={() => ubahQty(i, 1)} aria-label={`Tambah ${b.nama}`}>
                    +
                  </button>
                  <span className="pos-baris__harga">@ {formatRupiah(b.harga)}</span>
                  <button type="button" className="pos-baris__hapus" onClick={() => hapusBaris(i)} aria-label={`Hapus ${b.nama}`}>
                    ✕
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="pos-ringkas">
            <div className="r">
              <span>Subtotal</span>
              <span>{formatRupiah(subtotal)}</span>
            </div>
            <div className="r">
              <span>Diskon (Rp)</span>
              <input
                inputMode="numeric"
                placeholder="0"
                value={diskon}
                onChange={(e) => setDiskon(e.target.value.replace(/\D/g, ''))}
                aria-label="Diskon nominal"
              />
            </div>
            <div className="r">
              <span>Pajak (%)</span>
              <input
                inputMode="numeric"
                placeholder="0"
                value={String(pajakPersen)}
                onChange={(e) => setPajakPersen(Math.min(100, Number(e.target.value.replace(/\D/g, '')) || 0))}
                aria-label="Persentase pajak"
              />
            </div>
            <div className="r">
              <span>Pajak</span>
              <span>{formatRupiah(pajak)}</span>
            </div>
            <div className="pos-total">
              <span>TOTAL</span>
              <b>{formatRupiah(total)}</b>
            </div>
            <div className="pos-aksi">
              <button type="button" className="tombol" onClick={() => setDialog('tahan')} disabled={keranjang.length === 0}>
                Tahan (F8)
              </button>
              <button type="button" className="tombol" onClick={() => void muatTertahan()}>
                Tertahan (F9)
              </button>
              <button type="button" className="tombol pos-aksi-bayar" onClick={bukaBayar} disabled={keranjang.length === 0}>
                Bayar {formatRupiah(total)} (F4)
              </button>
            </div>
          </div>
        </aside>
      </div>

      {/* ------------------------- dialog ------------------------------------ */}
      {dialog === 'bayar' && (
        <DialogBayar
          total={total}
          items={keranjang}
          diskon={diskonNum}
          pajakPersen={pajakPersen}
          gudangId={gudangId}
          namaUsaha={pengaturan.nama_usaha}
          alamatUsaha={pengaturan.alamat_usaha || null}
          teleponUsaha={pengaturan.telepon_usaha || null}
          logoUrl={pengaturan.logo_usaha || null}
          onTutup={() => setDialog(null)}
          onSukses={(s) => {
            setStruk(s);
            setKeranjang([]);
            setDiskon('');
            setDialog(null);
            // Muat ulang stok grid agar angka segar.
            apiGet<{ data: ProdukPos[] }>('/api/pos/produk').then((g) => setProduk(g.data)).catch(() => undefined);
            apiGet<{ data: ShiftAktif | null }>('/api/pos/shift/aktif').then((sh) => setShift(sh.data)).catch(() => undefined);
          }}
        />
      )}
      {dialog === 'tahan' && <DialogTahan onSimpan={tahanTransaksi} onTutup={() => setDialog(null)} />}
      {dialog === 'tertahan' && <DialogTertahan onLanjut={lanjutkanTertahan} onTutup={() => setDialog(null)} />}
      {dialog === 'shift-buka' && (
        <DialogShiftBuka
          onTutup={() => setDialog(null)}
          onSukses={(sh) => {
            setShift(sh);
            setDialog(null);
            beritahu('Shift dibuka — selamat bertugas!', 'sukses');
          }}
        />
      )}
      {dialog === 'shift-tutup' && shift && (
        <DialogShiftTutup
          shift={shift}
          onTutup={() => setDialog(null)}
          onSukses={() => {
            setShift(null);
            beritahu('Shift ditutup.', 'sukses');
          }}
        />
      )}
      {dialog === 'layanan' && (
        <DialogLayanan namaUsaha={pengaturan.nama_usaha} profil={profilStruk} onTutup={() => setDialog(null)} />
      )}
      {struk && (
        <DialogStruk
          struk={struk}
          profil={profilStruk}
          cetakOtomatis={cetakOtomatis}
          onBaru={() => {
            setStruk(null);
            setKeranjang([]);
            cariRef.current?.focus();
          }}
          onTutup={() => setStruk(null)}
        />
      )}
      {/* M5 — konfirmasi ganti mode bila keranjang tidak kosong. */}
      {konfirmasiMode && (
        <Modal
          judul="Ganti mode POS?"
          lebar="kecil"
          onTutup={() => setKonfirmasiMode(false)}
          aksi={
            <>
              <button
                type="button"
                className="tombol tombol--netral"
                onClick={() => setKonfirmasiMode(false)}
              >
                Batal
              </button>
              <button
                type="button"
                className="tombol tombol--primer"
                onClick={() => {
                  setKonfirmasiMode(false);
                  gantiKeTanpaFoto();
                }}
              >
                Ganti mode
              </button>
            </>
          }
        >
          <p>
            Keranjang berisi <b>{keranjang.length}</b> baris. Isi keranjang akan dipindahkan ke{' '}
            <b>Mode Tanpa Foto</b> — tidak ada barang yang hilang.
          </p>
        </Modal>
      )}
    </div>
  );
}
