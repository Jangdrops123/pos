import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiGet } from '../../lib/api';
import { formatAngka, formatTanggal } from '../../lib/format';
import type { Arah } from './tipe';

type Sesi = Record<string, any>;

/**
 * O4 — Sesi opname yang sudah disahkan muncul di riwayat Item Masuk/Keluar
 * sebagai mutasi "Penyesuaian Opname" (dengan nomor OPN), tanpa input manual:
 * penyesuaian stoknya terjadi otomatis lewat kartu stok & jurnal saat pengesahan.
 * Arah mengikuti netto selisih: lebih (>= 0) → Item Masuk, kurang (< 0) → Item Keluar.
 */
export function PenyesuaianOpnameRiwayat({ arah }: { arah: Arah }) {
  const [data, setData] = useState<Sesi[]>([]);

  useEffect(() => {
    let hidup = true;
    void apiGet<{ data: Sesi[] }>('/api/opname?per=100&tahap=selesai')
      .then((r) => {
        if (!hidup) return;
        const netto = (s: Sesi) => Number(s.netto_selisih ?? 0);
        setData(r.data.filter((s) => (arah === 'masuk' ? netto(s) > 0 : netto(s) < 0)));
      })
      .catch(() => {
        if (hidup) setData([]);
      });
    return () => {
      hidup = false;
    };
  }, [arah]);

  if (data.length === 0) return null;

  return (
    <section className="kartu">
      <div className="kartu__kepala">
        <div>
          <h3>
            Penyesuaian Opname <span className="teks-redup">· {formatAngka(data.length)} sesi disahkan</span>
          </h3>
          <p className="teks-redup teks-kecil">
            Sesi opname yang sudah disahkan — penyesuaian stok terjadi otomatis lewat kartu stok &amp; jurnal
            (arah mengikuti netto selisih: {arah === 'masuk' ? 'lebih → masuk' : 'kurang → keluar'}).
          </p>
        </div>
      </div>
      <div className="tabel-bungkus">
        <table className="tabel">
          <thead>
            <tr>
              <th>Tanggal</th>
              <th>No. Opname</th>
              <th>Gudang</th>
              <th className="rata-kanan">Netto Selisih</th>
              <th className="rata-tengah">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {data.map((s) => (
              <tr key={s.id}>
                <td className="whitespace-nowrap teks-kecil">{formatTanggal(s.tanggal)}</td>
                <td>
                  <code>{s.no_dokumen}</code>
                </td>
                <td className="whitespace-nowrap">{s.gudang_kode}</td>
                <td className="rata-kanan nowrap">
                  {Number(s.netto_selisih ?? 0) >= 0 ? '+' : '−'}
                  {formatAngka(Math.abs(Number(s.netto_selisih ?? 0)))} unit
                </td>
                <td className="rata-tengah">
                  <Link className="tombol tombol--kecil tombol--netral" to={`/stok/opname/${s.id}`}>
                    Lihat Sesi
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
