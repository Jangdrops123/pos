import { useState } from 'react';
import { Modal } from '../../components/crud/Modal';
import { beritahu } from '../../components/crud/Toast';
import { bukaWa, formatWa62, nomorWaValid, pesanWaFaktur } from './aksi';

/**
 * Dialog "Kirim via WhatsApp" (BAGIAN I4): mengisi otomatis nomor faktur,
 * tanggal, total, dan tautan dokumen. Bila nomor kosong/tidak valid, pengguna
 * diminta mengisinya dulu; nomor otomatis diformat ke kode negara 62.
 */
export function DialogWa({
  faktur,
  namaToko,
  teleponAwal = '',
  pihakNama = '',
  pesanLain,
  onTutup,
}: {
  faktur: { id: number; no_faktur: string; tanggal: string; total: number };
  namaToko?: string;
  teleponAwal?: string;
  pihakNama?: string;
  /** Isi pesan lain (mis. struk POS) menggantikan pesan faktur otomatis. */
  pesanLain?: string;
  onTutup: () => void;
}) {
  const [nomor, setNomor] = useState(teleponAwal);
  const pesan = pesanLain ?? pesanWaFaktur(faktur, namaToko);

  const kirim = () => {
    if (!nomorWaValid(nomor)) {
      beritahu('Nomor WhatsApp belum valid — isi nomor dulu (contoh: 08123456789).', 'galat');
      return;
    }
    bukaWa(nomor, pesan);
    onTutup();
  };

  return (
    <Modal
      judul={`Kirim faktur ${faktur.no_faktur} via WhatsApp`}
      onTutup={onTutup}
      aksi={
        <>
          <button type="button" className="tombol tombol--netral" onClick={onTutup}>
            Batal
          </button>
          <button type="button" className="tombol tombol--primer" onClick={kirim}>
            Buka WhatsApp
          </button>
        </>
      }
    >
      <div className="faktur-wa">
        <label className="bidang">
          <span>Nomor WhatsApp{pihakNama ? ` (${pihakNama})` : ''}</span>
          <input
            type="tel"
            value={nomor}
            onChange={(e) => setNomor(e.target.value)}
            placeholder="08123456789 atau 628123456789"
            autoFocus
          />
          <small className="teks-redup">
            {nomor.trim()
              ? `Akan dikirim ke ${formatWa62(nomor) || '—'} (kode negara 62 otomatis).`
              : 'Nomor kosong — isi dulu sebelum dikirim.'}
          </small>
        </label>
        <div>
          <div className="teks-redup teks-kecil">Pesan otomatis:</div>
          <div className="faktur-wa__pratinjau">{pesan}</div>
        </div>
      </div>
    </Modal>
  );
}
