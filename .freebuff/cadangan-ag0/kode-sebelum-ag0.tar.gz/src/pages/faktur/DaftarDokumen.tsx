import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { IconButton } from '../../components/IconButton';
import { beritahu } from '../../components/crud/Toast';
import { apiGet } from '../../lib/api';
import { formatTanggal } from '../../lib/format';
import { DialogWa } from './DialogWa';
import { rupiah } from './tipe';
import './faktur.css';

type Baris = Record<string, any>;

/**
 * DAFTAR DOKUMEN (BAGIAN I1/I4) — faktur tersimpan yang bisa dibuka ulang.
 * Kolom Aksi berisi IKON SAJA dengan tooltip: Lihat, Kirim WhatsApp,
 * Simpan (PDF), Cetak.
 */
export function DaftarDokumen() {
  const navigasi = useNavigate();
  const [data, setData] = useState<Baris[]>([]);
  const [total, setTotal] = useState(0);
  const [hal, setHal] = useState(1);
  const [per] = useState(20);
  const [cari, setCari] = useState('');
  const [cariTunda, setCariTunda] = useState('');
  const [jenis, setJenis] = useState('');
  const [sibuk, setSibuk] = useState(false);
  const [dlgWa, setDlgWa] = useState<Baris | null>(null);
  // N5 — berkas laporan (jadwal otomatis & "Jalankan sekarang") tampil di sini.
  const [berkas, setBerkas] = useState<Baris[]>([]);

  useEffect(() => {
    const t = window.setTimeout(() => {
      setCariTunda(cari);
      setHal(1);
    }, 350);
    return () => window.clearTimeout(t);
  }, [cari]);

  const muat = useCallback(async () => {
    setSibuk(true);
    if (jenis === 'laporan') {
      try {
        const r = await apiGet<{ berkas: Baris[] }>('/api/laporan/tersimpan');
        setBerkas(r.berkas);
        setData([]);
        setTotal(0);
      } catch (err) {
        beritahu((err as Error).message, 'galat');
      } finally {
        setSibuk(false);
      }
      return;
    }
    try {
      const q = new URLSearchParams({ hal: String(hal), per: String(per), cari: cariTunda });
      if (jenis) q.set('jenis', jenis);
      const r = await apiGet<{ data: Baris[]; total: number }>(`/api/faktur?${q.toString()}`);
      setData(r.data);
      setTotal(r.total);
    } catch (err) {
      beritahu((err as Error).message, 'galat');
    } finally {
      setSibuk(false);
    }
  }, [hal, per, cariTunda, jenis]);

  useEffect(() => {
    void muat();
  }, [muat]);

  const totalHal = Math.max(1, Math.ceil(total / per));

  /** Cetak / simpan PDF: buka detail lalu cetak (dipicu lewat ?cetak=1). */
  const bukaDenganCetak = (b: Baris) => navigasi(`/dokumen/${b.id}?cetak=1`);

  const waDariDaftar = (b: Baris) =>
    setDlgWa({
      id: Number(b.id),
      no_faktur: String(b.no_faktur),
      tanggal: String(b.tanggal),
      total: Number(b.total),
      telepon: b.pihak_telepon ?? '',
      nama: b.pihak_nama ?? '',
    });

  return (
    <div className="halaman">
      <section className="kartu">
        <div className="kartu__kepala">
          <div>
            <h3>Daftar Dokumen</h3>
            <p className="teks-redup teks-kecil">
              Faktur penjualan &amp; pembelian yang dibuat otomatis saat transaksi disahkan — buka untuk
              melihat, mencetak, menyimpan PDF, atau mengirim via WhatsApp.
            </p>
          </div>
          <button type="button" className="tombol tombol--netral" onClick={() => void muat()} disabled={sibuk}>
            {sibuk ? 'Memuat…' : 'Muat ulang'}
          </button>
        </div>

        <div className="alat-tabel">
          <input
            className="input-cari"
            type="search"
            placeholder="Cari no. faktur / pihak / no. dokumen…"
            value={cari}
            onChange={(e) => setCari(e.target.value)}
            aria-label="Cari faktur"
          />
          <select
            className="input-pilih"
            value={jenis}
            onChange={(e) => setJenis(e.target.value)}
            aria-label="Filter jenis"
          >
            <option value="">Semua jenis</option>
            <option value="penjualan">Penjualan</option>
            <option value="pembelian">Pembelian</option>
            <option value="laporan">Laporan</option>
          </select>
        </div>

        <div className="tabel-bungkus">
          <table className="tabel tabel--aksi">
            <thead>
              <tr>
                <th>No. Faktur</th>
                <th>Tanggal</th>
                <th>Jenis</th>
                <th>Pihak</th>
                <th>Dokumen</th>
                <th className="rata-kanan">Total</th>
                <th>Status</th>
                <th className="rata-tengah">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {jenis === 'laporan' ? (
                berkas.length === 0 ? (
                  <tr>
                    <td className="tabel-kosong" colSpan={8}>
                      {sibuk
                        ? 'Memuat…'
                        : 'Belum ada berkas laporan. Jalankan laporan dari menu Laporan › Laporan Tersimpan.'}
                    </td>
                  </tr>
                ) : (
                  berkas.map((b) => (
                    <tr key={`laporan-${b.id}`}>
                      <td>{b.nama}</td>
                      <td>{formatTanggal(b.dibuat_pada)}</td>
                      <td>
                        <span className="lencana lencana--netral">Laporan</span>
                      </td>
                      <td>{b.laporan}</td>
                      <td>
                        {b.periode_dari} s/d {b.periode_sampai}
                      </td>
                      <td className="rata-kanan whitespace-nowrap">—</td>
                      <td>
                        <span className="lencana lencana--aktif">Tersimpan</span>
                      </td>
                      <td className="rata-tengah">
                        <div className="aksi-baris">
                          <IconButton
                            label="Buka laporan"
                            ikon="eye"
                            onClick={() => navigasi(`/laporan/l/${b.laporan}`)}
                          />
                        </div>
                      </td>
                    </tr>
                  ))
                )
              ) : data.length === 0 ? (
                <tr>
                  <td className="tabel-kosong" colSpan={8}>
                    {sibuk
                      ? 'Memuat…'
                      : 'Belum ada faktur. Faktur dibuat otomatis saat penjualan POS disahkan dan saat pembelian disahkan (GRN → Faktur).'}
                  </td>
                </tr>
              ) : (
                data.map((b) => (
                  <tr key={b.id}>
                    <td>
                      <Link to={`/dokumen/${b.id}`}>{b.no_faktur}</Link>
                    </td>
                    <td>{formatTanggal(b.tanggal)}</td>
                    <td>
                      <span className={`lencana ${b.jenis === 'penjualan' ? 'lencana--aktif' : 'lencana--netral'}`}>
                        {b.jenis === 'penjualan' ? 'Penjualan' : 'Pembelian'}
                      </span>
                    </td>
                    <td>{b.pihak_nama || '—'}</td>
                    <td>{b.no_sumber || '—'}</td>
                    <td className="rata-kanan whitespace-nowrap">{rupiah(Number(b.total))}</td>
                    <td>
                      <span className={`lencana ${b.status === 'batal' ? 'lencana--bahaya' : 'lencana--aktif'}`}>
                        {b.status === 'batal' ? 'Batal' : 'Terbit'}
                      </span>
                    </td>
                    <td className="rata-tengah">
                      <div className="aksi-baris">
                        <IconButton label="Lihat faktur" ikon="eye" onClick={() => navigasi(`/dokumen/${b.id}`)} />
                        <IconButton label="Kirim via WhatsApp" ikon="whatsapp" onClick={() => waDariDaftar(b)} />
                        <IconButton label="Simpan (PDF)" ikon="download" onClick={() => bukaDenganCetak(b)} />
                        <IconButton label="Cetak" ikon="printer" onClick={() => bukaDenganCetak(b)} />
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="paginasi">
          <span className="teks-redup teks-kecil">
            Hal {hal} dari {totalHal} · {total} dokumen
          </span>
          <div className="paginasi__kontrol">
            <button
              type="button"
              className="tombol tombol--kecil"
              disabled={hal <= 1 || sibuk}
              onClick={() => setHal((h) => Math.max(1, h - 1))}
            >
              ‹ Sebelumnya
            </button>
            <button
              type="button"
              className="tombol tombol--kecil"
              disabled={hal >= totalHal || sibuk}
              onClick={() => setHal((h) => Math.min(totalHal, h + 1))}
            >
              Berikutnya ›
            </button>
          </div>
        </div>
      </section>

      {dlgWa && (
        <DialogWa
          faktur={{
            id: Number(dlgWa.id),
            no_faktur: String(dlgWa.no_faktur),
            tanggal: String(dlgWa.tanggal),
            total: Number(dlgWa.total),
          }}
          teleponAwal={String(dlgWa.telepon ?? '')}
          pihakNama={String(dlgWa.nama ?? '')}
          onTutup={() => setDlgWa(null)}
        />
      )}
    </div>
  );
}
