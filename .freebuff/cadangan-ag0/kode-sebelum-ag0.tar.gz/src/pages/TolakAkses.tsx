import { Link } from 'react-router-dom';
import { tujuanHalamanAwal } from '../lib/pengguna';

/**
 * TAHAP 2 — Halaman "Tidak punya akses".
 *
 * Ditampilkan saat sebuah URL langsung dibuka namun peran/pengguna tidak
 * memiliki izin modul tersebut (sidebar sudah menyembunyikan menunya).
 */
export function TolakAkses({ pesan }: { pesan?: string }) {
  return (
    <section className="kartu tolak-akses">
      <div className="kartu__kepala">
        <h3>Tidak punya akses</h3>
      </div>
      <p className="teks-redup">
        {pesan ??
          'Peran ini tidak memiliki izin untuk membuka halaman tersebut. Menu yang tidak diizinkan tidak muncul di sidebar, dan alamat langsung pun tetap diblokir.'}
      </p>
      <p className="teks-redup">
        Minta Admin mengubah Hak Akses di Pengaturan ▸ Halaman Awal &amp; Peran, atau hubungi Admin untuk
        penyesuaian peran Anda.
      </p>
      <div className="tombol-baris">
        <Link to={tujuanHalamanAwal()} className="tombol tombol--primer">
          Kembali ke Halaman Awal
        </Link>
      </div>
    </section>
  );
}
