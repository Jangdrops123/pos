import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { App } from './App';
import { PenyediaSesi } from './lib/sesi';
import { muatIdentitas } from './lib/identitas';
import { terapkanTampilanBaru } from './lib/tampilanBaru';
import './styles.css';
import './crud.css';
// Tema gelap "glassmorphism" — dimuat terakhir agar menimpa gaya lama (murni tampilan).
import './theme-gelap.css';

// U2 — kepadatan tampilan (Nyaman/Padat/Longgar) & ukuran font dari preferensi
// pengguna, diterapkan sebelum render supaya tidak ada kedip.
terapkanTampilanBaru();

// X1.2 — judul tab & favicon mengikuti identitas aplikasi (cache + versi).
// Dijalankan berbarengan dengan render; layar muat (#root splash di index.html)
// menutup otomatis saat React merender.
void muatIdentitas().catch(() => {
  /* offline — pakai identitas bawaan / cache lokal */
});

const el = document.getElementById('root');
if (!el) throw new Error('Elemen #root tidak ditemukan');

createRoot(el).render(
  <StrictMode>
    <BrowserRouter>
      <PenyediaSesi>
        <App />
      </PenyediaSesi>
    </BrowserRouter>
  </StrictMode>,
);
