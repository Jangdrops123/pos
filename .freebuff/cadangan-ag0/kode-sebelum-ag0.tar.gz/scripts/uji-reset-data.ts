// Uji integrasi Reset Data (Pengaturan ▸ Database & Backup):
//   - ringkasan per modul, guard Admin utama, konfirmasi RESET + kata sandi
//   - urutan hapus detail → induk (jurnal disahkan, retur → penjualan, dst.)
//   - nomor urut dokumen kembali ke awal sesuai pilihan
//   - pengaturan & pengguna tetap (pilihan 1/2) vs kembali bawaan (total)
//   - log aktivitas tercatat, cadangan pengaman dibuat & bisa dipulihkan
//
// Jalankan pada DATABASE & PORT TERPISAH supaya data dev tidak tersentuh:
//   DB_FILE=data/uji-reset.db API_PORT=3017 npx tsx server/index.ts   (terminal 1)
//   DB_FILE=data/uji-reset.db API_PORT=3017 npx tsx scripts/uji-reset-data.ts (terminal 2)
import { DatabaseSync } from 'node:sqlite';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { pulihkanBackup } from '../server/lib/sistem.ts';
import { jalankanReset, type JenisReset } from '../server/lib/resetData.ts';
import { headerUji } from './sesi-uji.mjs';

const API_PORT = process.env.API_PORT ?? '3017';
const BASE = process.env.BASE ?? `http://127.0.0.1:${API_PORT}`;
const DB_FILE = process.env.DB_FILE ?? 'data/uji-reset.db';

const db = new DatabaseSync(DB_FILE);
db.exec('PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');

let lulus = 0;
let gagal = 0;
const cek = (nama: string, ok: boolean, info = '') => {
  if (ok) lulus++;
  else gagal++;
  console.log(`${ok ? '✔' : '✘'} ${nama}${info ? ` — ${info}` : ''}`);
};

async function req(method: string, url: string, body?: unknown, headers: Record<string, string> = {}) {
  const res = await fetch(`${BASE}${url}`, {
    method,
    headers: await headerUji(headers),
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let data: any = null;
  try {
    data = await res.json();
  } catch {
    /* bukan json */
  }
  return { status: res.status, data };
}

const q1 = (sql: string, ...p: unknown[]) => db.prepare(sql).get(...(p as never[])) as any;
const hitung = (tabel: string, saring = '') =>
  Number(q1(`SELECT COUNT(*) AS c FROM "${tabel}"${saring ? ` WHERE ${saring}` : ''}`)?.c ?? 0);
const ins = (sql: string, ...p: unknown[]) => Number(db.prepare(sql).run(...(p as never[])).lastInsertRowid);

/** Tabel yang dipertahankan (sama dengan keadaan awal hasil migrasi). */
const SIMPAN = new Set([
  'schema_migrations', 'roles', 'role_permissions', 'users', 'settings', 'accounts', 'periods',
  'cash_accounts', 'expense_categories', 'payment_method_accounts', 'struk_profil',
  'invoice_templates', 'size_profiles', 'size_profile_sizes', 'dashboard_layout',
  'dashboard_layout_peran', 'pengaturan_dashboard', 'pengaturan_dashboard_peran',
]);

const semuaTabel = () =>
  (db.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'`).all() as { name: string }[])
    .map((r) => r.name);

/** Kembalikan DB ke keadaan awal: hanya seed migrasi + akun admin. */
function bersihkan() {
  db.exec('PRAGMA foreign_keys = OFF');
  // Pemicu perlindungan dihormati saat pembersihan juga: jurnal disahkan
  // dibuka dulu, lalu tabel yang dicek pemicu "produk bertransaksi" dikosongkan
  // sebelum products.
  try {
    db.exec(`UPDATE journals SET status = 'batal' WHERE status = 'disahkan'`);
  } catch {
    /* belum ada jurnal */
  }
  for (const t of [
    'sale_items', 'purchase_items', 'opname_items', 'stock_ledger', 'stock_transfer_items', 'journal_lines',
  ]) {
    db.prepare(`DELETE FROM "${t}"`).run();
  }
  for (const t of semuaTabel()) if (!SIMPAN.has(t)) db.prepare(`DELETE FROM "${t}"`).run();
  db.exec(`DELETE FROM users WHERE username <> 'admin'`);
  // Rincian profil buatan ikut dihapus sebelum induknya (FK dimatikan sementara),
  // termasuk baris yatim peninggalan penghapusan lama.
  db.exec(
    `DELETE FROM size_profile_sizes WHERE profile_id IN (SELECT id FROM size_profiles WHERE bawaan = 0)
      OR profile_id NOT IN (SELECT id FROM size_profiles)`,
  );
  db.exec(`DELETE FROM size_profiles WHERE bawaan = 0`);
  db.exec(
    `DELETE FROM settings WHERE kunci IN ('gudang_bawaan', 'size_profile_default', 'peng.umum-regional.satuan_bawaan')`,
  );
  db.exec('PRAGMA foreign_keys = ON');
}

interface Fiks {
  adminId: number;
  kasirId: number;
  gudangId: number;
  gudang2Id: number;
  lokasiId: number;
  unitId: number;
  unit2Id: number;
  kategoriId: number;
  merekId: number;
  profilId: number;
  produkId: number;
  pelangganId: number;
  pemasokId: number;
  packId: number;
  shiftId: number;
}

/** Data uji: satu baris tiap tabel yang disentuh reset, ditandai 'Uji Reset'. */
function siapkan(): Fiks {
  const adminId = Number(q1(`SELECT id FROM users WHERE username = 'admin'`)!.id);
  const kasirId = ins(
    `INSERT INTO users (nama, username, password_hash, role_id) VALUES ('Kasir Uji Reset', 'rsx-kasir', '!', (SELECT id FROM roles WHERE nama = 'Kasir'))`,
  );
  const gudangId = ins(`INSERT INTO warehouses (kode, nama) VALUES ('RSX-GD', 'Gudang Uji Reset')`);
  const gudang2Id = ins(`INSERT INTO warehouses (kode, nama) VALUES ('RSX-GD2', 'Gudang Uji Reset 2')`);
  const lokasiId = ins(`INSERT INTO locations (warehouse_id, kode_lokasi, zona) VALUES (?, 'RSX-L1', 'Zona')`, gudangId);
  const unitId = ins(`INSERT INTO units (kode, nama) VALUES ('RSX-PCS', 'Pcs Uji Reset')`);
  const unit2Id = ins(`INSERT INTO units (kode, nama) VALUES ('RSX-DUS', 'Dus Uji Reset')`);
  const kategoriId = ins(`INSERT INTO categories (nama) VALUES ('Kategori Uji Reset')`);
  const merekId = ins(`INSERT INTO brands (nama) VALUES ('Merek Uji Reset')`);
  const profilId = ins(
    `INSERT INTO size_profiles (kode, nama, pasang_per_kodi, bawaan) VALUES ('rsx-custom', 'Profil Uji Reset', 20, 0)`,
  );
  db.prepare(`INSERT INTO size_profile_sizes (profile_id, size, jatah, urutan) VALUES (?, 'M', 4, 1)`).run(profilId);
  const produkId = ins(
    `INSERT INTO products (nama, sku, barcode, category_id, brand_id, satuan_dasar_id, harga_beli, harga_jual, size_profile_id)
     VALUES ('Produk Uji Reset', 'RSX-001', 'RSX899001', ?, ?, ?, 1000, 5000, ?)`,
    kategoriId, merekId, unitId, profilId,
  );
  db.prepare(`INSERT INTO unit_conversions (product_id, unit_id, jumlah_per_satuan_dasar) VALUES (?, ?, 12)`).run(produkId, unit2Id);
  const packId = ins(`INSERT INTO packs (kode_box, nama) VALUES ('RSX-BOX', 'Box Uji Reset')`);
  db.prepare(`INSERT INTO pack_items (pack_id, product_id, qty) VALUES (?, ?, 1)`).run(packId, produkId);
  const pelangganId = ins(`INSERT INTO customers (nama, telepon) VALUES ('Pelanggan Uji Reset', '0812')`);
  const pemasokId = ins(`INSERT INTO suppliers (nama, telepon) VALUES ('Pemasok Uji Reset', '0813')`);

  // Stok & kartu stok.
  db.prepare(`INSERT INTO stock_balances (product_id, warehouse_id, qty) VALUES (?, ?, 5)`).run(produkId, gudangId);
  db.prepare(
    `INSERT INTO stock_ledger (product_id, warehouse_id, tipe_dokumen, dokumen_id, qty_masuk, saldo, nilai_unit)
     VALUES (?, ?, 'pembelian', NULL, 5, 5, 1000)`,
  ).run(produkId, gudangId);

  // Penjualan (disahkan) + turunannya + piutang + retur + faktur.
  const saleId = ins(
    `INSERT INTO sales (no_dokumen, kasir_id, customer_id, warehouse_id, subtotal, total, status)
     VALUES ('RSX-SJ-1', ?, ?, ?, 5000, 5000, 'disahkan')`,
    adminId, pelangganId, gudangId,
  );
  db.prepare(
    `INSERT INTO sale_items (sale_id, product_id, nama_produk, sku, qty, unit_id, harga, subtotal, hpp)
     VALUES (?, ?, 'Produk Uji Reset', 'RSX-001', 1, ?, 5000, 5000, 1000)`,
  ).run(saleId, produkId, unitId);
  db.prepare(`INSERT INTO sale_payments (sale_id, metode, jumlah) VALUES (?, 'tunai', 5000)`).run(saleId);
  db.prepare(
    `INSERT INTO receivables (sale_id, customer_id, jatuh_tempo, total, status) VALUES (?, ?, '2026-12-31', 5000, 'belum')`,
  ).run(saleId, pelangganId);
  const returId = ins(
    `INSERT INTO sale_returns (no_dokumen, sale_id, total, status) VALUES ('RSX-RET-1', ?, 5000, 'disahkan')`,
    saleId,
  );
  db.prepare(
    `INSERT INTO sale_return_items (return_id, product_id, nama_produk, sku, qty, harga) VALUES (?, ?, 'Produk Uji Reset', 'RSX-001', 1, 5000)`,
  ).run(returId, produkId);
  db.prepare(
    `INSERT INTO invoices (no_faktur, jenis, sumber_tipe, sumber_id, tanggal, subtotal, total, status)
     VALUES ('RSX-INV-1', 'penjualan', 'penjualan', ?, date('now'), 5000, 5000, 'terbit')`,
  ).run(saleId);

  // Pembelian (disahkan) + turunannya + hutang + log chat/scan.
  const beliId = ins(
    `INSERT INTO purchases (no_dokumen, supplier_id, warehouse_id, subtotal, total, status)
     VALUES ('RSX-PB-1', ?, ?, 1000, 1000, 'disahkan')`,
    pemasokId, gudangId,
  );
  db.prepare(
    `INSERT INTO purchase_items (purchase_id, product_id, nama_produk, sku, qty, harga_beli, subtotal)
     VALUES (?, ?, 'Produk Uji Reset', 'RSX-001', 1, 1000, 1000)`,
  ).run(beliId, produkId);
  db.prepare(
    `INSERT INTO payables (purchase_id, supplier_id, jatuh_tempo, total, status) VALUES (?, ?, '2026-12-31', 1000, 'belum')`,
  ).run(beliId, pemasokId);
  db.prepare(`INSERT INTO purchase_chat_logs (purchase_id, pesan_user) VALUES (?, 'pesan uji')`).run(beliId);
  db.prepare(
    `INSERT INTO purchase_scan_logs (purchase_id, barcode, tipe, product_id, user_id) VALUES (?, 'RSX899001', 'satuan', ?, ?)`,
  ).run(beliId, produkId, adminId);

  // Item Masuk, Opname, Transfer.
  const docId = ins(
    `INSERT INTO sub_stock_docs (no_dokumen, arah, warehouse_id, alasan, status, total_qty, jumlah_item)
     VALUES ('RSX-PSM-1', 'masuk', ?, 'temuan', 'disahkan', 1, 1)`,
    gudangId,
  );
  db.prepare(`INSERT INTO sub_stock_items (doc_id, product_id, qty) VALUES (?, ?, 1)`).run(docId, produkId);
  const opnId = ins(
    `INSERT INTO opname_sessions (no_dokumen, warehouse_id, location_id, status, penanggung_jawab_id)
     VALUES ('RSX-OPN-1', ?, ?, 'disahkan', ?)`,
    gudangId, lokasiId, adminId,
  );
  db.prepare(
    `INSERT INTO opname_items (session_id, product_id, location_id, qty_sistem, qty_fisik, selisih) VALUES (?, ?, ?, 5, 4, -1)`,
  ).run(opnId, produkId, lokasiId);
  const trfId = ins(
    `INSERT INTO stock_transfers (no_dokumen, dari_warehouse, ke_warehouse, status) VALUES ('RSX-TRF-1', ?, ?, 'disahkan')`,
    gudangId, gudang2Id,
  );
  db.prepare(`INSERT INTO stock_transfer_items (transfer_id, product_id, qty) VALUES (?, ?, 1)`).run(trfId, produkId);

  // Jurnal berstatus disahkan (memancing pemicu "jurnal tidak dapat diubah").
  const periodId = Number(q1('SELECT id FROM periods ORDER BY id LIMIT 1')!.id);
  const akun1 = Number(q1(`SELECT id FROM accounts ORDER BY id LIMIT 1`)!.id);
  const akun2 = Number(q1(`SELECT id FROM accounts ORDER BY id LIMIT 1 OFFSET 1`)!.id);
  const jurnalId = ins(
    `INSERT INTO journals (no_jurnal, period_id, sumber_tipe, status) VALUES ('RSX-JU-1', ?, 'manual', 'draft')`,
    periodId,
  );
  db.prepare(`INSERT INTO journal_lines (journal_id, account_id, debit, kredit) VALUES (?, ?, 1000, 0)`).run(jurnalId, akun1);
  db.prepare(`INSERT INTO journal_lines (journal_id, account_id, debit, kredit) VALUES (?, ?, 0, 1000)`).run(jurnalId, akun2);
  // Disahkan setelah baris lengkap (seimbang) — memancing pemicu
  // "jurnal disahkan tidak dapat diubah" saat reset menghapusnya.
  db.prepare(`UPDATE journals SET status = 'disahkan' WHERE id = ?`).run(jurnalId);

  // Kas, shift, tahanan POS.
  const kasId = Number(q1('SELECT id FROM cash_accounts ORDER BY id LIMIT 1')!.id);
  db.prepare(
    `INSERT INTO cash_transactions (tipe, nomor, cash_account_id, jumlah, keterangan) VALUES ('masuk', 'RSX-KAS-1', ?, 1000, 'uji')`,
  ).run(kasId);
  const shiftId = ins(`INSERT INTO cashier_shifts (user_id, kas_awal) VALUES (?, 100000)`, adminId);
  db.prepare(`INSERT INTO held_sales (kasir_id, data_json) VALUES (?, '{}')`).run(adminId);

  // Riwayat yang hanya dihapus Reset Total.
  const batchId = ins(
    `INSERT INTO import_batches (modul, nama_file, total_baris, baris_valid, status, user_id) VALUES ('produk', 'rsx.xlsx', 1, 1, 'selesai', ?)`,
    adminId,
  );
  db.prepare(`INSERT INTO import_errors (batch_id, nomor_baris, pesan) VALUES (?, 1, 'uji')`).run(batchId);
  const repId = ins(`INSERT INTO saved_reports (nama, laporan) VALUES ('Laporan Uji Reset', 'penjualan')`);
  db.prepare(`INSERT INTO report_files (saved_report_id, laporan, nama) VALUES (?, 'penjualan', 'rsx.pdf')`).run(repId);
  db.prepare(
    `INSERT INTO annual_processes (no_proses, gudang_id, sampai, periode_baru_dari, user_id) VALUES ('RSX-PT-1', ?, '2025-12-31', '2026-01-01', ?)`,
  ).run(gudangId, adminId);
  db.prepare(`INSERT INTO stores (kode, nama, warehouse_id) VALUES ('RSX', 'Toko Uji Reset', ?)`).run(gudangId);

  // Log aktivitas lama (harus bertahan pada reset pilihan 1 & 2).
  db.prepare(
    `INSERT INTO audit_logs (user_id, aksi, tabel, record_id, alasan) VALUES (?, 'tambah', 'products', '1', 'Log uji reset')`,
  ).run(adminId);
  db.prepare(
    `INSERT INTO audit_logs (user_id, aksi, tabel, record_id, alasan) VALUES (?, 'ubah', 'pengaturan', 'tema', 'Log uji reset')`,
  ).run(adminId);

  // Counter nomor urut: satu transaksi, satu non-transaksi (uji cakupan reset).
  db.prepare(`INSERT INTO document_counters (kunci, terakhir) VALUES ('inv-2099', 7)`).run();
  db.prepare(`INSERT INTO document_counters (kunci, terakhir) VALUES ('pb-2099-12', 5)`).run();
  db.prepare(`INSERT INTO document_counters (kunci, terakhir) VALUES ('rsx-lain-2099', 3)`).run();

  // Pengaturan kustom (harus bertahan pada reset 1 & 2, hilang pada total).
  db.prepare(`UPDATE settings SET nilai = 'Toko Uji Reset' WHERE kunci = 'nama_usaha'`).run();
  db.prepare(`INSERT OR REPLACE INTO settings (kunci, nilai, keterangan) VALUES ('gudang_bawaan', ?, 'uji')`).run(String(gudangId));
  db.prepare(`INSERT OR REPLACE INTO settings (kunci, nilai, keterangan) VALUES ('size_profile_default', 'rsx-custom', 'uji')`).run();
  db.prepare(
    `INSERT OR REPLACE INTO settings (kunci, nilai, keterangan) VALUES ('peng.umum-regional.satuan_bawaan', ?, 'uji')`,
  ).run(String(unitId));

  return {
    adminId, kasirId, gudangId, gudang2Id, lokasiId, unitId, unit2Id, kategoriId, merekId,
    profilId, produkId, pelangganId, pemasokId, packId, shiftId,
  };
}

/** Tabel yang harus kosong setelah Reset Transaksi. */
const TABEL_TRANSAKSI = [
  'sale_return_items', 'sale_returns', 'receivables', 'sale_payments', 'sale_items', 'sales',
  'held_sales', 'cashier_shifts', 'payments', 'invoices', 'payables', 'purchase_scan_logs',
  'purchase_chat_logs', 'purchase_items', 'purchases', 'sub_stock_items', 'sub_stock_docs',
  'opname_scans', 'opname_items', 'opname_sessions', 'stock_transfer_items', 'stock_transfers',
  'journal_lines', 'journals', 'cash_transactions', 'stock_ledger', 'stock_balances',
];

const TABEL_MASTER = [
  'unit_conversions', 'pack_items', 'products', 'packs', 'categories', 'brands', 'units',
  'customers', 'suppliers', 'locations', 'warehouses',
];

const cadanganDibuat: string[] = [];
const cadanganAwal = fs.existsSync('data/backups') ? fs.readdirSync('data/backups') : [];

/** Jalankan reset lewat API; bila gagal, ulangi langsung di proses ini untuk
 *  mendapatkan stack trace lengkap (balasan API hanya memuat pesan singkat). */
async function resetAtauDiag(jenis: string) {
  const r = await req('POST', '/api/pengaturan/sistem/reset', { jenis, konfirmasi: 'RESET', sandi: '1234' });
  if (r.status !== 200) {
    try {
      jalankanReset(jenis as JenisReset, null, 'admin');
      console.log(`  [diag] ${jenis}: reset langsung dari skrip → OK (hanya API yang gagal)`);
    } catch (e) {
      console.log(`  [diag] ${jenis}: reset langsung gagal:\n${(e as Error).stack ?? String(e)}`);
    }
  }
  return r;
}

async function main() {
  bersihkan();
  const f = siapkan();
  const tahun = new Date().getFullYear();

  /* ---------------- Langkah 1: ringkasan per modul ---------------- */
  let r = await req('GET', '/api/pengaturan/sistem/reset/ringkasan?jenis=transaksi');
  cek('ringkasan transaksi → 200', r.status === 200, `status ${r.status}`);
  const rt = r.data as any;
  cek(
    'ringkasan transaksi: modul penjualan/jurnal/stok terhitung',
    ['penjualan', 'jurnal', 'stok', 'pembelian'].every((k) => rt.modul.find((m: any) => m.kode === k)?.jumlah > 0),
    JSON.stringify(rt.modul.map((m: any) => `${m.kode}=${m.jumlah}`)),
  );
  cek('ringkasan transaksi: TANPA modul master', !rt.modul.some((m: any) => m.kode === 'produk'));
  cek('ringkasan transaksi: daftar dipertahankan terisi', Array.isArray(rt.dipertahankan) && rt.dipertahankan.length > 0);

  r = await req('GET', '/api/pengaturan/sistem/reset/ringkasan?jenis=master');
  const rm = r.data as any;
  cek(
    'ringkasan master: produk/pelanggan/pemasok/gudang ikut',
    ['produk', 'pelanggan', 'pemasok', 'gudang'].every((k) => rm.modul.find((m: any) => m.kode === k)?.jumlah > 0),
    JSON.stringify(rm.modul.map((m: any) => `${m.kode}=${m.jumlah}`)),
  );
  cek('ringkasan master > ringkasan transaksi', rm.total > rt.total, `${rm.total} vs ${rt.total}`);

  r = await req('GET', '/api/pengaturan/sistem/reset/ringkasan?jenis=total');
  const rg = r.data as any;
  cek(
    'ringkasan total: pengguna/pengaturan/toko/log ikut',
    ['pengguna', 'pengaturan', 'toko', 'log_aktivitas'].every((k) => rg.modul.find((m: any) => m.kode === k)?.jumlah >= 0),
    JSON.stringify(rg.modul.map((m: any) => `${m.kode}=${m.jumlah}`)),
  );
  cek('ringkasan total: pengguna terhitung 1 (selain admin)', rg.modul.find((m: any) => m.kode === 'pengguna')?.jumlah === 1);
  cek('ringkasan total: toko terhitung 1', rg.modul.find((m: any) => m.kode === 'toko')?.jumlah === 1);

  /* ---------------- Guard: hanya Admin utama ---------------- */
  r = await req('GET', '/api/pengaturan/sistem/reset/ringkasan?jenis=transaksi', undefined, { 'x-peran': 'manajer' });
  cek('ringkasan ditolak untuk Manajer (403)', r.status === 403, `status ${r.status}`);
  r = await req('POST', '/api/pengaturan/sistem/reset', { jenis: 'transaksi', konfirmasi: 'RESET', sandi: '1234' }, { 'x-peran': 'kasir' });
  cek('reset ditolak untuk Kasir (403)', r.status === 403, `status ${r.status}`);
  cek('data tetap utuh setelah penolakan peran', hitung('sales') === 1 && hitung('products') === 1);

  /* ---------------- Validasi input ---------------- */
  r = await req('POST', '/api/pengaturan/sistem/reset', { jenis: 'transaksi', sandi: '1234' });
  cek('tanpa konfirmasi RESET → 400', r.status === 400, `status ${r.status}`);
  r = await req('POST', '/api/pengaturan/sistem/reset', { jenis: 'transaksi', konfirmasi: 'reset', sandi: '1234' });
  cek('konfirmasi huruf kecil → 400', r.status === 400, `status ${r.status}`);
  r = await req('POST', '/api/pengaturan/sistem/reset', { jenis: 'transaksi', konfirmasi: 'RESET', sandi: 'salah' });
  cek('kata sandi salah → 401', r.status === 401, `status ${r.status}`);
  r = await req('POST', '/api/pengaturan/sistem/reset', { jenis: 'ngawur', konfirmasi: 'RESET', sandi: '1234' });
  cek('jenis tak dikenal → 400', r.status === 400, `status ${r.status}`);
  cek('validasi tidak mengubah data', hitung('sales') === 1 && hitung('products') === 1 && hitung('users') === 2);

  // Baris uji dihitung terpisah: sejak modul Log In (TAHAP 1), login berhasil/
  // gagal juga dicatat ke Log Aktivitas dan tidak boleh mengubah ekspektasi ini.
  const logSebelum = hitung('audit_logs', `alasan = 'Log uji reset'`);
  cek('log aktivitas berisi 2 baris uji', logSebelum === 2, String(logSebelum));

  /* ---------------- Reset Transaksi ---------------- */
  r = await resetAtauDiag('transaksi');
  cek('Reset Transaksi → 200', r.status === 200, `status ${r.status} ${r.data?.pesan ?? ''}`);
  const h1 = r.data as any;
  cek('laporan: dilewati kosong', Array.isArray(h1.dilewati) && h1.dilewati.length === 0, JSON.stringify(h1.dilewati));
  cek('laporan: nomor urut direset (2 counter transaksi)', h1.nomor_urut === 2, `nomor_urut=${h1.nomor_urut}`);
  cek('laporan: pengguna tidak dihapus', h1.pengguna_dihapus === 0, String(h1.pengguna_dihapus));
  cek('laporan: pengaturan tidak disentuh', h1.pengaturan === 0, String(h1.pengaturan));
  cek('cadangan pengaman dibuat', typeof h1.cadangan_pengaman === 'string' && h1.cadangan_pengaman.endsWith('.db'), String(h1.cadangan_pengaman));
  cadanganDibuat.push(h1.cadangan_pengaman);

  const kosong = TABEL_TRANSAKSI.filter((t) => hitung(t) > 0);
  cek('seluruh tabel transaksi kosong', kosong.length === 0, `sisa: ${kosong.join(', ')}`);
  const masterUtuh = TABEL_MASTER.filter((t) => hitung(t) === 0);
  cek('master data tetap utuh', masterUtuh.length === 0, `hilang: ${masterUtuh.join(', ')}`);
  cek('stok kembali 0 (saldo stok kosong)', hitung('stock_balances') === 0);
  cek('pengguna tetap (admin + kasir)', hitung('users') === 2, String(hitung('users')));
  cek('pengaturan kustom tetap', q1(`SELECT nilai FROM settings WHERE kunci = 'nama_usaha'`)?.nilai === 'Toko Uji Reset');
  cek(
    'counter transaksi direset, counter non-transaksi tetap',
    hitung('document_counters', `kunci LIKE 'inv%' OR kunci LIKE 'pb-%'`) === 0 &&
      hitung('document_counters', `kunci = 'rsx-lain-2099'`) === 1,
    JSON.stringify(db.prepare('SELECT kunci FROM document_counters').all()),
  );
  cek('log aktivitas lama tetap + 1 entri reset',
    hitung('audit_logs', `alasan = 'Log uji reset'`) === 2 &&
      hitung('audit_logs', `aksi = 'reset'`) === 1 &&
      hitung('audit_logs', `aksi = 'login'`) >= 1,
    `total=${hitung('audit_logs')} login=${hitung('audit_logs', `aksi = 'login'`)}`);
  const logReset = q1(`SELECT record_id, alasan, data_sesudah FROM audit_logs WHERE aksi = 'reset'`);
  cek(
    'entri log memuat jenis reset & cadangan',
    logReset?.record_id === 'transaksi' && String(logReset?.alasan ?? '').includes('Reset Transaksi') &&
      String(logReset?.data_sesudah ?? '').includes('cadangan_pengaman'),
    String(logReset?.alasan ?? ''),
  );

  // Nomor urut kembali ke awal: dokumen berikutnya nomor 0001.
  r = await req('POST', '/api/pembelian', {
    metode_input: 'biasa',
    supplier_id: f.pemasokId,
    warehouse_id: f.gudangId,
    items: [{ product_id: f.produkId, qty: 1, unit_id: null, harga_beli: 1000, diskon: 0 }],
  });
  const noBaru = String(r.data?.no_dokumen ?? r.data?.data?.no_dokumen ?? '');
  cek('dokumen baru nomor urut 0001', r.status === 201 && noBaru.endsWith('-0001'), `${r.status} ${noBaru}`);

  r = await req('GET', '/api/pengaturan/sistem/reset/ringkasan?jenis=transaksi');
  const pascaModul = (r.data as any).modul.find((m: any) => m.kode === 'pembelian')?.jumlah;
  cek('ringkasan pasca reset: tinggal dokumen baru (induk + item)', pascaModul === 2, `pembelian=${pascaModul}`);

  /* ---------------- Reset Transaksi + Master ---------------- */
  r = await resetAtauDiag('master');
  cek('Reset Master → 200', r.status === 200, `status ${r.status} ${r.data?.pesan ?? ''}`);
  const h2 = r.data as any;
  cadanganDibuat.push(h2.cadangan_pengaman);
  cek('laporan master: dilewati kosong', Array.isArray(h2.dilewati) && h2.dilewati.length === 0, JSON.stringify(h2.dilewati));

  const masterKosong = TABEL_MASTER.filter((t) => hitung(t) > 0);
  cek('seluruh tabel master kosong', masterKosong.length === 0, `sisa: ${masterKosong.join(', ')}`);
  cek('transaksi juga kosong', TABEL_TRANSAKSI.every((t) => hitung(t) === 0));
  cek('profil size bawaan dipertahankan', hitung('size_profiles', 'bawaan = 1') > 0 && hitung('size_profiles', 'bawaan = 0') === 0);
  cek('toko tetap, rujukan gudang dilepas', hitung('stores') === 1 && q1('SELECT warehouse_id FROM stores')?.warehouse_id === null);
  cek('riwayat proses tahunan tetap, rujukan gudang dilepas', hitung('annual_processes') === 1 && q1('SELECT gudang_id FROM annual_processes')?.gudang_id === null);
  cek('pengguna tetap', hitung('users') === 2);
  cek('pengaturan kustom tetap', q1(`SELECT nilai FROM settings WHERE kunci = 'nama_usaha'`)?.nilai === 'Toko Uji Reset');
  cek(
    'rujukan pengaturan yang menggantung dibersihkan',
    hitung('settings', `kunci IN ('gudang_bawaan','size_profile_default','peng.umum-regional.satuan_bawaan')`) === 0,
  );
  cek('log aktivitas bertambah entri reset', hitung('audit_logs', `aksi = 'reset'`) === 2, String(hitung('audit_logs', `aksi = 'reset'`)));

  /* ---------------- Reset Total ---------------- */
  // Cadangan pengaman Reset Total merekam kondisi SEBELUM reset dijalankan —
  // itulah isi yang harus kembali setelah pemulihan.
  const sebelumTotal = {
    pengguna: hitung('users'),
    produk: hitung('products'),
    pelanggan: hitung('customers'),
  };
  r = await resetAtauDiag('total');
  cek('Reset Total → 200', r.status === 200, `status ${r.status} ${r.data?.pesan ?? ''}`);
  const h3 = r.data as any;
  const cadanganTotal = String(h3.cadangan_pengaman);
  cadanganDibuat.push(cadanganTotal);
  cek('laporan total: dilewati kosong', Array.isArray(h3.dilewati) && h3.dilewati.length === 0, JSON.stringify(h3.dilewati));
  cek('laporan total: pengguna dihapus 1', h3.pengguna_dihapus === 1, String(h3.pengguna_dihapus));
  cek('laporan total: pengaturan dikembalikan', h3.pengaturan > 0, String(h3.pengaturan));

  cek('hanya akun Admin utama yang tersisa', hitung('users') === 1 && q1('SELECT username FROM users')?.username === 'admin');
  cek('peran & hak akses tetap', hitung('roles') >= 4);
  cek('COA, periode, kas/bank tetap', hitung('accounts') > 0 && hitung('periods') > 0 && hitung('cash_accounts') > 0);
  cek('template faktur & struk tetap', hitung('invoice_templates') === 3 && hitung('struk_profil') === 1);
  cek('toko, laporan, riwayat impor, riwayat proses habis',
    hitung('stores') + hitung('saved_reports') + hitung('import_batches') + hitung('annual_processes') === 0,
    `stores=${hitung('stores')} reports=${hitung('saved_reports')} impor=${hitung('import_batches')} proses=${hitung('annual_processes')}`);
  cek('counter seluruh dokumen direset', hitung('document_counters') === 0, String(hitung('document_counters')));
  cek('pengaturan kembali ke bawaan', q1(`SELECT nilai FROM settings WHERE kunci = 'nama_usaha'`)?.nilai === 'Toko Retail');
  cek('pin supervisor kembali bawaan (verifikasi tetap jalan)',
    q1(`SELECT nilai FROM settings WHERE kunci = 'pin_supervisor'`)?.nilai ===
      crypto.createHash('sha256').update('1234').digest('hex'));
  cek('pemetaan akun jurnal kembali bawaan', typeof q1(`SELECT nilai FROM settings WHERE kunci = 'akuntansi_pemetaan'`)?.nilai === 'string');
  cek('log lama habis, tersisa entri reset total', hitung('audit_logs') === 1 && hitung('audit_logs', `record_id = 'total'`) === 1,
    `baris=${hitung('audit_logs')}`);

  // Kata sandi masih diterima setelah pengaturan dibersihkan.
  r = await req('POST', '/api/pengaturan/sistem/reset', { jenis: 'transaksi', konfirmasi: 'RESET', sandi: '1234' });
  cek('reset lanjutan setelah Reset Total tetap valid', r.status === 200, `status ${r.status} ${r.data?.pesan ?? ''}`);
  cadanganDibuat.push((r.data as any)?.cadangan_pengaman);

  // Log aktivitas menampilkan reset (siapa, kapan, jenis).
  r = await req('GET', '/api/pengaturan/log/aktivitas?per=50');
  const adaReset = (r.data?.data ?? []).filter((x: any) => x.aksi === 'reset');
  cek('log aktivitas menampilkan reset', r.status === 200 && adaReset.length >= 1 && adaReset[0].alasan?.includes('Reset'),
    `jumlah=${adaReset.length}`);

  /* ---------------- Pulihkan dari Backup ---------------- */
  r = await req('POST', '/api/pengaturan/sistem/pulihkan', { nama: cadanganTotal, konfirmasi: 'PULIHKAN' });
  cek('pulihkan cadangan pengaman → 200', r.status === 200, `status ${r.status} ${r.data?.pesan ?? ''}`);
  if (r.status !== 200) {
    // Lacak baris SQL yang gagal (balasan API hanya memuat pesan singkat).
    try {
      pulihkanBackup(cadanganTotal);
      console.log('  [diag] pulih langsung dari skrip: OK');
    } catch (e) {
      console.log(`  [diag] pulih langsung dari skrip gagal:\n${(e as Error).stack ?? String(e)}`);
    }
  }
  cek('data kembali setelah pemulihan',
    hitung('users') === sebelumTotal.pengguna && hitung('products') === sebelumTotal.produk && hitung('customers') === sebelumTotal.pelanggan,
    `users=${hitung('users')}/${sebelumTotal.pengguna} produk=${hitung('products')}/${sebelumTotal.produk} pelanggan=${hitung('customers')}/${sebelumTotal.pelanggan}`);
  cek('pengaturan kustom kembali', q1(`SELECT nilai FROM settings WHERE kunci = 'nama_usaha'`)?.nilai === 'Toko Uji Reset');

  r = await req('POST', '/api/pengaturan/sistem/pulihkan', { nama: cadanganTotal, konfirmasi: 'salah' });
  cek('pulihkan tanpa konfirmasi PULIHKAN → 400', r.status === 400, `status ${r.status}`);

  // Unggahan file backup (.db) dari komputer.
  const berkas = fs.readFileSync(path.join('data/backups', cadanganTotal));
  const unggah = await fetch(`${BASE}/api/pengaturan/sistem/pulihkan/unggah?konfirmasi=PULIHKAN`, {
    method: 'POST',
    headers: await headerUji({ 'content-type': 'application/octet-stream' }),
    body: berkas,
  });
  const dataUnggah = (await unggah.json().catch(() => null)) as any;
  cek('unggah file backup → 200', unggah.status === 200, `${unggah.status} ${dataUnggah?.pesan ?? ''}`);
  if (dataUnggah?.nama) cadanganDibuat.push(String(dataUnggah.nama));
  cek('data kembali setelah pemulihan unggahan',
    hitung('users') === sebelumTotal.pengguna && hitung('products') === sebelumTotal.produk,
    `users=${hitung('users')}/${sebelumTotal.pengguna} produk=${hitung('products')}/${sebelumTotal.produk}`);

  const gagalUnggah = await fetch(`${BASE}/api/pengaturan/sistem/pulihkan/unggah?konfirmasi=PULIHKAN`, {
    method: 'POST',
    headers: await headerUji({ 'content-type': 'application/octet-stream' }),
    body: Buffer.from('ini bukan cadangan sqlite'),
  });
  cek('unggah berkas bukan SQLite → 400', gagalUnggah.status === 400, `status ${gagalUnggah.status}`);
  const tanpaKonfirmasi = await fetch(`${BASE}/api/pengaturan/sistem/pulihkan/unggah?konfirmasi=salah`, {
    method: 'POST',
    headers: await headerUji({ 'content-type': 'application/octet-stream' }),
    body: berkas,
  });
  cek('unggah tanpa konfirmasi PULIHKAN → 400', tanpaKonfirmasi.status === 400, `status ${tanpaKonfirmasi.status}`);

  /* ---------------- Bersihkan berkas cadangan uji ---------------- */
  for (const n of [...new Set(cadanganDibuat)]) {
    if (!n) continue;
    try {
      fs.unlinkSync(path.join('data', 'backups', n));
    } catch {
      /* sudah tidak ada */
    }
  }
  const hilang = cadanganAwal.filter((n) => !fs.existsSync(path.join('data', 'backups', n)));
  cek('cadangan lama tidak tersentuh rotasi', hilang.length === 0, hilang.join(', '));

  console.log(`\nHasil: ${lulus} lulus, ${gagal} gagal`);
  if (gagal) process.exit(1);
}

main().catch((e) => {
  // Berkas cadangan buatan uji tetap dibersihkan walau uji gagal, supaya tidak
  // menumpuk dan memicu rotasi yang menghapus cadangan asli pengguna.
  for (const n of [...new Set(cadanganDibuat)]) {
    if (!n) continue;
    try {
      fs.unlinkSync(path.join('data', 'backups', n));
    } catch {
      /* sudah tidak ada */
    }
  }
  console.error(e);
  process.exit(1);
});
