// Uji integrasi metode CHATBOT modul Pembelian/Inbound:
// 1) Parser aturan/regex mengurai 3 contoh spesifikasi (pemasok, produk, warna,
//    size/rentang, jumlah, satuan pcs/lusin/kodi/box, harga, diskon) tanpa API
//    eksternal, dengan penanda kuning + saran bila ambigu/tidak cocok.
// 2) Riwayat chat disimpan per dokumen (diklaim lewat chat_sesi saat draft
//    dibuat) dan dokumen masuk ke alur pengesahan yang sama.
// Master Produk tanpa varian: warna/size dibaca dari NAMA produk (satu produk
// = satu baris katalog), parser memilih product_id.
// Jalankan: npx tsx scripts/uji-chat.ts   (server API harus hidup di :3001)
import { DatabaseSync } from 'node:sqlite';
import { headerUji } from './sesi-uji.mjs';

const BASE = process.env.BASE ?? 'http://127.0.0.1:3001';
const db = new DatabaseSync('data/app.db');
db.exec('PRAGMA foreign_keys = ON');

let lulus = 0;
let gagal = 0;
const cek = (nama: string, ok: boolean, info = '') => {
  if (ok) lulus++;
  else gagal++;
  console.log(`${ok ? '✔' : '✘'} ${nama}${info ? ` — ${info}` : ''}`);
};

async function req(method: string, url: string, body?: unknown) {
  const res = await fetch(`${BASE}${url}`, {
    method,
    headers: await headerUji(),
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let data: any = null;
  try {
    data = await res.json();
  } catch {
    /* bukan json */
  }
  return { status: res.status, data };
}

const q1 = (sql: string, ...p: unknown[]) => db.prepare(sql).get(...(p as never[])) as any;
const semua = (sql: string, ...p: unknown[]) => db.prepare(sql).all(...(p as never[])) as any[];

/** Fiks UCH: produk contoh yang cocok dengan 3 teks spesifikasi.
    Nama membawa warna/size agar parser katalog (baca nama produk) mengenali. */
const CONTOH1 = 'beli dari Supplier A, kaos polos hitam size M 2 lusin harga 45000';
const CONTOH2 = 'sepatu sport putih 39-43 masing-masing 2 kodi @120000';
const CONTOH3 = 'kemeja flanel merah L 10 pcs, biru XL 5 pcs, diskon 5%';

interface Fiks {
  supId: number;
  gudangId: number;
  unitId: number;
  kpmM: number;
  kpmL: number;
  ssp: Record<string, number>; // size → product id
  kfm: number;
  kfb: number;
  amara: number;
}

const bersihkan = () => {
  const sup = semua(`SELECT id FROM suppliers WHERE nama = 'Supplier A'`).map((r) => Number(r.id));
  const supPh = sup.length ? sup.map(() => '?').join(',') : '-1';
  const docs = semua(
    `SELECT id FROM purchases WHERE supplier_id IN (${supPh})
        OR warehouse_id IN (SELECT id FROM warehouses WHERE kode = 'UCH-GD')`,
    ...sup,
  ).map((r) => Number(r.id));
  if (docs.length) {
    const dph = docs.map(() => '?').join(',');
    db.prepare(`DELETE FROM stock_ledger WHERE tipe_dokumen IN ('pembelian', 'pembelian_batal') AND dokumen_id IN (${dph})`).run(...docs);
    db.prepare(`DELETE FROM journals WHERE sumber_tipe = 'pembelian' AND sumber_id IN (${dph})`).run(...docs);
    db.prepare(`DELETE FROM payables WHERE purchase_id IN (${dph})`).run(...docs);
    db.prepare(`DELETE FROM purchase_items WHERE purchase_id IN (${dph})`).run(...docs);
    db.prepare(`DELETE FROM purchases WHERE id IN (${dph})`).run(...docs);
  }
  // Riwayat chat yang belum terklaim (tidak menempel di dokumen mana pun).
  db.prepare(`DELETE FROM purchase_chat_logs WHERE chat_sesi LIKE 'UCH-%' AND purchase_id IS NULL`).run();
  db.exec(`
    DELETE FROM stock_ledger WHERE product_id IN (SELECT id FROM products WHERE sku LIKE 'UCH-%');
    DELETE FROM stock_balances WHERE product_id IN (SELECT id FROM products WHERE sku LIKE 'UCH-%');
    DELETE FROM products WHERE sku LIKE 'UCH-%';
    DELETE FROM units WHERE kode = 'UCH-PCS';
    DELETE FROM locations WHERE kode_lokasi LIKE 'UCH-%';
    DELETE FROM warehouses WHERE kode = 'UCH-GD';
    DELETE FROM suppliers WHERE nama = 'Supplier A';
  `);
};

const siapkan = (): Fiks => {
  const supId = Number(db.prepare(`INSERT INTO suppliers (nama, telepon, termin_hari) VALUES ('Supplier A', '081200', 0)`).run().lastInsertRowid);
  const gudangId = Number(db.prepare(`INSERT INTO warehouses (kode, nama) VALUES ('UCH-GD', 'Gudang Uji Chat')`).run().lastInsertRowid);
  db.prepare(`INSERT INTO locations (warehouse_id, kode_lokasi, zona) VALUES (?, 'UCH-L1', 'U')`).run(gudangId);
  const unitId = Number(db.prepare(`INSERT INTO units (kode, nama) VALUES ('UCH-PCS', 'Pcs Uji Chat')`).run().lastInsertRowid);

  const buat = (nama: string, sku: string, harga: number) =>
    Number(
      db
        .prepare(`INSERT INTO products (nama, sku, satuan_dasar_id, harga_beli, harga_jual) VALUES (?, ?, ?, ?, ?)`)
        .run(nama, sku, unitId, harga, harga * 2).lastInsertRowid,
    );

  const kpmM = buat('Kaos Polos Hitam M', 'UCH-KPM-M', 40000);
  const kpmL = buat('Kaos Polos Hitam L', 'UCH-KPM-L', 40000);

  const sspMap: Record<string, number> = {};
  for (const n of [39, 40, 41, 42, 43]) sspMap[String(n)] = buat(`Sepatu Sport Putih ${n}`, `UCH-SSP-${n}`, 100000);

  const kfm = buat('Kemeja Flanel Merah L', 'UCH-KFM', 30000);
  const kfb = buat('Kemeja Flanel Biru XL', 'UCH-KFB', 35000);

  // Produk "nyata" untuk uji pemasok tak dikenal (kecocokan yakin).
  // Nama HARUS unik di katalog — katalog demo sudah punya "Amara Hitam 39",
  // nama kembar membuat kecocokan rangkap → kabur (bukan bug parser).
  const amara = buat('Amaraux Hitam 39', 'UCH-AMARA-39', 90000);

  return { supId, gudangId, unitId, kpmM, kpmL, ssp: sspMap, kfm, kfb, amara };
};

const stok = (produkId: number, gudangId: number) =>
  Number(q1(`SELECT COALESCE(SUM(qty), 0) AS s FROM stock_balances WHERE product_id = ? AND warehouse_id = ?`, produkId, gudangId)?.s ?? 0);

const urai = (teks: string, sesi: string) => req('POST', '/api/pembelian/chat/urai', { teks, chat_sesi: sesi });

async function main() {
  bersihkan();
  const f = siapkan();

  // --- validasi dasar endpoint ---
  let r = await req('POST', '/api/pembelian/chat/urai', { teks: '' });
  cek('urai tanpa teks → 400', r.status === 400, `status ${r.status}`);
  r = await req('POST', '/api/pembelian/chat/urai', { teks: 'tes', purchase_id: 999999 });
  cek('urai dengan purchase_id asing → 404', r.status === 404, `status ${r.status}`);
  r = await req('GET', '/api/pembelian/999999/chat');
  cek('riwayat dokumen tak dikenal → 404', r.status === 404, `status ${r.status}`);

  // --- CONTOH 1: pemasok + warna + size eksplisit + lusin + harga ---
  r = await urai(CONTOH1, 'UCH-SES-1');
  cek('contoh 1 → 201', r.status === 201, `status ${r.status} ${r.data?.pesan ?? ''}`);
  const h1 = r.data ?? {};
  cek('contoh 1: pemasok "Supplier A" cocok', h1.pemasok?.cocok === true && Number(h1.pemasok?.supplier_id) === f.supId, JSON.stringify(h1.pemasok));
  cek('contoh 1: satu baris', h1.baris?.length === 1, String(h1.baris?.length));
  const b1 = h1.baris?.[0] ?? {};
  cek('contoh 1: yakin tanpa alasan', b1.kecocokan === 'yakin' && (b1.alasan ?? []).length === 0, `${b1.kecocokan} / ${JSON.stringify(b1.alasan)}`);
  cek('contoh 1: produk UCH-KPM-M', Number(b1.product_id) === f.kpmM && b1.baris?.sku === 'UCH-KPM-M', String(b1.product_id));
  cek('contoh 1: warna hitam + size M', b1.warna === 'hitam' && b1.size === 'm', `${b1.warna}/${b1.size}`);
  cek('contoh 1: 2 lusin → 24 satuan dasar', Number(b1.qty) === 2 && b1.satuan_teks === 'lusin' && Number(b1.qty_dasar) === 24, `${b1.qty} ${b1.satuan_teks} → ${b1.qty_dasar}`);
  cek('contoh 1: harga 45.000', Number(b1.harga) === 45000, String(b1.harga));
  cek('contoh 1: pesan bot berisi ringkasan', typeof h1.pesan_bot === 'string' && h1.pesan_bot.includes('✔'), '');

  // --- CONTOH 2: rentang size + kodi + @harga ---
  r = await urai(CONTOH2, 'UCH-SES-2');
  cek('contoh 2 → 201', r.status === 201, `status ${r.status}`);
  const h2 = r.data ?? {};
  cek('contoh 2: rentang 39-43 → 5 baris', h2.baris?.length === 5, String(h2.baris?.length));
  const ukuran = (h2.baris ?? []).map((b: any) => b.size);
  cek('contoh 2: size 39…43 berurutan', JSON.stringify(ukuran) === JSON.stringify(['39', '40', '41', '42', '43']), JSON.stringify(ukuran));
  cek('contoh 2: tiap baris 2 kodi → 48', (h2.baris ?? []).every((b: any) => Number(b.qty) === 2 && b.satuan_teks === 'kodi' && Number(b.qty_dasar) === 48));
  cek('contoh 2: tiap baris harga 120.000', (h2.baris ?? []).every((b: any) => Number(b.harga) === 120000));
  cek('contoh 2: semua produk terpilih yakin', (h2.baris ?? []).every((b: any) => b.kecocokan === 'yakin' && Number(b.product_id) > 0));
  cek(
    'contoh 2: produk cocok per size',
    (h2.baris ?? []).every((b: any, i: number) => Number(b.product_id) === f.ssp[String(39 + i)]),
    JSON.stringify((h2.baris ?? []).map((b: any) => b.product_id)),
  );
  cek('contoh 2: catatan jumlah per size', (h2.catatan ?? []).some((c: string) => c.includes('Rentang size 39–43')), JSON.stringify(h2.catatan));

  // --- CONTOH 3: baris lanjutan + diskon persen global ---
  r = await urai(CONTOH3, 'UCH-SES-3');
  cek('contoh 3 → 201', r.status === 201, `status ${r.status}`);
  const h3 = r.data ?? {};
  cek('contoh 3: dua baris', h3.baris?.length === 2, String(h3.baris?.length));
  const b3a = h3.baris?.[0] ?? {};
  const b3b = h3.baris?.[1] ?? {};
  cek('contoh 3: baris 1 merah L 10 pcs yakin', b3a.warna === 'merah' && b3a.size === 'l' && Number(b3a.qty_dasar) === 10 && b3a.satuan_teks === 'pcs' && b3a.kecocokan === 'yakin', `${b3a.warna}/${b3a.size}/${b3a.qty_dasar}/${b3a.kecocokan}`);
  cek('contoh 3: baris 1 produk UCH-KFM', Number(b3a.product_id) === f.kfm, String(b3a.product_id));
  cek('contoh 3: harga jatuh ke master 30.000', b3a.harga_dari_master === true && Number(b3a.harga) === 30000, `${b3a.harga_dari_master}/${b3a.harga}`);
  cek('contoh 3: baris 2 lanjutan biru XL + produk terpilih', b3b.warna === 'biru' && b3b.size === 'xl' && Number(b3b.qty_dasar) === 5 && Number(b3b.product_id) === f.kfb, `${b3b.kecocokan}/${b3b.product_id} ${JSON.stringify(b3b.alasan)}`);
  cek('contoh 3: diskon global 5% → 15.000 & 8.750', Number(b3a.diskon_persen) === 5 && Number(b3a.diskon) === 15000 && Number(b3b.diskon) === 8750, `${b3a.diskon}/${b3b.diskon}`);
  cek('contoh 3: pemasok tidak disebut → teks null', h3.pemasok?.teks === null && h3.pemasok?.cocok === false, JSON.stringify(h3.pemasok));

  // --- pemasok tak dikenal → penanda kuning + saran ---
  r = await urai('beli dari Supplier Zzz, Amaraux Hitam 39 1 pcs', 'UCH-SES-4');
  const h4 = r.data ?? {};
  cek('pemasok tak dikenal: teks terbaca, cocok=false', h4.pemasok?.teks === 'Supplier Zzz' && h4.pemasok?.cocok === false, JSON.stringify(h4.pemasok));
  cek('pemasok tak dikenal: saran tersedia', Array.isArray(h4.pemasok?.saran) && h4.pemasok.saran.length >= 1, JSON.stringify(h4.pemasok?.saran));
  cek('pemasok tak dikenal: catatan peringatan', (h4.catatan ?? []).some((c: string) => c.includes('tidak ditemukan')), JSON.stringify(h4.catatan));
  const b4 = h4.baris?.[0] ?? {};
  cek('produk nyata "Amaraux Hitam 39" yakin', b4.kecocokan === 'yakin' && Number(b4.product_id) === f.amara, `${b4.kecocokan}/${b4.product_id}`);

  // --- satuan box: dikenali, ditandai kuning karena tanpa konversi ---
  r = await urai('beli dari Supplier A, Kaos Polos Hitam M 3 box harga 45000', 'UCH-SES-5');
  const h5 = r.data ?? {};
  const b5 = h5.baris?.[0] ?? {};
  cek('box dikenali sebagai satuan', b5.satuan_teks === 'box' && Number(b5.qty_dasar) === 3, `${b5.satuan_teks}/${b5.qty_dasar}`);
  cek('box ditandai kuning (tanpa konversi)', Array.isArray(b5.alasan) && b5.alasan.some((a: string) => a.includes('box')), JSON.stringify(b5.alasan));
  cek('box: produk tetap yakin', b5.kecocokan === 'yakin' && Number(b5.product_id) === f.kpmM, String(b5.kecocokan));

  // --- produk tak cocok → saran ---
  r = await urai('jeruk peras 5 pcs', 'UCH-SES-6');
  const h6 = r.data ?? {};
  cek('produk tak dikenal: baris tetap ada & kuning', h6.baris?.length === 1 && h6.baris[0].kecocokan === 'tidak', String(h6.baris?.[0]?.kecocokan));
  cek('produk tak dikenal: produk kosong', h6.baris?.[0]?.product_id === null, String(h6.baris?.[0]?.product_id));

  // --- riwayat chat sebelum dokumen: menunggu dengan chat_sesi ---
  let nPending = Number(q1(`SELECT COUNT(*) AS n FROM purchase_chat_logs WHERE chat_sesi = 'UCH-SES-1' AND purchase_id IS NULL`)?.n ?? 0);
  cek('pesan pra-dokumen tersimpan dengan chat_sesi', nPending === 1, String(nPending));

  // --- konfirmasi → draft metode chatbot + klaim riwayat ---
  r = await req('POST', '/api/pembelian', {
    metode_input: 'chatbot',
    supplier_id: f.supId,
    warehouse_id: f.gudangId,
    pajak_persen: 0,
    chat_sesi: 'UCH-SES-1',
    items: [{ product_id: f.kpmM, qty: 24, unit_id: f.unitId, harga_beli: 45000, diskon: 0 }],
  });
  cek('buat draft dari chat → 201', r.status === 201, `status ${r.status} ${r.data?.pesan ?? ''}`);
  const docId = Number(r.data?.id);
  cek('draft bermetode chatbot', r.data?.data?.metode_input === 'chatbot', String(r.data?.data?.metode_input));
  cek('total 1.080.000 (24 × 45.000)', Number(r.data?.data?.total) === 1080000, String(r.data?.data?.total));

  const klaim = semua(`SELECT purchase_id FROM purchase_chat_logs WHERE chat_sesi = 'UCH-SES-1'`);
  cek('riwayat sesi terklaim ke dokumen', klaim.length > 0 && klaim.every((x) => Number(x.purchase_id) === docId), JSON.stringify(klaim));
  const sesiLain = q1(`SELECT purchase_id FROM purchase_chat_logs WHERE chat_sesi = 'UCH-SES-2'`);
  cek('sesi lain TIDAK ikut terklaim', sesiLain?.purchase_id === null || sesiLain === undefined, String(sesiLain?.purchase_id));

  r = await req('GET', `/api/pembelian/${docId}/chat`);
  cek('GET riwayat chat → 200 & berisi pesan', r.status === 200 && r.data?.data?.length >= 1, `status ${r.status} n=${r.data?.data?.length}`);
  const log0 = r.data?.data?.[0] ?? {};
  cek('riwayat membawa pesan user + bot', log0.pesan_user === CONTOH1 && typeof log0.pesan_bot === 'string' && log0.pesan_bot.length > 0, `${String(log0.pesan_user).slice(0, 30)}…`);

  r = await req('GET', '/api/pembelian?metode=chatbot');
  cek('filter metode=chatbot menemukan dokumen', Boolean(r.data?.data?.some((b: any) => b.id === docId)));

  // --- alur pengesahan yang sama ---
  r = await req('POST', `/api/pembelian/${docId}/terima`, {});
  cek('GRN draft chat → 200', r.status === 200, `status ${r.status} ${r.data?.pesan ?? ''}`);
  cek('GRN: stok masih 0', stok(f.kpmM, f.gudangId) === 0, String(stok(f.kpmM, f.gudangId)));
  cek('GRN: belum ada jurnal', semua(`SELECT id FROM journals WHERE sumber_tipe = 'pembelian' AND sumber_id = ?`, docId).length === 0);

  r = await req('POST', `/api/pembelian/${docId}/sahkan`, {});
  cek('sahkan draft chat → 200', r.status === 200, `status ${r.status} ${r.data?.pesan ?? ''}`);
  cek('sahkan: stok masuk 24', stok(f.kpmM, f.gudangId) === 24, String(stok(f.kpmM, f.gudangId)));
  const js = semua(`SELECT * FROM journals WHERE sumber_tipe = 'pembelian' AND sumber_id = ?`, docId);
  // AKUNTANSI DASAR (model saat ini — lihat komentar "AKUNTANSI DASAR" di
  // routes/pembelian.ts): pengesahan TIDAK membuat jurnal; pembelian tercatat
  // sebagai stok + hutang pemasok, kas bergerak saat pembayaran hutang.
  cek('pengesahan tanpa jurnal (Akuntansi Dasar)', js.length === 0, `jurnal=${js.length}`);
  const hutang = q1(`SELECT * FROM payables WHERE purchase_id = ?`, docId);
  cek('hutang dibuat 1.080.000', Number(hutang?.total) === 1080000 && hutang?.status === 'belum', `${hutang?.total}/${hutang?.status}`);

  r = await req('POST', `/api/pembelian/${docId}/batal`, { alasan: 'uji chat void' });
  cek('void draft chat → 200', r.status === 200, `status ${r.status} ${r.data?.pesan ?? ''}`);
  cek('void: stok kembali 0', stok(f.kpmM, f.gudangId) === 0, String(stok(f.kpmM, f.gudangId)));
  // Model pembatalan saat ini (Akuntansi Dasar): TIDAK ada jurnal untuk
  // dibalik — pembatalan membalik stok + hutang (diverifikasi di baris atas).
  const jurnalVoid = semua(
    `SELECT status, keterangan FROM journals WHERE sumber_tipe = 'pembelian' AND sumber_id = ? ORDER BY id`,
    docId,
  );
  cek('void tanpa jurnal pembalik (Akuntansi Dasar)',
    jurnalVoid.length === 0,
    JSON.stringify(jurnalVoid));
  cek('riwayat chat tetap utuh setelah void', Number(q1(`SELECT COUNT(*) AS n FROM purchase_chat_logs WHERE purchase_id = ?`, docId)?.n ?? 0) >= 1);

  console.log(`\n${lulus} lulus, ${gagal} gagal`);
  bersihkan();
  console.log('Fiks uji UCH dibersihkan — database dikembalikan ke kondisi semula.');
  db.close();
  process.exit(gagal > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error('✘ Galat fatal:', err instanceof Error ? err.message : err);
  db.close();
  process.exit(1);
});
