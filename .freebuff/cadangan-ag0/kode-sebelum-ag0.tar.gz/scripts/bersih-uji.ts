/* Bersihkan data fixture uji (dipakai setelah uji-massal / uji-tambah-banyak). */
import { db } from '../server/db.ts';

// Pemakaian stok uji pada BRG-0002 (agar bisa dihapus normal lagi)
db.prepare(`DELETE FROM stock_balances WHERE product_id IN (
  SELECT id FROM products WHERE kode_item = 'BRG-0002'
)`).run();

// Produk fixture (anak dulu — FK)
db.prepare(`DELETE FROM stock_ledger WHERE product_id IN (SELECT id FROM products WHERE nama LIKE 'Massal Banyak %' OR nama LIKE 'Massal Uji %')`).run();
db.prepare(`DELETE FROM stock_balances WHERE product_id IN (SELECT id FROM products WHERE nama LIKE 'Massal Banyak %' OR nama LIKE 'Massal Uji %')`).run();
db.prepare(`DELETE FROM unit_conversions WHERE product_id IN (SELECT id FROM products WHERE nama LIKE 'Massal Banyak %' OR nama LIKE 'Massal Uji %')`).run();
db.prepare(`DELETE FROM products WHERE nama LIKE 'Massal Banyak %' OR nama LIKE 'Massal Uji %'`).run();

// Pelanggan & kategori fixture
db.prepare(`DELETE FROM customers WHERE nama LIKE 'Pelanggan Uji %' OR nama = 'Pelanggan Massal Uji'`).run();
db.prepare(`DELETE FROM categories WHERE nama = 'Kategori Massal Uji'`).run();

const sisa = {
  produk: (db.prepare(`SELECT COUNT(*) AS n FROM products WHERE nama LIKE 'Massal %'`).get() as { n: number }).n,
  pelanggan: (db.prepare(`SELECT COUNT(*) AS n FROM customers WHERE nama LIKE 'Pelanggan %'`).get() as { n: number }).n,
};
console.log('Bersih. sisa fixture:', JSON.stringify(sisa));
