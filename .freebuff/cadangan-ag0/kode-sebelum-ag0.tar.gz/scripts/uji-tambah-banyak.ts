/* Buat 24 produk uji (untuk uji pilih-massal lintas halaman). */
import { db } from '../server/db.ts';

db.prepare(`DELETE FROM stock_ledger WHERE product_id IN (SELECT id FROM products WHERE nama LIKE 'Massal Banyak %')`).run();
db.prepare(`DELETE FROM stock_balances WHERE product_id IN (SELECT id FROM products WHERE nama LIKE 'Massal Banyak %')`).run();
db.prepare(`DELETE FROM unit_conversions WHERE product_id IN (SELECT id FROM products WHERE nama LIKE 'Massal Banyak %')`).run();
db.prepare(`DELETE FROM products WHERE nama LIKE 'Massal Banyak %'`).run();

const ins = db.prepare(
  `INSERT INTO products (kode_item, nama, sku, harga_beli, harga_jual, stok_min, aktif)
   VALUES (?, ?, ?, 500, 1000, 0, 1)`,
);
for (let i = 1; i <= 24; i++) {
  const kode = `MB-${String(i).padStart(3, '0')}`;
  ins.run(kode, `Massal Banyak ${i}`, `MB-${i}-A`);
}
console.log('24 produk uji dibuat.');
