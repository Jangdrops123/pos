import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { alihRuteLama } from './server/alihPos';

const API_PORT = Number(process.env.API_PORT ?? 3001);

/**
 * M2/O2/R1 — di mode dev, rute lama menjawab 301 ke rute baru:
 * /pos/* → Penjualan, /opname/* & /persediaan-sub/* → grup Stok.
 * req.url dipakai utuh agar query string ikut terbawa.
 */
function alihRuteLamaDev(): Plugin {
  return {
    name: 'alih-rute-lama',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        if (req.method !== 'GET') {
          next();
          return;
        }
        const tujuan = alihRuteLama(req.url ?? '');
        if (tujuan) {
          res.statusCode = 301;
          res.setHeader('Location', tujuan);
          res.end();
          return;
        }
        next();
      });
    },
  };
}

export default defineConfig({
  plugins: [react(), alihRuteLamaDev()],
  server: {
    port: Number(process.env.WEB_PORT ?? 5173),
    strictPort: false,
    proxy: {
      '/api': {
        target: `http://127.0.0.1:${API_PORT}`,
        changeOrigin: true,
      },
      // Foto produk yang diunggah disimpan & disajikan oleh API.
      '/uploads': {
        target: `http://127.0.0.1:${API_PORT}`,
        changeOrigin: true,
      },
    },
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
});
