import type { Request, RequestHandler } from 'express';
import { tolak } from './http.ts';

/**
 * Identitas pemakai untuk pengecekan hak akses.
 *
 * Tahap 1 — modul Log In sudah ada: identitas dibaca dari SESI login
 * (`req.konteks`, diisi middleware `wajibLogin`). Seluruh pemanggil
 * `penggunaSaatIni` / `wajibAdmin` / `catatAudit` di modul lain tidak
 * berubah — mereka kini otomatis mencatat pengguna sungguhan.
 */
export interface Pengguna {
  id: number | null;
  nama: string;
  peran: string;
}

export const PERAN_ADMIN = new Set(['owner', 'administrator']);

export function penggunaSaatIni(req: Request): Pengguna {
  const k = req.konteks;
  if (k) return { id: k.userId, nama: k.nama, peran: k.roleNama };
  // Tanpa sesi (endpoint publik) — dipakai hanya untuk pesan, bukan otorisasi.
  return { id: null, nama: '-', peran: 'administrator' };
}

export function adalahAdmin(req: Request): boolean {
  return PERAN_ADMIN.has(penggunaSaatIni(req).peran.toLowerCase());
}

/** Tolak permintaan bila bukan Owner/Admin (dipakai untuk ubah harga & hapus). */
export const wajibAdmin: RequestHandler = (req, _res, next) => {
  if (!adalahAdmin(req)) {
    next(tolak(403, 'Hanya Owner/Admin yang boleh mengubah harga atau menghapus data.'));
    return;
  }
  next();
};

/* --------------------------- MODUL AKUNTANSI ---------------------------- */

/**
 * Peran efektif permintaan: diambil dari SESI login (`peranKunci`).
 * Sesi Admin boleh mensimulasikan peran lain lewat header `x-peran`
 * (dipakai skrip uji & matriks izin) — sesi non-Admin mengabaikan header
 * tersebut sehingga peran tidak bisa dinaikkan sendiri.
 */
const DAFTAR_PERAN = ['admin', 'owner', 'administrator', 'manajer', 'akuntan', 'kasir', 'gudang'] as const;

export function peranDariHeader(req: Request): string {
  if (req.konteks) return req.konteks.peranKunci;
  const h = String(req.headers['x-peran'] ?? '').toLowerCase().trim();
  return (DAFTAR_PERAN as readonly string[]).includes(h) ? h : 'administrator';
}

/** Peran Admin menurut header `x-peran` (klien) maupun sesi. */
export function adalahPeranAdmin(peran: string): boolean {
  const p = peran.toLowerCase().trim();
  return PERAN_ADMIN.has(p) || p === 'admin';
}

/**
 * Y2.1 — Identitas Aplikasi hanya boleh diubah Admin/Owner.
 * Peran dibaca dari sesi login (lihat `peranDariHeader`).
 */
export const wajibAdminIdentitas: RequestHandler = (req, _res, next) => {
  if (!adalahPeranAdmin(peranDariHeader(req))) {
    next(tolak(403, 'Hanya Admin/Owner yang boleh mengubah identitas aplikasi.'));
    return;
  }
  next();
};

/** Boleh membuka modul Akuntansi: Kasir & Staf Gudang TIDAK. */
const BOLEH_AKUNTANSI = new Set(['admin', 'owner', 'administrator', 'manajer', 'akuntan']);
/** Boleh membuat jurnal manual: hanya Akuntan & Owner. */
const BOLEH_BUAT_JURNAL = new Set(['admin', 'owner', 'administrator', 'akuntan']);
/** Boleh membuka/kunci periode: hanya Owner. */
const BOLEH_KELOLA_PERIODE = new Set(['owner', 'admin', 'administrator']);

export const wajibAkuntansi: RequestHandler = (req, _res, next) => {
  // Sumber kebenaran = sesi login (peran efektif).
  if (!BOLEH_AKUNTANSI.has(peranDariHeader(req))) {
    next(tolak(403, 'Menu Akuntansi hanya untuk Akuntan dan Owner.'));
    return;
  }
  next();
};

export const wajibBuatJurnal: RequestHandler = (req, _res, next) => {
  if (!BOLEH_BUAT_JURNAL.has(peranDariHeader(req))) {
    next(tolak(403, 'Hanya Akuntan dan Owner yang boleh membuat atau membatalkan jurnal.'));
    return;
  }
  next();
};

export const wajibKelolaPeriode: RequestHandler = (req, _res, next) => {
  if (!BOLEH_KELOLA_PERIODE.has(peranDariHeader(req))) {
    next(tolak(403, 'Hanya Owner yang boleh membuka atau menutup periode akuntansi.'));
    return;
  }
  next();
};
