// Fasilitas sistem untuk Pengaturan ▸ Keamanan & Sistem:
// info database, backup manual/terjadwal, pemulihan, dan pemeriksaan pembaruan.
//
// Backup memakai SQLite `VACUUM INTO` sehingga menghasilkan berkas .db utuh
// tanpa menggangu koneksi yang sedang berjalan (aman dipakai saat aplikasi aktif).
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { all, db, ROOT_DIR, withTransaction } from '../db.ts';
import { tolak } from './http.ts';

/** Berkas database aktif. */
export const LOKASI_DB = path.join(ROOT_DIR, 'data', 'app.db');
/** Folder cadangan — dibuat saat dibutuhkan, tidak ikut disalin sebagai aset. */
export const LOKASI_BACKUP = path.join(ROOT_DIR, 'data', 'backups');

/** Versi aplikasi (diambil dari package.json — satu sumber kebenaran). */
export function versiAplikasi(): string {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'package.json'), 'utf8')) as { version?: string };
    return pkg.version ?? '0.0.0';
  } catch {
    return '0.0.0';
  }
}

export interface InfoSistem {
  versi: string;
  namaDatabase: string;
  ukuranDb: number;
  waktuDatabase: string;
  migrasi: number;
  ringkasan: { nama: string; jumlah: number }[];
}

function ukuranBerkas(p: string): number {
  try {
    return fs.statSync(p).size;
  } catch {
    return 0;
  }
}

/** Informasi database aktif + ringkasan jumlah data penting. */
export function infoSistem(): InfoSistem {
  const hitung = (sql: string): number => {
    try {
      return Number(all<{ n: number }>(sql)[0]?.n ?? 0);
    } catch {
      return 0;
    }
  };
  const migrasi = hitung('SELECT COUNT(*) AS n FROM schema_migrations');
  let waktu = '';
  try {
    waktu = fs.statSync(LOKASI_DB).mtime.toISOString();
  } catch {
    waktu = '';
  }
  return {
    versi: versiAplikasi(),
    namaDatabase: path.basename(LOKASI_DB),
    ukuranDb: ukuranBerkas(LOKASI_DB),
    waktuDatabase: waktu,
    migrasi,
    ringkasan: [
      { nama: 'Produk', jumlah: hitung('SELECT COUNT(*) AS n FROM products') },
      { nama: 'Toko', jumlah: hitung('SELECT COUNT(*) AS n FROM stores') },
      { nama: 'Gudang', jumlah: hitung('SELECT COUNT(*) AS n FROM warehouses') },
      { nama: 'Pelanggan', jumlah: hitung('SELECT COUNT(*) AS n FROM customers') },
      { nama: 'Pemasok', jumlah: hitung('SELECT COUNT(*) AS n FROM suppliers') },
      { nama: 'Penjualan (faktur)', jumlah: hitung(`SELECT COUNT(*) AS n FROM invoices WHERE jenis = 'penjualan'`) },
      { nama: 'Pembelian', jumlah: hitung('SELECT COUNT(*) AS n FROM purchases') },
      { nama: 'Jurnal', jumlah: hitung('SELECT COUNT(*) AS n FROM journals') },
      { nama: 'Akun (COA)', jumlah: hitung('SELECT COUNT(*) AS n FROM accounts') },
      { nama: 'Pengguna', jumlah: hitung('SELECT COUNT(*) AS n FROM users') },
      { nama: 'Baris Log Aktivitas', jumlah: hitung('SELECT COUNT(*) AS n FROM audit_logs') },
    ],
  };
}

export interface BarisBackup {
  nama: string;
  ukuran: number;
  waktu: string;
}

/** Daftar berkas cadangan, terbaru lebih dulu. */
export function daftarBackup(): BarisBackup[] {
  try {
    if (!fs.existsSync(LOKASI_BACKUP)) return [];
    return fs
      .readdirSync(LOKASI_BACKUP)
      .filter((f) => f.endsWith('.db'))
      .map((f) => {
        const p = path.join(LOKASI_BACKUP, f);
        const st = fs.statSync(p);
        return { nama: f, ukuran: st.size, waktu: st.mtime.toISOString() };
      })
      .sort((a, b) => (a.waktu < b.waktu ? 1 : -1));
  } catch {
    return [];
  }
}

const AMAN = /^[A-Za-z0-9._-]+\.db$/;

/** Buat satu cadangan. Mengembalikan nama berkas hasil cadangan. */
export function buatBackup(alasan: string): string {
  fs.mkdirSync(LOKASI_BACKUP, { recursive: true });
  // Nama harus unik: VACUUM INTO menolak berkas yang sudah ada, dan dua
  // cadangan bisa dibuat dalam detik yang sama (mis. cadangan pengaman saat
  // pemulihan langsung mengikuti cadangan manual).
  const stempel = new Date().toISOString().replace(/[:.]/g, '-');
  let nama = `backup-${stempel}.db`;
  let urut = 1;
  while (fs.existsSync(path.join(LOKASI_BACKUP, nama))) {
    nama = `backup-${stempel}-${urut++}.db`;
  }
  const tujuan = path.join(LOKASI_BACKUP, nama);
  // VACUUM INTO menyalin isi database ke berkas konsisten tanpa mengunci tulis.
  db.exec(`VACUUM INTO '${tujuan.replace(/'/g, "''")}'`);
  if (!fs.existsSync(tujuan) || ukuranBerkas(tujuan) === 0) {
    throw tolak(500, 'Cadangan gagal dibuat — periksa izin folder data/backups.');
  }
  void alasan;
  bersihkanCadanganLama();
  return nama;
}

/** Simpan hanya N cadangan terbaru (mengikuti pengaturan jumlah backup). */
export function bersihkanCadanganLama(): void {
  const batas = Math.max(1, Math.min(100, bacaJumlahCadangan()));
  const daftar = daftarBackup();
  for (const b of daftar.slice(batas)) {
    try {
      fs.unlinkSync(path.join(LOKASI_BACKUP, b.nama));
    } catch {
      /* berkas terkunci — biarkan */
    }
  }
}

export function bacaJumlahCadangan(): number {
  const v = all<{ nilai: string | null }>(`SELECT nilai FROM settings WHERE kunci = 'peng.database.jumlah_backup'`)[0]?.nilai;
  const n = Number.parseInt(v ?? '', 10);
  return Number.isFinite(n) && n > 0 ? n : 14;
}

/** Path berkas cadangan — hanya nama aman yang boleh diminta. */
export function pathBackup(nama: string): string {
  if (!AMAN.test(nama)) throw tolak(400, 'Nama berkas cadangan tidak valid.');
  const p = path.join(LOKASI_BACKUP, nama);
  if (!fs.existsSync(p)) throw tolak(404, `Cadangan "${nama}" tidak ditemukan.`);
  return p;
}

/**
 * Pulihkan database dari cadangan.
 *
 * PERINGATAN: menimpa seluruh isi database aktif dengan isi cadangan.
 *
 * Isi disalin TABEL PER TABEL di dalam satu transaksi, bukan dengan menimpa
 * berkas database. Menimpa berkas di bawah koneksi SQLite yang sedang terbuka
 * membuat koneksi terus menulis ke berkas lama dan merusak disk image —
 * jadi salinan dilakukan lewat SQLite sendiri agar aman saat aplikasi berjalan.
 */
export function pulihkanBackup(nama: string): void {
  const sumber = pathBackup(nama);

  const src = new DatabaseSync(sumber, { readOnly: true });
  try {
    const cek = src.prepare('PRAGMA integrity_check').get() as { integrity_check: string } | undefined;
    if (!cek || cek.integrity_check !== 'ok') {
      throw tolak(409, 'Berkas cadangan rusak (integrity check gagal). Pulihkan dari cadangan lain.');
    }

    const namaTabel = (db: DatabaseSync): string[] =>
      (db.prepare(`SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'`).all() as { name: string }[])
        .map((r) => r.name);

    const dariCadangan = namaTabel(src);
    const diAktif = new Set(namaTabel(db));

    // Skema berbeda berarti cadangan berasal dari versi lain — menyalinnya
    // akan meninggalkan tabel setengah kosong. Tolak dengan jelas.
    const hilang = dariCadangan.filter((t) => !diAktif.has(t));
    if (hilang.length) {
      throw tolak(
        409,
        `Cadangan ini berasal dari versi database yang berbeda (tabel belum ada: ${hilang.slice(0, 5).join(', ')}). ` +
          'Pulihkan dengan versi aplikasi yang sama dengan saat cadangan dibuat.',
      );
    }

    const idn = (t: string): string => `"${t.replace(/"/g, '""')}"`;

    withTransaction(() => {
      // Salinan tabel dalam urutan apa pun: tunda pemeriksaan kunci asing
      // sampai COMMIT, agar induk-anak boleh dihapus-disisipkan bergantian
      // tanpa melanggar FOREIGN KEY. Pragma otomatis kembali saat transaksi
      // berakhir (baik commit maupun rollback).
      db.exec('PRAGMA defer_foreign_keys = ON');

      // Trigger proteksi ikut dilepas sementara. Pemulihan menghapus-menyisipkan
      // baris lama tanpa urutan dependensi, sehingga trigger seperti
      // "produk bertransaksi tidak boleh dihapus" dan "jurnal disahkan tidak
      // boleh diubah" menolaknya dan membatalkan pemulihan. Definisi trigger
      // disimpan lalu dibuat kembali tepat di transaksi yang sama, jadi
      // rollback (atau kegagalan) otomatis mengembalikannya seperti semula.
      const sqlTrigger = db
        .prepare(`SELECT name, sql FROM sqlite_master WHERE type = 'trigger' AND name NOT LIKE 'sqlite_%'`)
        .all() as { name: string; sql: string | null }[];
      for (const tr of sqlTrigger) db.exec(`DROP TRIGGER IF EXISTS ${idn(tr.name)}`);

      // Tabel yang hanya ada di database aktif (mis. hasil migrasi lebih baru
      // daripada cadangan) dikosongkan supaya isi database benar-benar sama
      // dengan cadangan, bukan sisa baris yang kini yatim.
      const cadangan = new Set(dariCadangan);
      for (const t of diAktif) if (!cadangan.has(t)) db.exec(`DELETE FROM ${idn(t)}`);

      for (const t of dariCadangan) {
        const kolom = (src.prepare(`PRAGMA table_info(${idn(t)})`).all() as { name: string }[]).map((c) => c.name);
        if (!kolom.length) continue;
        const daftarKolom = kolom.map(idn).join(', ');
        db.exec(`DELETE FROM ${idn(t)}`);
        const baris = src.prepare(`SELECT ${daftarKolom} FROM ${idn(t)}`).all() as Record<string, unknown>[];
        if (!baris.length) continue;
        const tempat = kolom.map(() => '?').join(', ');
        const sisip = db.prepare(`INSERT INTO ${idn(t)} (${daftarKolom}) VALUES (${tempat})`);
        for (const b of baris) sisip.run(...kolom.map((k) => b[k] as never));
      }

      // Pasang kembali seluruh trigger seperti semula.
      for (const tr of sqlTrigger) {
        if (!tr.sql) continue;
        db.exec(tr.sql);
      }

      // Validasi akhir sebelum COMMIT: cadangan yang berisi baris yatim
      // (anak tanpa induk) akan membuat database aktif rusak, jadi tolak dengan
      // jelas dan biarkan transaksi tergulung — definisi trigger ikut tergulung.
      const bermasalah = all<{ table: string; parent: string }>('PRAGMA foreign_key_check');
      if (bermasalah.length) {
        const pasangan = [...new Set(bermasalah.map((b) => `${b.table} → ${b.parent}`))].slice(0, 5);
        throw tolak(
          409,
          `Cadangan berisi baris tanpa induk (${pasangan.join(', ')}) sehingga tidak aman dipulihkan. Pulihkan dari cadangan lain.`,
        );
      }
    });
  } finally {
    src.close();
  }
}

/* ------------------------- Pemeriksaan pembaruan ------------------------- */

/**
 * Pemeriksaan pembaruan.
 *
 * Aplikasi belum memiliki endpoint pembaruan resmi, jadi jawabannya jujur:
 * `tersedia: false` dengan petunjuk cara memeriksa manual. Tidak ada panggilan
 * jaringan yang dibuat (tidak ada izin & tidak ada endpoint yang diketahui).
 */
export function periksaPembaruan(): { versi: string; tersedia: boolean; pesan: string } {
  const versi = versiAplikasi();
  return {
    versi,
    tersedia: false,
    pesan: `Versi terpasang ${versi}. Aplikasi ini belum memiliki kanal pembaruan otomatis — periksa repositori atau distributor resmi Anda untuk versi terbaru.`,
  };
}
