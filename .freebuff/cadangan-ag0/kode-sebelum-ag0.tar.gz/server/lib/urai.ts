// Parser aturan/regex untuk metode input CHATBOT pada Pembelian/Inbound.
//
// Tanpa API eksternal berbayar: teks bahasa sehari-hari diuraikan menjadi
// baris draft item (pemasok, nama produk, warna, size/rentang size, jumlah,
// satuan, harga, diskon), lalu dicocokkan ke katalog produk di basis data.
// Hasilnya membawa penanda kuning (alasan) untuk bagian ambigu/tidak cocok
// beserta saran produk — pengguna meninjau/mengoreksi lalu mengonfirmasi.
//
// Konvensi penting:
// - SATUAN memengaruhi JUMLAH saja: qty dikonversi ke satuan dasar
//   (lusin=12, kodi=24, pcs=1) dan harga diangkap PER SATUAN DASAR
//   ("2 lusin harga 45000" → 24 × 45.000), sesuai makna wajar contoh teks.
// - Satuan yang dikenali tapi tidak punya konversi (box, dus, …) ditandai
//   kuning agar pengguna memeriksa jumlahnya.
// - Kecocokan: 'yakin' (semua kata produk cocok unik), 'kabur' (beberapa
//   kandidat / lanjutan baris), 'tidak' (tidak ada kandidat — saran disertakan
//   bila ada kandidat mendekati: tumpang tindih kata → warna → size).
import { all, getSettings } from '../db.ts';
import {
  resolusiProfilSize,
  aturanDariProfil,
  profilSizeDefault,
  profilSizeDariId,
  profilUntukSize,
  daftarProfilSize,
  labelProfil,
  rentangSize,
  type ProfilSize,
} from './profilSize.ts';

/** Semua profil yang memuat sebuah size (untuk pesan "pilih profil"). */
function daftarProfilYangPunyaSize(size: string): ProfilSize[] {
  const u = String(size).trim().toLowerCase();
  if (!u) return [];
  return daftarProfilSize().filter((p) => p.sizes.some((s) => s.size.trim().toLowerCase() === u));
}

// --- Tipe hasil -------------------------------------------------------------

export interface InfoProduk {
  id: number;
  sku: string;
  produk: string;
  size: string | null;
  warna: string | null;
  harga_beli: number;
  satuan_dasar_id: number | null;
}

export interface BarisUrai {
  teks: string; // segmen asli (lowercase) tempat baris berasal
  produk_teks: string; // sisa teks produk setelah field ditarik
  warna: string | null;
  size: string | null;
  rentang_size: [number, number] | null;
  qty: number | null; // jumlah persis seperti yang diketik
  satuan_teks: string | null;
  qty_dasar: number; // jumlah setelah konversi ke satuan dasar
  konversi: string | null; // "2 lusin → 24 (satuan dasar)"
  harga: number;
  harga_dari_master: boolean;
  diskon_persen: number | null;
  diskon: number; // rupiah (rekomendasi, bisa diedit pengguna)
  product_id: number | null;
  baris: InfoProduk | null;
  unit_id: number | null; // satuan dasar produk (bila produk cocok)
  kecocokan: 'yakin' | 'kabur' | 'tidak';
  saran: InfoProduk[];
  alasan: string[]; // penanda kuning di tabel draft
  /** Gaya BARIS: id kelompok satu baris teks (bisa menghasilkan beberapa baris size). */
  grup?: number;
  kelompok?: string;
  /** Gaya BARIS: jumlah size dalam kelompok ini (untuk rowspan pratinjau). */
  jumlah_size?: number;
}

/** Rincian per size dalam satu baris teks gaya BARIS (satu baris per barang). */
export interface RincianSizeUrai {
  size: string;
  pasang: number;
  /** kodi size = pasang / jatah size (profil/aturan) — bukan pasang / total kodi. */
  kodi: number;
  product_id: number | null;
}

/** Aksi yang bisa diklik pengguna pada satu peringatan pratinjau (AF5). */
export interface AksiPesanUrai {
  teks: string;
  aksi: 'pakai_profil' | 'pilih_profil' | 'seimbangkan';
  profil_id?: number;
  profil_nama?: string;
  db?: number;
  tp?: number;
}

/** Pratinjau terstruktur satu baris teks → tabel di mode Chatbot. */
export interface PratinjauUrai {
  grup: number;
  teks: string;
  nama: string;
  warna: string | null;
  /** Profil size yang dipakai baris ini (X5.3) — null bila tidak ada profil. */
  profil: string | null;
  profil_dari?: 'produk' | 'kategori' | 'kata' | 'size' | 'default' | 'manual' | null;
  /** Id & ukuran profil baris ini — untuk badge P/W + dropdown Db/Tp (AF3/AF4). */
  profil_id: number | null;
  profil_kode: string | null;
  profil_sizes: { size: string; jatah: number }[];
  /** Db/Tp yang terbaca dari teks baris (null = tidak ditulis). */
  db: number | null;
  tp: number | null;
  /** Jumlah kodi & pcs di luar kodi (untuk kolom Pasang/Kodi/Pcs pratinjau). */
  kodi_normal: number;
  kodi_komp: number;
  pcs: number;
  /** Total pasang per kodi setelah komposisi — 20 = hijau, selain itu kuning. */
  sisa_per_kodi: number;
  seimbang: boolean;
  /** AF1.6 — baris belum terklasifikasi (profil jatuh ke default tanpa petunjuk). */
  ragu: boolean;
  /** Saran profil dari petunjuk size (mis. "db 37" → Wanita). */
  saran_profil: { id: number; nama: string } | null;
  /** Peringatan yang bisa ditindaklanjuti + tombol aksinya (AF5). */
  pesan: AksiPesanUrai[];
  qty_teks: string;
  total_pasang: number;
  total_kodi: number;
  rincian: RincianSizeUrai[];
  kecocokan: 'yakin' | 'kabur' | 'tidak';
  saran: InfoProduk[];
  alasan: string[];
}

/** Hasil cek baris "Total = …" terhadap jumlah hasil hitung. */
export interface CekTotalUrai {
  ada: boolean;
  klaim: number | null;
  hitung: number;
  selisih: number;
  ok: boolean;
}

export interface PemasokUrai {
  teks: string | null;
  supplier_id: number | null;
  cocok: boolean;
  saran: { id: number; nama: string }[];
}

export interface HasilUrai {
  pemasok: PemasokUrai;
  baris: BarisUrai[];
  catatan: string[];
  pesan_bot: string;
  /** 'baris' = gaya baru (satu baris per barang, tulis ke bawah). */
  gaya?: 'bebas' | 'baris';
  tanggal?: string | null;
  pratinjau?: PratinjauUrai[];
  cek?: CekTotalUrai;
  aturan?: { per_kodi: number; normal: Record<string, number> };
}

// --- Kamus ------------------------------------------------------------------

/** Alias warna → bentuk baku (dipakai juga untuk menormalisasi nama produk). */
const WARNA: Record<string, string> = {
  hitam: 'hitam', black: 'hitam',
  putih: 'putih', white: 'putih',
  merah: 'merah', red: 'merah',
  biru: 'biru', blue: 'biru', navy: 'biru',
  hijau: 'hijau', green: 'hijau',
  kuning: 'kuning', yellow: 'kuning',
  coklat: 'coklat', cokelat: 'coklat', brown: 'coklat',
  abu: 'abu', 'abu-abu': 'abu', grey: 'abu', gray: 'abu',
  pink: 'pink',
  cream: 'cream', krem: 'cream',
  mocca: 'mocca', mocha: 'mocca',
  ungu: 'ungu', purple: 'ungu',
  oranye: 'oranye', orange: 'oranye',
  emas: 'emas', gold: 'emas',
  perak: 'perak', silver: 'perak',
  maroon: 'maroon', nude: 'nude', tosca: 'tosca',
};
const KUNCI_WARNA = Object.keys(WARNA).sort((a, b) => b.length - a.length);
const RE_WARNA = new RegExp(`\\b(${KUNCI_WARNA.join('|')})\\b`, 'i');

/** Satuan yang dikenali parser → faktor ke satuan dasar (null = tidak ada konversi). */
const SATUAN: Record<string, number | null> = {
  pcs: 1, pc: 1, buah: 1, bh: 1, unit: 1, set: 1, pasang: 1, psg: 1,
  lusin: 12, lsn: 12, lusinan: 12,
  kodi: 24, kd: 24, kodian: 24,
  box: null, bx: null, dus: null, karton: null,
  pak: null, pack: null, paket: null, karung: null, rim: null,
};
const KUNCI_SATUAN = Object.keys(SATUAN).sort((a, b) => b.length - a.length);
const RE_SATUAN = new RegExp(`\\b(\\d+(?:[.,]\\d+)?)\\s*(${KUNCI_SATUAN.join('|')})\\b`, 'i');

/** Kata umum yang bukan bagian nama produk. */
const STOPWORDS = new Set([
  'beli', 'dari', 'untuk', 'dengan', 'yang', 'dan', 'atau', 'sebanyak', 'masing',
  'semua', 'barang', 'produk', 'item', 'harga', 'diskon', 'potongan', 'disc',
  'discount', 'rp', 'jumlah', 'qty', 'tolong', 'please', 'request', 'pesan',
  'order', 'utk', 'dgn', 'ya', 'dong', 'deh', 'nih', 'buat', 'supaya', 'biar',
  'ada', 'ini', 'itu', 'the', 'of', 'and', 'or', 'for', 'plus', 'sama', 'per',
  'lagi', 'donk', 'ayo', 'mari', 'sih', 'saja', 'aja', 'kak', 'bro', 'mas',
  'mbak', 'pak', 'bu', 'no', 'nomor', 'kode', 'lengkap', 'beserta', 'termasuk',
  'ready', 'stok', 'promo', 'gratis', 'mohon', 'saya', 'kami', 'mau', 'akan',
  'ada', 'nya', 'punya', 'semua', 'dulu', 'baru', 'banyak', 'sedikit',
  'size', 'ukuran', 'warna', 'ok', 'oke', 'okay', 'thanks', 'thank', 'you',
  'makasih', 'terima', 'kasih', 'sip', 'siap', 'halo', 'hai', 'hello', 'test', 'tes',
]);
// Kata satuan tidak boleh menjadi kata kunci produk ("per lusin", dst).
for (const k of Object.keys(SATUAN)) STOPWORDS.add(k);

const SIZE_HURUF = ['xxxxl', 'xxxl', 'xxl', '3xl', '2xl', 'xl', 's', 'm', 'l'];
const RE_SIZE_HURUF = new RegExp(`\\b(${SIZE_HURUF.join('|')})\\b`, 'gi');
const RE_INTRO_PEMASOK = /^(?:beli\s+)?(?:dari|pemasok|supplier)\s+(.+)$/;
const RE_TANDA_PEMASOK = /\d|\b(?:size|ukuran|harga|rp|pcs|lusin|kodi|box)\b|@/i;

// --- Utilitas ---------------------------------------------------------------

/** "45.000" / "45,000" / "45.500,75" → number (gaya id-ID; koma = desimal bila bukan ribuan). */
function angka(s: string): number {
  const b = s.replace(/\s/g, '');
  if (/^\d{1,3}(\.\d{3})+$/.test(b)) return Number(b.replace(/\./g, ''));
  if (/^\d{1,3}(,\d{3})+$/.test(b)) return Number(b.replace(/,/g, ''));
  return Number(b.replace(',', '.'));
}

function tokenisasi(s: string): string[] {
  return s
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter(Boolean);
}

/** Normalisasi kata warna ke bentuk baku (navy → biru, cokelat → coklat, …). */
function warnaBaku(kata: string): string {
  const k = kata.toLowerCase();
  return WARNA[k] ?? k;
}

function normWarna(nilai: string | null | undefined): string | null {
  if (!nilai) return null;
  const kata = tokenisasi(nilai).filter((t) => t.length > 1 || WARNA[t]);
  return kata.length ? warnaBaku(kata[0]) : null;
}

function kutip(s: string): string {
  return s.replace(/[()[\]{}.,;:@/\\]/g, ' ').replace(/\s+/g, ' ').trim();
}

// --- Katalog ----------------------------------------------------------------

interface BarisProduk {
  id: number;
  sku: string;
  produk: string;
  size: string | null;
  warna: string | null;
  harga_beli: number;
  satuan_dasar_id: number | null;
}

interface ProdukKatalog {
  pid: number;
  nama: string;
  namaTokens: string[];
  matchTokens: Set<string>;
  sizeSet: Set<string>;
  unitId: number | null; // satuan dasar produk
  baris: BarisProduk[];
}

function muatKatalog(): ProdukKatalog[] {
  const rows = all<{
    id: number;
    sku: string;
    nama: string;
    harga_beli: number;
    satuan_dasar_id: number | null;
    kategori: string | null;
    merek: string | null;
  }>(
    `SELECT p.id, p.sku, p.nama, p.harga_beli, p.satuan_dasar_id,
            c.nama AS kategori, b.nama AS merek
       FROM products p
       LEFT JOIN categories c ON c.id = p.category_id
       LEFT JOIN brands b ON b.id = p.brand_id
      WHERE p.deleted_at IS NULL AND p.aktif = 1
      ORDER BY p.id`,
  );

  const peta = new Map<number, ProdukKatalog>();
  for (const r of rows) {
    const namaTokens = tokenisasi(r.nama);
    const kategoriTokens = r.kategori ? tokenisasi(r.kategori) : [];
    const merekTokens = r.merek ? tokenisasi(r.merek) : [];
    const p: ProdukKatalog = {
      pid: r.id,
      nama: r.nama,
      namaTokens,
      matchTokens: new Set([...namaTokens, ...kategoriTokens, ...merekTokens]),
      sizeSet: new Set<string>(),
      unitId: r.satuan_dasar_id ?? null,
      baris: [],
    };
    // Size & warna dari nama produk: angka 2 digit (25–65) / huruf ukuran,
    // dan kata warna yang dikenal kamus WARNA.
    let size: string | null = null;
    let warna: string | null = null;
    for (const t of namaTokens) {
      if (SIZE_HURUF.includes(t)) {
        p.sizeSet.add(t);
        size ??= t;
      } else if (/^\d{2}$/.test(t) && Number(t) >= 25 && Number(t) <= 65) {
        p.sizeSet.add(t);
        size ??= t;
      }
      if (warna === null && t in WARNA) warna = t;
    }
    p.baris.push({
      id: r.id,
      sku: r.sku,
      produk: r.nama,
      size,
      warna,
      harga_beli: Number(r.harga_beli ?? 0),
      satuan_dasar_id: r.satuan_dasar_id,
    });
    peta.set(r.id, p);
  }
  return [...peta.values()];
}

const infoProduk = (v: BarisProduk): InfoProduk => ({
  id: v.id,
  sku: v.sku,
  produk: v.produk,
  size: v.size,
  warna: v.warna,
  harga_beli: v.harga_beli,
  satuan_dasar_id: v.satuan_dasar_id,
});

// --- Pencocokan produk ------------------------------------------------------

interface HasilCocok {
  kecocokan: 'yakin' | 'kabur' | 'tidak';
  produk: ProdukKatalog | null;
  baris: BarisProduk | null;
  saran: InfoProduk[];
  alasan: string[];
}

function kumpulSaran(daftar: ProdukKatalog[], batas: number): InfoProduk[] {
  const keluar: InfoProduk[] = [];
  const lihat = new Set<number>();
  for (const p of daftar) {
    for (const v of p.baris) {
      if (lihat.has(v.id)) continue;
      lihat.add(v.id);
      keluar.push(infoProduk(v));
      if (keluar.length >= batas) return keluar;
    }
  }
  return keluar;
}

function pilihBaris(p: ProdukKatalog, warna: string | null, size: string | null): BarisProduk | null {
  let cand = p.baris;
  if (warna) cand = cand.filter((v) => !v.warna || normWarna(v.warna) === warna);
  if (size) cand = cand.filter((v) => !v.size || String(v.size).toLowerCase() === size);
  return cand.length === 1 ? cand[0] : null;
}

function cocokkanProduk(
  katalog: ProdukKatalog[],
  qTokens: string[],
  warna: string | null,
  size: string | null,
  rentang: [number, number] | null,
): HasilCocok {
  const cocokWarna = (p: ProdukKatalog): boolean =>
    !warna || p.namaTokens.some((t) => warnaBaku(t) === warna) || p.baris.some((v) => normWarna(v.warna) === warna);

  const cocokSize = (p: ProdukKatalog): boolean => {
    if (rentang) {
      return [...p.sizeSet].some((s) => /^\d+$/.test(s) && Number(s) >= rentang[0] && Number(s) <= rentang[1]);
    }
    if (size) return p.sizeSet.has(size);
    return true;
  };

  const skor = (p: ProdukKatalog): number =>
    qTokens.reduce((n, t) => n + (p.matchTokens.has(t) ? 1 : 0), 0);

  const tanpaFilter = katalog.map((p) => ({ p, n: skor(p) }));
  const kand = tanpaFilter
    .filter(({ p, n }) => cocokWarna(p) && cocokSize(p) && (qTokens.length === 0 || n > 0))
    .sort((a, b) => b.n - a.n || a.p.nama.localeCompare(b.p.nama));

  const alasan: string[] = [];

  if (qTokens.length === 0 && !warna && !size && !rentang) {
    return {
      kecocokan: 'tidak',
      produk: null,
      baris: null,
      saran: [],
      alasan: ['Produk tidak disebut dalam teks — pilih produk manual.'],
    };
  }

  if (kand.length === 0) {
    // Fallback saran: (kata ∧ warna) → warna → kata → size.
    const byKata = tanpaFilter.filter((x) => x.n > 0).sort((a, b) => b.n - a.n).map((x) => x.p);
    const dekat = [
      ...byKata.filter(cocokWarna),
      ...katalog.filter(cocokWarna),
      ...byKata,
      ...katalog.filter(cocokSize),
    ];
    const unik: ProdukKatalog[] = [];
    const lihat = new Set<number>();
    for (const p of dekat) {
      if (lihat.has(p.pid)) continue;
      lihat.add(p.pid);
      unik.push(p);
    }
    alasan.push(
      qTokens.length > 0
        ? `Produk "${qTokens.join(' ')}" tidak cocok di katalog${warna ? ` (warna ${warna})` : ''}${size ? ` (size ${size})` : ''} — pilih salah satu saran.`
        : `Tidak ada produk untuk warna${warna ? ` ${warna}` : ''}${size ? ` size ${size}` : ''} — pilih salah satu saran.`,
    );
    return {
      kecocokan: 'tidak',
      produk: null,
      baris: null,
      saran: kumpulSaran(unik, 6),
      alasan: unik.length === 0 ? [alasan[0], 'Tidak ada kandidat mirip — pilih produk manual.'] : alasan,
    };
  }

  const penuh = kand.filter((x) => x.n === qTokens.length);
  const sumber = penuh.length > 0 ? penuh : kand;
  const lanjutan = qTokens.length === 0;

  if (sumber.length === 1) {
    const p = sumber[0].p;
    const v = pilihBaris(p, warna, size);
    if (lanjutan) {
      // Baris lanjutan (tanpa nama produk) — produk diwarisi, tetap minta konfirmasi.
      return {
        kecocokan: 'kabur',
        produk: p,
        baris: v ?? (p.baris.length === 1 ? p.baris[0] : null),
        saran: v ? [infoProduk(v)] : (p.baris.length === 1 ? [infoProduk(p.baris[0])] : kumpulSaran([p], 6)),
        alasan: ['Baris lanjutan dari sebelumnya — konfirmasi produk pilihan.'],
      };
    }
    if (v) {
      return { kecocokan: 'yakin', produk: p, baris: v, saran: [], alasan: [] };
    }
    if (p.baris.length === 1) {
      return { kecocokan: 'yakin', produk: p, baris: p.baris[0], saran: [], alasan: [] };
    }
    const dekat = p.baris.filter((x) => (!warna || !x.warna || normWarna(x.warna) === warna) && (!size || !x.size || String(x.size).toLowerCase() === size));
    alasan.push('Produk punya beberapa produk — pilih produk yang tepat.');
    return {
      kecocokan: 'kabur',
      produk: p,
      baris: null,
      saran: (dekat.length ? dekat : p.baris).slice(0, 6).map(infoProduk),
      alasan,
    };
  }

  // Beberapa kandidat setara.
  const p = sumber[0].p;
  if (lanjutan) {
    alasan.push('Baris lanjutan dari sebelumnya — konfirmasi produk pilihan.');
  } else if (penuh.length > 1) {
    alasan.push(`Pilihan kabur: ${penuh.length} produk mirip — pilih salah satu saran.`);
  } else {
    alasan.push(`Cocok sebagian dengan "${p.nama}" — periksa pilihan.`);
  }
  const ambil = penuh.length > 0 ? penuh : kand;
  return {
    kecocokan: 'kabur',
    produk: lanjutan && ambil.length === 1 ? ambil[0].p : null,
    baris: null,
    saran: kumpulSaran(ambil.map((x) => x.p), 6),
    alasan,
  };
}

// --- Urai satu segmen --------------------------------------------------------

interface Mentah {
  teks: string;
  produkTeks: string;
  warna: string | null;
  size: string | null;
  rentang: [number, number] | null;
  qty: number | null;
  satuan: string | null;
  harga: number | null;
  diskonPersen: number | null;
  diskonRupiah: number | null;
  masing: boolean;
  sisaAngka: string[];
  kosong: boolean;
}

function uraiSegmen(segmen: string): Mentah {
  let mini = segmen.toLowerCase();
  const hasil: Mentah = {
    teks: segmen,
    produkTeks: '',
    warna: null,
    size: null,
    rentang: null,
    qty: null,
    satuan: null,
    harga: null,
    diskonPersen: null,
    diskonRupiah: null,
    masing: false,
    sisaAngka: [],
    kosong: true,
  };

  // 1. penanda "masing-masing" (rentang size per size)
  mini = mini.replace(/\bmasing[\s-]?masing\b/g, () => {
    hasil.masing = true;
    return ' ';
  });

  // 2. harga: @120000 · harga 45000 · rp 45.000
  mini = mini.replace(/(?:^|[^\w@])@\s*(\d[\d.,]*)/, (_, n: string) => {
    if (hasil.harga === null) hasil.harga = angka(n);
    return ' ';
  });
  mini = mini.replace(/\bharga\s*[:=]?\s*(?:per\s+\w+\s*)?(?:rp\.?\s*)?(\d[\d.,]*)/, (_, n: string) => {
    if (hasil.harga === null) hasil.harga = angka(n);
    return ' ';
  });
  mini = mini.replace(/\brp\.?\s*(\d[\d.,]*)/, (_, n: string) => {
    if (hasil.harga === null) hasil.harga = angka(n);
    return ' ';
  });

  // 3. diskon: "diskon 5%" (persen) / "diskon 5000" (rupiah)
  mini = mini.replace(
    /\b(?:diskon|potongan|disc|discount)\s*[:=]?\s*(\d[\d.,]*)\s*(%|persen)?/i,
    (_, n: string, p: string | undefined) => {
      if (p) hasil.diskonPersen = angka(n);
      else hasil.diskonRupiah = angka(n);
      return ' ';
    },
  );

  // 4. jumlah + satuan: "2 lusin", "10 pcs", "2 kodi"
  mini = mini.replace(RE_SATUAN, (_, n: string, s: string) => {
    if (hasil.qty === null) {
      hasil.qty = angka(n);
      hasil.satuan = s.toLowerCase();
    }
    return ' ';
  });

  // 5. qty × harga: "3 x 45000"
  mini = mini.replace(/\b(\d+)\s*[x×]\s*(\d[\d.,]*)/, (_, q: string, h: string) => {
    if (hasil.qty === null) hasil.qty = angka(q);
    if (hasil.harga === null) hasil.harga = angka(h);
    return ' ';
  });

  // 6. size eksplisit: "size M", "ukuran 39", "ukuran 39-43"
  mini = mini.replace(
    /\b(?:size|ukuran|uk)\s*[:=]?\s*([a-z0-9]+(?:\s*[-–]\s*[a-z0-9]+)?)/i,
    (_, v: string) => {
      const nilai = String(v).replace(/\s/g, '');
      if (nilai.includes('-')) {
        const [a, b] = nilai.split(/[-–]/).map(Number);
        if (Number.isFinite(a) && Number.isFinite(b) && !hasil.rentang) {
          hasil.rentang = [Math.min(a, b), Math.max(a, b)];
        }
      } else if (!hasil.size && !hasil.rentang) {
        hasil.size = nilai.toLowerCase();
      }
      return ' ';
    },
  );

  // 7. rentang size bebas: "39-43"
  mini = mini.replace(/\b(\d{2})\s*[-–]\s*(\d{2})\b/, (_, a: string, b: string) => {
    if (!hasil.rentang && !hasil.size) {
      const x = Number(a);
      const y = Number(b);
      hasil.rentang = [Math.min(x, y), Math.max(x, y)];
    }
    return ' ';
  });

  // 8. warna (kata pertama yang dikenali)
  mini = mini.replace(RE_WARNA, (m: string) => {
    if (!hasil.warna) hasil.warna = warnaBaku(m);
    return ' ';
  });

  // 9. size huruf tersendiri (M, L, XL) — ambil yang pertama, buang semuanya
  mini = mini.replace(RE_SIZE_HURUF, (m: string) => {
    if (!hasil.size && !hasil.rentang) hasil.size = m.toLowerCase();
    return ' ';
  });

  // 10. angka sisa: 25–65 bilangan → size; ≥1000 & belum ada harga → harga;
  //     selain itu → jumlah (bila belum) — sisanya dicatat sebagai sisa.
  mini = mini.replace(/\d+(?:[.,]\d+)?/g, (m: string) => {
    const n = angka(m);
    if (!hasil.size && !hasil.rentang && Number.isInteger(n) && n >= 25 && n <= 65) {
      hasil.size = String(n);
      return ' ';
    }
    if (hasil.harga === null && n >= 1000) {
      hasil.harga = n;
      return ' ';
    }
    if (hasil.qty === null) {
      hasil.qty = n;
      return ' ';
    }
    hasil.sisaAngka.push(m);
    return ' ';
  });

  hasil.produkTeks = kutip(
    mini
      .replace(/^(?:yang|untuk|dengan|dan|dari|buat|tolong|request|pesan|order|sebanyak|per|nya)\s+/, '')
      .replace(/\s+(?:yang|untuk|dengan|dan|dari|ya|dong|nih|nya)$/, ''),
  );

  hasil.kosong =
    !hasil.produkTeks &&
    hasil.qty === null &&
    hasil.harga === null &&
    hasil.warna === null &&
    !hasil.size &&
    !hasil.rentang &&
    hasil.diskonPersen === null &&
    hasil.diskonRupiah === null;

  return hasil;
}

// --- Pemasok -----------------------------------------------------------------

function uraiPemasok(
  asliSeg: string[],
  miniSeg: string[],
  pemasokIdx: { i: number },
  catatan: string[],
): PemasokUrai {
  const suppliers = all<{ id: number; nama: string }>(`SELECT id, nama FROM suppliers ORDER BY nama`);
  const cari = (teks: string) => {
    const t = teks.toLowerCase().trim();
    if (!t) return null;
    const exact = suppliers.find((s) => s.nama.toLowerCase() === t);
    if (exact) return exact;
    const contains = suppliers.find(
      (s) => s.nama.toLowerCase().includes(t) || t.includes(s.nama.toLowerCase()),
    );
    if (contains) return contains;
    const tt = tokenisasi(t).filter((x) => x.length >= 2);
    if (!tt.length) return null;
    // Semua kata frasa harus ada di nama pemasok (frasa ⊆ nama) — arah ini
    // mencegah "Supplier Zzz" dianggap cocok dengan "Supplier A".
    return (
      suppliers.find((s) => {
        const st = new Set(tokenisasi(s.nama).filter((x) => x.length >= 2));
        return tt.every((x) => st.has(x));
      }) ?? null
    );
  };
  const saranDari = (teks: string | null): { id: number; nama: string }[] => {
    const tt = teks ? new Set(tokenisasi(teks)) : new Set<string>();
    const dekat = suppliers.filter((s) => tokenisasi(s.nama).some((x) => tt.has(x)));
    const pakai = dekat.length ? dekat : suppliers;
    return pakai.slice(0, 6).map((s) => ({ id: s.id, nama: s.nama }));
  };

  // a. nama pemasok langsung ada di teks (bentuk terpanjang dahulu)
  const teksGabung = miniSeg.join(' , ');
  let langsung: { id: number; nama: string } | null = null;
  for (const s of [...suppliers].sort((a, b) => b.nama.length - a.nama.length)) {
    const n = s.nama.toLowerCase();
    if (n && teksGabung.includes(n)) {
      langsung = s;
      for (let j = 0; j < miniSeg.length; j++) miniSeg[j] = miniSeg[j].split(n).join(' ');
      break;
    }
  }

  // b. klause intro: "beli dari X" / "dari X" / "pemasok X" tanpa angka/satuan
  for (let i = 0; i < miniSeg.length; i++) {
    const m = miniSeg[i].match(RE_INTRO_PEMASOK);
    if (!m || m.index !== 0) continue;
    const capture = (m[1] ?? '').trim();
    if (RE_TANDA_PEMASOK.test(capture)) continue;
    const capStart = m.index + m[0].length - (m[1]?.length ?? 0);
    const teks = capture || langsung?.nama || '';
    const teksAsli = capture ? asliSeg[i].slice(capStart).trim() : langsung?.nama || '';
    if (!teks && !teksAsli) {
      // Klause intro kosong (nama sudah terlanjur dikosongkan) — segmen ini
      // bukan item; buang dari daftar item tanpa pesan khusus.
      pemasokIdx.i = i;
      return { teks: null, supplier_id: null, cocok: false, saran: [] };
    }
    const cocok = cari(teks) ?? langsung;
    pemasokIdx.i = i;
    if (cocok) return { teks: teksAsli || cocok.nama, supplier_id: cocok.id, cocok: true, saran: [] };
    if (teksAsli) {
      catatan.push(`Pemasok "${teksAsli}" tidak ditemukan di master supplier — pilih manual.`);
      return { teks: teksAsli, supplier_id: null, cocok: false, saran: saranDari(teksAsli) };
    }
  }

  // c. nama pemasok terdeteksi langsung di tengah kalimat
  if (langsung) {
    return { teks: langsung.nama, supplier_id: langsung.id, cocok: true, saran: [] };
  }

  return { teks: null, supplier_id: null, cocok: false, saran: [] };
}

/** Segmen yang tidak menyisakan kata produk, angka, warna, maupun size. */
function segmenTidakTerkunci(mentah: Mentah, qTokens: string[]): boolean {
  return (
    qTokens.length === 0 &&
    mentah.qty === null &&
    mentah.harga === null &&
    !mentah.warna &&
    !mentah.size &&
    !mentah.rentang &&
    mentah.diskonPersen === null &&
    mentah.diskonRupiah === null
  );
}

// --- Fungsi utama --------------------------------------------------------------

export function uraiPembelian(teksMentah: string): HasilUrai {
  // Gaya BARIS (satu baris per barang, tulis ke bawah): terdeteksi dari bullet
  // "•/-/*", baris "Total = …", atau 3+ baris dengan baris kedua berupa tanggal.
  if (gayaBaris(teksMentah)) return uraiPembelianBaris(teksMentah);
  const teks = teksMentah.replace(/\s+/g, ' ').trim();
  const asliSeg = teks.split(/\s*(?:[,;\n]|\s+dan\s+)\s*/i).filter((s) => s.trim());
  const miniSeg = asliSeg.map((s) => s.toLowerCase());

  const catatan: string[] = [];
  const pemasokIdx = { i: -1 };
  const pemasok = uraiPemasok(asliSeg, miniSeg, pemasokIdx, catatan);

  // Segmen diskon global: "diskon 5%" sendirian → berlaku untuk semua baris.
  let diskonGlobalPersen: number | null = null;
  const itemIdx: number[] = [];
  for (let i = 0; i < miniSeg.length; i++) {
    if (i === pemasokIdx.i) continue;
    const m = miniSeg[i].trim().match(/^(?:diskon|potongan|disc|discount)\s*[:=]?\s*(\d[\d.,]*)\s*(%|persen)?$/i);
    if (m) {
      const nilai = angka(m[1]);
      if (m[2]) diskonGlobalPersen = nilai;
      else catatan.push(`Diskon global Rp ${nilai} tidak otomatis — isi manual per baris.`);
      continue;
    }
    itemIdx.push(i);
  }
  if (diskonGlobalPersen !== null) catatan.push(`Diskon ${diskonGlobalPersen}% diterapkan ke semua baris.`);

  const katalog = muatKatalog();
  const baris: BarisUrai[] = [];

  for (const i of itemIdx) {
    const mentah = uraiSegmen(miniSeg[i]);
    const qTokens = tokenisasi(mentah.produkTeks).filter((t) => t.length > 1 && !STOPWORDS.has(t));
    if (segmenTidakTerkunci(mentah, qTokens)) {
      catatan.push(`Segmen "${asliSeg[i]}" tidak terbaca — diabaikan.`);
      continue;
    }
    if (mentah.sisaAngka.length) {
      catatan.push(`Angka tidak terbaca di "${asliSeg[i]}": ${mentah.sisaAngka.join(', ')}.`);
    }

    // Rentang size → satu baris per size dalam rentang (jumlah berlaku per size).
    const sub: { size: string | null; rentang: [number, number] | null }[] = [];
    if (mentah.rentang && mentah.rentang[1] - mentah.rentang[0] + 1 <= 12) {
      for (let n = mentah.rentang[0]; n <= mentah.rentang[1]; n++) sub.push({ size: String(n), rentang: null });
      if (mentah.qty !== null || mentah.size === null) {
        catatan.push(`Rentang size ${mentah.rentang[0]}–${mentah.rentang[1]}: jumlah berlaku untuk tiap size.`);
      }
    } else if (mentah.rentang) {
      sub.push({ size: null, rentang: mentah.rentang });
    } else {
      sub.push({ size: mentah.size, rentang: null });
    }

    for (const s of sub) {
      const alasan: string[] = [];
      const cocok = cocokkanProduk(
        katalog,
        qTokens,
        mentah.warna,
        s.size,
        s.rentang ?? (s.size === null ? mentah.rentang : null),
      );
      alasan.push(...cocok.alasan);
      if (s.rentang) alasan.push(`Rentang size ${s.rentang[0]}–${s.rentang[1]} belum dirinci per size.`);

      // Jumlah: konversi ke satuan dasar.
      let qty = mentah.qty;
      if (qty === null) {
        qty = 1;
        alasan.push('Jumlah tidak disebut — diasumsikan 1.');
      }
      let qtyDasar = qty;
      let konversi: string | null = null;
      if (mentah.satuan) {
        const f = SATUAN[mentah.satuan];
        if (f === null || f === undefined) {
          alasan.push(`Satuan "${mentah.satuan}" tidak punya konversi ke satuan dasar — periksa jumlah.`);
        } else if (f !== 1) {
          qtyDasar = qty * f;
          konversi = `${qty} ${mentah.satuan} → ${qtyDasar} (satuan dasar)`;
        }
      }

      // Harga: dari teks, atau jatuh ke harga beli produk.
      let harga = mentah.harga;
      let hargaDariMaster = false;
      if (harga === null) {
        if (cocok.baris) {
          harga = cocok.baris.harga_beli;
          hargaDariMaster = true;
          alasan.push('Harga tidak disebut — diambil dari harga beli produk.');
        } else {
          harga = 0;
          alasan.push('Harga tidak disebut.');
        }
      }

      // Diskon baris (persen dari segmen/globally → rupiah).
      let diskonPersen = mentah.diskonPersen;
      let diskon = mentah.diskonRupiah ?? 0;
      if (diskonPersen !== null) {
        diskon = Math.round((qtyDasar * harga * diskonPersen) / 100);
      } else if (diskonGlobalPersen !== null) {
        diskonPersen = diskonGlobalPersen;
        diskon = Math.round((qtyDasar * harga * diskonGlobalPersen) / 100);
      }

      baris.push({
        teks: mentah.teks,
        produk_teks: mentah.produkTeks,
        warna: mentah.warna,
        size: s.size ?? mentah.size,
        rentang_size: s.rentang ?? mentah.rentang,
        qty: mentah.qty,
        satuan_teks: mentah.satuan,
        qty_dasar: qtyDasar,
        konversi,
        harga,
        harga_dari_master: hargaDariMaster,
        diskon_persen: diskonPersen,
        diskon,
        product_id: cocok.baris?.id ?? null,
        baris: cocok.baris ? infoProduk(cocok.baris) : null,
        unit_id: cocok.baris?.satuan_dasar_id ?? null,
        kecocokan: cocok.kecocokan,
        saran: cocok.saran,
        alasan,
      });
    }
  }

  if (baris.length === 0 && catatan.length === 0) {
    catatan.push('Tidak ada item yang terbaca — tulis keterangan pembelian, misalnya "beli dari PT Contoh Pemasok, Amara Hitam 39 2 lusin harga 45000".');
  }

  const pesan_bot = susunPesanBot(pemasok, baris, catatan);
  return { pemasok, baris, catatan, pesan_bot };
}

// --- Balasan chat --------------------------------------------------------------

// ===================== GAYA BARIS (satu baris per barang) ==================
// Tulis ke bawah, satu baris per barang — format utama mode Chatbot:
//
//   Bos ace
//   Jumat 09 okt
//   • chx merah 6 kd (3kd db 42 tp 39)
//   • ston hitam 4 kd
//   Total = 15 kd
//
// "kd" = kodi (1 kodi = N pasang menurut aturan di Pengaturan → aturan_kodi,
// bawaan 20 pasang dengan size 39/40/41/42/43 masing-masing 4 pasang).
// Isi kurung = komposisi sebagian kodi: "(3kd db 42 tp 39)" → 3 kodi dari
// total memakai Double size 42 + Tanpa size 39 (size 42 jadi 8 pasang dan 39
// jadi 0 per kodi — total per kodi tetap).

const BULAN_ID: Record<string, number> = {
  jan: 1, januari: 1, feb: 2, peb: 2, februari: 2, pebruari: 2,
  mar: 3, maret: 3, apr: 4, april: 4, mei: 5,
  jun: 6, juni: 6, jul: 7, juli: 7, agu: 8, agt: 8, agustus: 8,
  sep: 9, september: 9, okt: 10, oktober: 10,
  nov: 11, november: 11, des: 12, desember: 12,
};
const RE_HARI = /^(senin|selasa|rabu|kamis|jum['’]?at|sabtu|ahad|minggu)\b[\s,]*/i;
const RE_BULLET = /^\s*[•\-*·]\s+\S/;

/** Aturan per kodi (ukuran & jatah per size) — di Pengaturan → `aturan_kodi`. */
export interface AturanKodi {
  per_kodi: number;
  normal: Record<string, number>;
}

const ATURAN_KODI_BAWAAN: AturanKodi = {
  per_kodi: 20,
  normal: { '39': 4, '40': 4, '41': 4, '42': 4, '43': 4 },
};

/** Baca aturan kodi dari Pengaturan; JSON tidak valid → aturan bawaan. */
export function muatAturanKodi(): AturanKodi {
  const raw = getSettings()['aturan_kodi'];
  if (raw) {
    try {
      const j = JSON.parse(raw) as { per_kodi?: number; normal?: Record<string, unknown> };
      const per = Number(j.per_kodi);
      const normal: Record<string, number> = {};
      for (const [k, v] of Object.entries(j.normal ?? {})) {
        const n = Number(v);
        if (/^\d{1,3}$/.test(k) && Number.isFinite(n) && n >= 0) normal[k] = n;
      }
      if (Number.isFinite(per) && per > 0 && Object.keys(normal).length > 0) return { per_kodi: per, normal };
    } catch {
      /* aturan rusak → pakai bawaan */
    }
  }
  return { per_kodi: ATURAN_KODI_BAWAAN.per_kodi, normal: { ...ATURAN_KODI_BAWAAN.normal } };
}

/** Apakah teks memakai gaya baris (satu baris per barang)? */
function gayaBaris(teks: string): boolean {
  const garis = teks.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  if (garis.length === 0) return false;
  if (garis.some((g) => RE_BULLET.test(g))) return true;
  if (garis.some((g) => /^\s*(?:total|tot)\s*[:=]/i.test(g))) return true;
  if (garis.length >= 3 && uraiTanggalBaris(garis[1]) !== null) return true;
  // AF3 — baris tunggal bergaya chatbot: komposisi db/tp ATAU jumlah kodi polos
  // memakai parser gaya baris supaya rincian size mengikuti profil barang
  // ("amara hitam 1 kd db 37 tp 40", "rulfine mocca 4 kd"). Tanda gaya BEBAS
  // (koma pemisah beberapa barang, "masing-masing", pemasok "beli dari …")
  // tetap bebas — TAPI @harga tidak: parser gaya baris ikut membaca @/rp
  // ("6 kd db 43 tp 39 @150000" wajib tetap komposisi, bukan jatuh ke gaya lama).
  const tandaBebas = /[,;]|\bmasing[\s-]masing\b/i;
  if (garis.some((g) => tandaBebas.test(g))) return false;
  if (garis.some((g) => /\b(?:db|tp)\s*[.:]?\s*\d{1,3}/i.test(g))) return true;
  if (garis.length === 1 && /\b\d+(?:[.,]\d+)?\s*(?:kd|kodi|kodian)\b/i.test(garis[0])) return !RE_INTRO_PEMASOK.test(garis[0]);
  return false;
}

/** "Jumat 09 okt" · "09/10/2026" · "9 oktober 2026" → 'YYYY-MM-DD'. */
function uraiTanggalBaris(t: string): string | null {
  let s = t.trim().toLowerCase().replace(RE_HARI, '').replace(/^[,;]+/, '').trim();
  if (!s) return null;

  const susun = (d: number, m: number, y?: number): string | null => {
    const tahun = y && y >= 1000 ? y : y && y < 100 ? 2000 + y : new Date().getFullYear();
    if (!(m >= 1 && m <= 12) || !(d >= 1 && d <= 31)) return null;
    const uji = new Date(tahun, m - 1, d);
    if (uji.getMonth() !== m - 1) return null;
    return `${tahun}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  };

  let m = s.match(/^(\d{1,2})\s*[\/-]\s*(\d{1,2})(?:\s*[\/-]\s*(\d{2,4}))?\b/);
  if (m) return susun(Number(m[1]), Number(m[2]), m[3] ? Number(m[3]) : undefined);

  m = s.match(/^(\d{1,2})\s+([a-z]+)(?:\s+(\d{4}))?/);
  if (m && m[2].length >= 3 && BULAN_ID[m[2].slice(0, 3)]) {
    return susun(Number(m[1]), BULAN_ID[m[2].slice(0, 3)], m[3] ? Number(m[3]) : undefined);
  }
  return null;
}

/** Pencocokan baris pertama ke master Pemasok (bila belum ada → saran/buat baru). */
function pemasokBaris(teks: string): PemasokUrai {
  const t = teks.trim();
  if (!t) return { teks: null, supplier_id: null, cocok: false, saran: [] };
  const suppliers = all<{ id: number; nama: string }>(`SELECT id, nama FROM suppliers ORDER BY nama`);
  const lower = t.toLowerCase();
  const exact = suppliers.find((s) => s.nama.toLowerCase() === lower);
  if (exact) return { teks: exact.nama, supplier_id: exact.id, cocok: true, saran: [] };
  const contains = suppliers.find((s) => s.nama.toLowerCase().includes(lower) || lower.includes(s.nama.toLowerCase()));
  if (contains) return { teks: t, supplier_id: contains.id, cocok: true, saran: [] };
  const tt = tokenisasi(t).filter((x) => x.length >= 2);
  const frasa = tt.length
    ? suppliers.find((s) => {
        const st = new Set(tokenisasi(s.nama).filter((x) => x.length >= 2));
        return tt.every((x) => st.has(x));
      })
    : undefined;
  if (frasa) return { teks: t, supplier_id: frasa.id, cocok: true, saran: [] };
  const set = new Set(tt);
  const dekat = suppliers.filter((s) => tokenisasi(s.nama).some((x) => set.has(x)));
  return {
    teks: t,
    supplier_id: null,
    cocok: false,
    saran: (dekat.length ? dekat : suppliers).slice(0, 6).map((s) => ({ id: s.id, nama: s.nama })),
  };
}

interface MentahBaris {
  teks: string;
  nama: string;
  warna: string | null;
  size: string | null;
  kodi: number | null; // jumlah kodi yang disebut ("6 kd")
  bebas: number; // jumlah pasang di luar kodi (pcs, lusin, ",10pcs")
  kodiKomposisi: number | null; // n pada "(nkd db X tp Y)" — null = seluruh kodi
  komposisi: [number, number] | null; // [double size, tanpa size]
  /** Petunjuk size Db/Tp — dibaca di dalam maupun luar kurung (AF3). */
  db: number | null;
  tp: number | null;
  qtyTeks: string;
  harga: number | null;
  diskonPersen: number | null;
  adaJumlah: boolean;
}

/** Urai satu baris "• chx merah 6 kd (3kd db 42 tp 39)". */
function uraiBarisItem(barisMentah: string, catatan: string[]): MentahBaris {
  let sisa = barisMentah.replace(/^\s*[•\-*·]\s+/, '').trim();
  const asli = sisa;
  const out: MentahBaris = {
    teks: asli,
    nama: '',
    warna: null,
    size: null,
    kodi: null,
    bebas: 0,
    kodiKomposisi: null,
    komposisi: null,
    db: null,
    tp: null,
    qtyTeks: '',
    harga: null,
    diskonPersen: null,
    adaJumlah: false,
  };
  const qTeks: string[] = [];
  const buang = (m: RegExpMatchArray) => {
    const i = m.index ?? 0;
    sisa = `${sisa.slice(0, i)} ${sisa.slice(i + m[0].length)}`;
  };

  // 1) komposisi dalam kurung: "(3kd db 42 tp 39)"
  sisa = sisa.replace(/\(([^)]*)\)/g, (_, isi: string) => {
    const teks = String(isi);
    const m = teks.match(
      /(\d+(?:[.,]\d+)?)?\s*(?:kd|kodi|kodian)?\s*db\s*[.:]?\s*(\d{1,3})[^\d]*?tp\s*[.:]?\s*(\d{1,3})/i,
    );
    if (m) {
      if (out.komposisi) {
        catatan.push(`Baris "${asli}": hanya satu komposisi (db/tp) yang dibaca.`);
      } else {
        out.komposisi = [Number(m[2]), Number(m[3])];
        out.kodiKomposisi = m[1] !== undefined ? angka(m[1]) : null;
      }
      return ' ';
    }
    if (teks.trim()) catatan.push(`Isi kurung "(${teks.trim()})" tidak terbaca — komposisi diabaikan.`);
    return ' ';
  });

  // 1b) Db/Tp DI LUAR kurung: "amara hitam 1 kd db 37 tp 40" atau hanya "db 37".
  // Petunjuk ini dipakai untuk resolusi profil (AF1 tahap 4) dan komposisi (AE).
  if (out.komposisi) {
    out.db = out.komposisi[0];
    out.tp = out.komposisi[1];
  } else {
    const mDb = sisa.match(/\bdb\s*[.:]?\s*(\d{1,3})/i);
    const mTp = sisa.match(/\btp\s*[.:]?\s*(\d{1,3})/i);
    // Hapus dari belakang agar indeks yang lebih awal tetap sah.
    if (mTp) {
      out.tp = Number(mTp[1]);
      sisa = `${sisa.slice(0, mTp.index ?? 0)} ${sisa.slice((mTp.index ?? 0) + mTp[0].length)}`;
    }
    if (mDb) {
      out.db = Number(mDb[1]);
      sisa = `${sisa.slice(0, mDb.index ?? 0)} ${sisa.slice((mDb.index ?? 0) + mDb[0].length)}`;
    }
    if (out.db !== null && out.tp !== null) out.komposisi = [out.db, out.tp];
    else if (out.db !== null || out.tp !== null) {
      catatan.push(`Baris "${asli}": hanya Db/Tp sebagian yang dibaca — komposisi butuh keduanya.`);
    }
  }

  // 2) harga & diskon bila disebut eksplisit
  sisa = sisa.replace(/@(\d[\d.,]*)/, (_, n: string) => {
    if (out.harga === null) out.harga = angka(n);
    return ' ';
  });
  sisa = sisa.replace(/\bharga\s*[:=]?\s*(?:rp\.?\s*)?(\d[\d.,]*)/i, (_, n: string) => {
    if (out.harga === null) out.harga = angka(n);
    return ' ';
  });
  // "rp 45.000" / "rp45000" tanpa kata "harga" — samakan dengan parser gaya bebas.
  sisa = sisa.replace(/\brp\.?\s*(\d[\d.,]*)/i, (_, n: string) => {
    if (out.harga === null) out.harga = angka(n);
    return ' ';
  });
  sisa = sisa.replace(/\b(?:diskon|disc|potongan)\s*[:=]?\s*(\d[\d.,]*)\s*(%|persen)?/i, (m, n: string, p?: string) => {
    if (p) out.diskonPersen = angka(n);
    else catatan.push(`Diskon rupiah "${m.trim()}" tidak otomatis di gaya baris — isi manual per baris.`);
    return ' ';
  });

  // 3) jumlah: kombinasi "2,10pcs" → 2 kodi + 10 pcs; lalu kodi / lusin / pcs
  const gabung = sisa.match(/\b(\d+)\s*,\s*(\d+)\s*(pcs|psg|pasang|bh|pc)\b/i);
  if (gabung) {
    out.kodi = angka(gabung[1]);
    out.bebas += angka(gabung[2]);
    qTeks.push(gabung[0].trim().replace(/\s+/g, ''));
    buang(gabung);
  }
  const kodiM = sisa.match(/\b(\d+(?:[.,]\d+)?)\s*(kd|kodi|kodian)\b/i);
  if (kodiM) {
    out.kodi = (out.kodi ?? 0) + angka(kodiM[1]);
    qTeks.push(kodiM[0].trim());
    buang(kodiM);
  }
  const lusinM = sisa.match(/\b(\d+(?:[.,]\d+)?)\s*(lsn|lusin|lusinan)\b/i);
  if (lusinM) {
    out.bebas += angka(lusinM[1]) * 12;
    qTeks.push(lusinM[0].trim());
    buang(lusinM);
  }
  const pcsM = sisa.match(/\b(\d+(?:[.,]\d+)?)\s*(pcs|psg|pasang|bh|pc|buah|unit|set)\b/i);
  if (pcsM) {
    out.bebas += angka(pcsM[1]);
    qTeks.push(pcsM[0].trim());
    buang(pcsM);
  }
  out.qtyTeks = qTeks.join(' + ');

  // 4) size eksplisit: "size 42" / "ukuran M" / angka 25–65 tersisa
  const sizeM = sisa.match(/\b(?:size|ukuran|uk)\s*[:.]?\s*([a-z0-9]+(?:\s*[-–]\s*[a-z0-9]+)?)/i);
  if (sizeM) {
    const nilai = sizeM[1].replace(/\s/g, '');
    if (nilai.includes('-')) catatan.push(`Rentang size pada "${asli}" tidak dipakai gaya baris — sebutkan per baris.`);
    else out.size = nilai.toLowerCase();
    buang(sizeM);
  } else {
    // Rentang telanjang "39-43" (tanpa kata "size"): baris memakai daftar size
    // profil (X5) — buang angkanya supaya tidak jadi sampah di nama produk.
    const rentangM = sisa.match(/\b(2[5-9]|[3-6]\d)\s*[-–\/]\s*(2[5-9]|[3-6]\d)\b/);
    if (rentangM) {
      catatan.push(`Rentang size ${rentangM[1]}–${rentangM[2]} pada "${asli}" tidak dipakai gaya baris — baris memakai daftar size profil.`);
      buang(rentangM);
    } else {
      const angkaM = sisa.match(/\b(2[5-9]|[3-6]\d)\b/);
      if (angkaM) {
        out.size = angkaM[1];
        buang(angkaM);
      }
    }
  }

  // 5) warna, lalu sisa = nama produk
  const warnaM = sisa.match(RE_WARNA);
  if (warnaM) {
    out.warna = warnaBaku(warnaM[0]);
    sisa = sisa.replace(RE_WARNA, ' ');
  }
  out.nama = kutip(sisa);
  out.adaJumlah = out.kodi !== null || out.bebas > 0 || (out.komposisi !== null && out.kodiKomposisi !== null);
  if (out.adaJumlah && !out.qtyTeks) out.qtyTeks = out.kodiKomposisi !== null ? `${out.kodiKomposisi} kd` : '';
  return out;
}

/** Harga beli terakhir dari pemasok tersebut (fallback: harga beli produk). */
function hargaTerakhirSupplier(supplierId: number | null, productIds: number[]): Map<number, number> {
  const peta = new Map<number, number>();
  if (!supplierId || productIds.length === 0) return peta;
  const ph = productIds.map(() => '?').join(',');
  const rows = all<{ product_id: number; harga_beli: number }>(
    `SELECT pi.product_id, pi.harga_beli
       FROM purchase_items pi
       JOIN purchases p ON p.id = pi.purchase_id
      WHERE p.supplier_id = ? AND p.status <> 'batal' AND pi.product_id IN (${ph})
      ORDER BY p.tanggal DESC, p.id DESC, pi.id DESC`,
    supplierId,
    ...productIds,
  );
  for (const r of rows) if (!peta.has(Number(r.product_id))) peta.set(Number(r.product_id), Number(r.harga_beli ?? 0));
  return peta;
}

const BULAN_PANJANG = [
  '', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember',
];

/** Skor saran per baris: size sama didahulukan, lalu warna sama. */
function skorSaran(v: InfoProduk, size: string | null, warna: string | null): number {
  let n = 0;
  if (size && v.size && String(v.size).toLowerCase() === size.toLowerCase()) n += 4;
  if (warna && normWarna(v.warna) === warna) n += 2;
  return n;
}

/**
 * Koreksi manual dari pratinjau (AF4): pengguna mengganti profil / Db / Tp
 * pada satu baris — parser menghitung ulang dengan pilihan itu.
 */
export interface UrahanBaris {
  /** Id profil pilihan pengguna; null = lepas (kembali resolusi otomatis). */
  profil_id?: number | null;
  db?: number | null;
  tp?: number | null;
}

/** Parser gaya baris utama. */
export function uraiPembelianBaris(teksMentah: string, ubah?: UrahanBaris): HasilUrai {
  // Aturan global (baris "Total = …" & fallback): profil default bila ada (X5.3).
  const aturan = aturanDariProfil(profilSizeDefault()) ?? muatAturanKodi();
  const catatan: string[] = [];
  const garis = teksMentah.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);

  // 1) baris "Total = …" — dipakai sebagai verifikasi, bukan sumber jumlah.
  let klaim: number | null = null;
  const badan: string[] = [];
  for (const g of garis) {
    const mt = g.match(/^\s*(?:total|tot)\s*[:=]\s*(\d+(?:[.,]\d+)?)\s*(kd|kodi|kodian|pcs|psg|pasang)?/i);
    if (mt) {
      const nilai = angka(mt[1]);
      const satuan = (mt[2] ?? '').toLowerCase();
      if (satuan.startsWith('p')) {
        klaim = nilai / aturan.per_kodi;
        catatan.push(`Total tertulis ${nilai} pasang → ${klaim} kodi (1 kodi = ${aturan.per_kodi} pasang).`);
      } else if (satuan) {
        klaim = nilai;
      } else {
        // Tanpa satuan: nilai besar berarti pasang, kecil berarti kodi.
        klaim = nilai >= aturan.per_kodi ? nilai / aturan.per_kodi : nilai;
        if (nilai >= aturan.per_kodi) catatan.push(`Total "${g}" tanpa satuan — dibaca ${nilai} pasang (${klaim} kodi).`);
      }
      continue;
    }
    badan.push(g);
  }

  // 2) baris awal: pemasok (baris 1) & tanggal (baris 2), sisanya item.
  let tanggal: string | null = null;
  let teksPemasok: string | null = null;
  const itemGar: string[] = [];
  for (const g of badan) {
    if (RE_BULLET.test(g)) {
      itemGar.push(g);
      continue;
    }
    if (tanggal === null) {
      const t = uraiTanggalBaris(g);
      if (t) {
        tanggal = t;
        continue;
      }
    }
    // Baris pertama = pemasok HANYA bila ada baris lain setelahnya atau barisnya
    // memang gaya "beli dari …". Pesan tunggal ("amara hitam 1 kd db 37 tp 40")
    // adalah BARIS BARANG, bukan pemasok (AF3).
    if (teksPemasok === null && (badan.length > 1 || RE_INTRO_PEMASOK.test(g))) {
      teksPemasok = g;
      continue;
    }
    itemGar.push(g);
  }
  if (tanggal === null) catatan.push('Baris tanggal tidak terbaca — tanggal dokumen memakai isian form.');
  const pemasok: PemasokUrai = pemasokBaris(teksPemasok ?? '');
  if (teksPemasok && !pemasok.cocok) {
    catatan.push(`Pemasok "${teksPemasok}" belum ada di master — buat baru atau pilih saran.`);
  }

  // 3) urai tiap baris item → beberapa baris draft (per size).
  const katalog = muatKatalog();
  const baris: BarisUrai[] = [];
  const pratinjau: PratinjauUrai[] = [];
  let grup = 0;

  for (const g of itemGar) {
    const mentah = uraiBarisItem(g, catatan);
    // AF4 — koreksi Db/Tp dari pratinjau diterapkan SEBELUM resolusi profil.
    if (ubah && (ubah.db !== undefined || ubah.tp !== undefined)) {
      const db = ubah.db ?? null;
      const tp = ubah.tp ?? null;
      mentah.db = db;
      mentah.tp = tp;
      mentah.komposisi = db !== null && tp !== null ? [db, tp] : null;
      if (!mentah.komposisi) mentah.kodiKomposisi = null;
    }
    const alasan: string[] = [];
    if (!mentah.nama && !mentah.warna && !mentah.size && !mentah.adaJumlah) {
      catatan.push(`Baris "${g}" tidak terbaca — diabaikan.`);
      continue;
    }
    if (!mentah.nama) alasan.push('Nama barang tidak terbaca — ketik nama barangnya.');
    if (!mentah.adaJumlah) alasan.push('Jumlah tidak terbaca — isi jumlah sebelum simpan.');

    const qTokens = tokenisasi(mentah.nama).filter((t) => t.length > 1 && !STOPWORDS.has(t));
    const cocok = cocokkanProduk(katalog, qTokens, mentah.warna, null, null);

    // Profil size baris ini — urutan AF1: produk > kategori/merek > kata penanda
    // > petunjuk size Db/Tp > profil default > bila ragu, tanyakan di pratinjau.
    const resolusi = resolusiProfilSize({
      produkId: cocok.produk?.pid ?? null,
      teks: g,
      sizes: [mentah.db, mentah.tp, mentah.size],
    });
    let profil = resolusi.profil;
    let profilDari = resolusi.dari;
    let ragu = resolusi.ragu;
    let saranProfil = resolusi.saran;
    let ukuranRagu = resolusi.ukuranRagu;
    // AF4 — pengguna memilih profil pada pratinjau: pilihannya menang.
    if (ubah && ubah.profil_id !== undefined) {
      const p = ubah.profil_id ? profilSizeDariId(ubah.profil_id) : null;
      profil = p;
      profilDari = p ? 'manual' : null;
      ragu = false;
      saranProfil = null;
      ukuranRagu = [];
    }
    const aturanGrup = (profil ? aturanDariProfil(profil) : null) ?? aturan;
    const ukuranAturan = Object.keys(aturanGrup.normal).sort((a, b) => Number(a) - Number(b));

    // Ukuran yang dipecah: size eksplisit, atau semua size dalam aturan kodi
    // (produk tanpa ukuran numerik → satu baris tanpa pecahan).
    // AF3 — produk yang SUDAH terklasifikasi (profil positif) ikut daftar size
    // profilnya walau namanya tidak membawa angka ("rulfine mocca 4 kd").
    const numerik = cocok.produk ? [...cocok.produk.sizeSet].filter((s) => /^\d+$/.test(s)) : [];
    const adaSizeHuruf = cocok.produk ? [...cocok.produk.sizeSet].some((s) => !/^\d+$/.test(s)) : false;
    const profilPositif = !!profil && profilDari !== null && profilDari !== 'default';
    const ukuran: (string | null)[] = mentah.size
      ? [mentah.size]
      : cocok.produk && numerik.length === 0 && (adaSizeHuruf || !profilPositif)
        ? [null]
        : ukuranAturan.length > 0
          ? ukuranAturan
          : [null];
    const pecah = ukuran.length > 1 && ukuran[0] !== null;

    // Sebaran pasang per size.
    let kodiNormal = 0;
    let kodiKomp = 0;
    if (mentah.komposisi && (mentah.kodiKomposisi !== null || mentah.kodi !== null)) {
      kodiKomp = mentah.kodiKomposisi ?? mentah.kodi ?? 0;
      if (mentah.kodi !== null) {
        kodiKomp = Math.min(kodiKomp, mentah.kodi);
        kodiNormal = mentah.kodi - kodiKomp;
      }
    } else if (mentah.kodi !== null) {
      kodiNormal = mentah.kodi;
    }
    const totalPasang = Math.round(((kodiNormal + kodiKomp) * aturanGrup.per_kodi + mentah.bebas) * 1000) / 1000;

    const sebaran = new Map<string, number>();
    let sisaPerKodi = aturanGrup.per_kodi; // total jatah per kodi SETELAH komposisi
    const pesanUrai: AksiPesanUrai[] = [];
    if (pecah) {
      for (const s of ukuranAturan) sebaran.set(s, (aturanGrup.normal[s] ?? 0) * kodiNormal);
      if (kodiKomp > 0 && mentah.komposisi) {
        const [db, tp] = mentah.komposisi;
        const komp = new Map(ukuranAturan.map((s) => [s, aturanGrup.normal[s] ?? 0]));
        if (db === tp) {
          catatan.push(`Komposisi db ${db} tp ${tp} pada "${mentah.teks}" sama — diabaikan.`);
        } else {
          const pindah = komp.get(String(tp)) ?? 0;
          komp.set(String(db), (komp.get(String(db)) ?? 0) + pindah);
          komp.set(String(tp), 0);
          if (!ukuranAturan.includes(String(db)) || !ukuranAturan.includes(String(tp))) {
            catatan.push(`Size db ${db} / tp ${tp} di luar aturan (${ukuranAturan.join(', ')}) — periksa hasilnya.`);
          }
          for (const s of ukuranAturan) sebaran.set(s, (sebaran.get(s) ?? 0) + (komp.get(s) ?? 0) * kodiKomp);
          // AF5 — total per kodi setelah komposisi harus tetap = jatah per kodi.
          sisaPerKodi = [...komp.entries()].reduce((n, [s, j]) => (ukuranAturan.includes(s) ? n + j : n), 0);
          if (sisaPerKodi !== aturanGrup.per_kodi) {
            pesanUrai.push({
              teks: `Tp ${tp} menyisakan ${sisaPerKodi} pasang per kodi. Tambahkan Db untuk menyeimbangkan atau ubah Tp.`,
              aksi: 'seimbangkan',
              tp,
            } as AksiPesanUrai);
          }
        }
      }
      if (mentah.bebas > 0) {
        let sisa = mentah.bebas;
        let i = 0;
        while (sisa > 0 && i < ukuranAturan.length * Math.ceil(sisa + 1)) {
          const s = ukuranAturan[i % ukuranAturan.length];
          sebaran.set(s, (sebaran.get(s) ?? 0) + 1);
          sisa -= 1;
          i += 1;
        }
        catatan.push(`${mentah.bebas} pcs di luar kodi dibagi merata ke ukuran ${ukuranAturan.join(', ')}.`);
      }
    }

    grup += 1;
    const idxGrup = grup;
    const rincian: RincianSizeUrai[] = [];
    const alasanProfil: string[] = [];
    const productIds: number[] = [];
    let dibuat = 0;

    for (const size of ukuran) {
      const pasang = !pecah
        ? totalPasang
        : Math.round((sebaran.get(size as string) ?? 0) * 1000) / 1000;
      const per = size === null ? cocok : cocokkanProduk(katalog, qTokens, mentah.warna, size, null);
      // Saran diurutkan: produk ber-size & ber-warna sama didahulukan —
      // supaya pilihan pertama untuk baris "size 39" benar-benar size 39.
      const saranUrut = [...per.saran].sort((a, b) => skorSaran(b, size, mentah.warna) - skorSaran(a, size, mentah.warna));
      const v = per.baris;
      if (v) productIds.push(v.id);
      rincian.push({
        size: size ?? '-',
        pasang,
        kodi: Math.round((pasang / (aturanGrup.normal[String(size)] ?? aturanGrup.per_kodi)) * 1000) / 1000,
        product_id: v?.id ?? null,
      });
      if (pasang <= 0 && pecah && mentah.adaJumlah) continue; // jatah 0 → cukup di pratinjau

      const alasanRow = [...alasan, ...per.alasan];
      if (profil && size !== null && profil.sizes.every((s) => s.size.toLowerCase() !== size.toLowerCase())) {
        // AF5 — pesan per baris + tombol aksi: tawarkan profil lain yang punya size ini.
        const lain = profilUntukSize(size, profil);
        const pesanProfil = lain
          ? `Size ${size} tidak ada di profil ${labelProfil(profil)} (${rentangSize(profil.sizes)}). Barang ini termasuk ${labelProfil(lain)}?`
          : `Size ${size} tidak ada di profil ${labelProfil(profil)} (${rentangSize(profil.sizes)}) — periksa jumlahnya.`;
        alasanRow.push(pesanProfil);
        alasanProfil.push(pesanProfil);
        if (lain) pesanUrai.push({ teks: pesanProfil, aksi: 'pakai_profil', profil_id: lain.id, profil_nama: labelProfil(lain) });
      }
      baris.push({
        teks: mentah.teks,
        produk_teks: mentah.nama,
        warna: mentah.warna,
        size,
        rentang_size: null,
        qty: pasang,
        satuan_teks: null,
        qty_dasar: pasang,
        konversi: mentah.qtyTeks ? `${mentah.qtyTeks} → ${totalPasang} pasang (1 kodi = ${aturanGrup.per_kodi})` : null,
        harga: mentah.harga ?? 0, // harga eksplisit dari teks (@150000 / rp 150.000) menang
        harga_dari_master: false,
        diskon_persen: mentah.diskonPersen,
        diskon: 0, // rupiah dihitung UI setelah harga terisi (persen × qty × harga)
        product_id: v?.id ?? null,
        baris: v ? infoProduk(v) : null,
        unit_id: v?.satuan_dasar_id ?? cocok.produk?.unitId ?? null,
        kecocokan: per.kecocokan,
        saran: saranUrut,
        alasan: alasanRow,
        grup: idxGrup,
        kelompok: mentah.teks,
        jumlah_size: ukuran.length,
      });
      dibuat += 1;
    }

    // Baris jumlah tidak terbaca tetap dibuat (bernilai 0) supaya bisa diedit.
    if (dibuat === 0) {
      const size = ukuran[0];
      const per = size === null ? cocok : cocokkanProduk(katalog, qTokens, mentah.warna, size, null);
      baris.push({
        teks: mentah.teks,
        produk_teks: mentah.nama,
        warna: mentah.warna,
        size,
        rentang_size: null,
        qty: 0,
        satuan_teks: null,
        qty_dasar: 0,
        konversi: null,
        harga: mentah.harga ?? 0,
        harga_dari_master: false,
        diskon_persen: mentah.diskonPersen,
        diskon: 0,
        product_id: per.baris?.id ?? null,
        baris: per.baris ? infoProduk(per.baris) : null,
        unit_id: per.baris?.satuan_dasar_id ?? cocok.produk?.unitId ?? null,
        kecocokan: per.kecocokan,
        saran: [...per.saran].sort((a, b) => skorSaran(b, size, mentah.warna) - skorSaran(a, size, mentah.warna)),
        alasan: [...alasan, ...per.alasan],
        grup: idxGrup,
        kelompok: mentah.teks,
        jumlah_size: ukuran.length,
      });
      rincian.push({ size: size ?? '-', pasang: 0, kodi: 0, product_id: per.baris?.id ?? null });
      dibuat = 1;
    }

    // AF1.6/AF5 — klasifikasi: tanyakan saat ragu, tawarkan saran bila size menunjuk satu profil.
    if (ragu && !saranProfil) {
      const pemilik = ukuranRagu.length ? daftarProfilYangPunyaSize(ukuranRagu[0]) : [];
      const label = [...new Set(pemilik.map(labelProfil))];
      const pesanRagu = label.length
        ? `Kategori barang belum diklasifikasikan. Pilih profil (size ${ukuranRagu.join(', ')} ada di ${label.join(' dan ')}).`
        : 'Kategori barang belum diklasifikasikan. Pilih profil.';
      alasanProfil.push(pesanRagu);
      pesanUrai.push({ teks: pesanRagu, aksi: 'pilih_profil' });
    } else if (saranProfil) {
      const pesanSaran = `Kategori barang belum diklasifikasikan. Saran: Gunakan profil ${labelProfil(saranProfil)} (dari size yang diketik).`;
      alasanProfil.push(pesanSaran);
      pesanUrai.push({ teks: pesanSaran, aksi: 'pakai_profil', profil_id: saranProfil.id, profil_nama: labelProfil(saranProfil) });
    }

    pratinjau.push({
      grup: idxGrup,
      teks: mentah.teks,
      nama: cocok.produk?.nama ?? mentah.nama ?? mentah.teks,
      warna: mentah.warna,
      profil: profil?.nama ?? null,
      profil_dari: profilDari,
      profil_id: profil?.id ?? null,
      profil_kode: profil?.kode ?? null,
      profil_sizes: profil?.sizes ?? [],
      db: mentah.db,
      tp: mentah.tp,
      kodi_normal: kodiNormal,
      kodi_komp: kodiKomp,
      pcs: mentah.bebas,
      sisa_per_kodi: sisaPerKodi,
      seimbang: Math.abs(sisaPerKodi - aturanGrup.per_kodi) < 0.001,
      ragu: ragu && !saranProfil,
      saran_profil: saranProfil ? { id: saranProfil.id, nama: saranProfil.nama } : null,
      pesan: pesanUrai,
      qty_teks: mentah.qtyTeks || (mentah.adaJumlah ? `${totalPasang} pasang` : 'jumlah belum terbaca'),
      total_pasang: totalPasang,
      total_kodi: Math.round((totalPasang / aturanGrup.per_kodi) * 1000) / 1000,
      rincian,
      kecocokan: cocok.kecocokan,
      saran: [...cocok.saran].sort(
        (a, b) => skorSaran(b, ukuran.length === 1 ? ukuran[0] : null, mentah.warna) - skorSaran(a, ukuran.length === 1 ? ukuran[0] : null, mentah.warna),
      ),
      alasan: [...alasan, ...cocok.alasan, ...alasanProfil],
    });
  }

  // 4) harga beli: harga beli terakhir pemasok → harga beli produk → kosong.
  const bekas = hargaTerakhirSupplier(pemasok.supplier_id, [...new Set(productIds(baris))]);
  for (const b of baris) {
    if (!b.product_id) {
      b.alasan = [...b.alasan, 'Baris belum cocok ke master — pilih saran produk atau buat produk baru.'];
      continue;
    }
    if (b.harga > 0) continue; // harga eksplisit dari teks (@/rp/harga …) dipertahankan
    const terakhir = bekas.get(Number(b.product_id));
    if (terakhir !== undefined && terakhir > 0) {
      b.harga = terakhir;
      b.harga_dari_master = false;
    } else if (b.baris && b.baris.harga_beli > 0) {
      b.harga = b.baris.harga_beli;
      b.harga_dari_master = true;
    } else {
      b.harga = 0;
      b.alasan = [...b.alasan, 'Harga beli kosong — wajib diisi sebelum Simpan Draft (PO).'];
    }
  }

  // 5) verifikasi total & pesan bot.
  const hitung = Math.round((pratinjau.reduce((n, p) => n + p.total_pasang, 0) / aturan.per_kodi) * 1000) / 1000;
  const cek: CekTotalUrai = {
    ada: klaim !== null,
    klaim,
    hitung,
    selisih: klaim === null ? 0 : Math.round((hitung - klaim) * 1000) / 1000,
    ok: klaim === null ? true : Math.abs(hitung - klaim) < 0.01,
  };
  if (!cek.ok) {
    catatan.push(`Total ditulis ${klaim} kodi tetapi hasil hitung ${hitung} kodi (selisih ${cek.selisih}).`);
  }

  const pesan_bot = susunPesanBotBaris(pemasok, tanggal, pratinjau, cek, aturan, catatan);
  return { pemasok, baris, catatan, pesan_bot, gaya: 'baris', tanggal, pratinjau, cek, aturan };
}

function productIds(baris: BarisUrai[]): number[] {
  return baris.map((b) => Number(b.product_id)).filter((n) => Number.isFinite(n) && n > 0);
}

function susunPesanBotBaris(
  pemasok: PemasokUrai,
  tanggal: string | null,
  pratinjau: PratinjauUrai[],
  cek: CekTotalUrai,
  aturan: AturanKodi,
  catatan: string[],
): string {
  const garis: string[] = [];
  if (pemasok.cocok && pemasok.teks) garis.push(`Pemasok: ${pemasok.teks}`);
  else if (pemasok.teks) {
    garis.push(
      `Pemasok "${pemasok.teks}" belum ada di master${pemasok.saran.length ? ` — saran: ${pemasok.saran.map((s) => s.nama).join(', ')}` : ''}.`,
    );
  } else garis.push('Pemasok tidak terbaca — pilih di form.');

  if (tanggal) {
    const [y, m, d] = tanggal.split('-').map(Number);
    const hari = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'][new Date(y, m - 1, d).getDay()];
    garis.push(`Tanggal: ${hari}, ${d} ${BULAN_PANJANG[m]} ${y}`);
  }

  const profilDipakai = [...new Set(pratinjau.map((p) => p.profil).filter((x): x is string => !!x))];
  if (profilDipakai.length > 0) garis.push(`Profil size: ${profilDipakai.join(' · ')}`);

  for (const p of pratinjau) {
    const bersih = p.alasan.length === 0 && p.kecocokan === 'yakin';
    const rincian = p.rincian.map((r) => `${r.size}: ${r.pasang} (${r.kodi} kd)`).join(' · ');
    garis.push(
      `${bersih ? '✔' : '⚠'} ${p.nama}${p.warna ? ` ${p.warna}` : ''} — ${p.qty_teks} = ${p.total_pasang} pasang (${p.total_kodi} kodi)${rincian ? ` · ${rincian}` : ''}`,
    );
    for (const a of p.alasan) garis.push(`   • ${a}`);
  }
  garis.push(`Total hitung: ${cek.hitung} kodi (${cek.hitung * aturan.per_kodi} pasang).`);
  if (cek.ada) {
    garis.push(
      cek.ok
        ? `✔ Cocok dengan baris "Total = ${cek.klaim} kd".`
        : `⚠ Baris "Total = ${cek.klaim} kd" tidak cocok (selisih ${cek.selisih} kodi) — periksa sebelum simpan.`,
    );
  }
  for (const c of catatan) garis.push(`• ${c}`);
  if (pratinjau.length > 0 && !pratinjau.some((p) => p.alasan.length || p.kecocokan !== 'yakin')) {
    garis.push('Semua baris terbaca bersih — tinjau pratinjau lalu Simpan Draft (PO).');
  } else if (pratinjau.length > 0) {
    garis.push('Baris bertanda ⚠ perlu ditinjau (pilih saran / buat produk baru / isi harga) sebelum disimpan.');
  }
  return garis.join('\n');
}

function susunPesanBot(pemasok: PemasokUrai, baris: BarisUrai[], catatan: string[]): string {
  const garis: string[] = [];
  if (pemasok.cocok && pemasok.teks) garis.push(`Pemasok: ${pemasok.teks}`);
  else if (pemasok.teks) garis.push(`Pemasok "${pemasok.teks}" belum cocok — pilih dari daftar.`);
  else garis.push('Pemasok tidak terbaca — pilih di form.');

  if (baris.length === 0) {
    garis.push('Tidak ada item yang terbaca dari teks.');
  }
  baris.forEach((b, i) => {
    const siap = b.kecocokan === 'yakin' && b.alasan.length === 0;
    const nama = b.baris ? `${b.baris.sku} — ${b.baris.produk}` : b.produk_teks || b.teks || '(tanpa produk)';
    const jumlah = b.konversi ? String(b.qty_dasar) : `${b.qty_dasar}${b.satuan_teks ? ` ${b.satuan_teks}` : ''}`;
    const potong = b.diskon_persen !== null ? ` · diskon ${b.diskon_persen}%` : b.diskon > 0 ? ` · diskon Rp ${b.diskon.toLocaleString('id-ID')}` : '';
    const konv = b.konversi ? ` · ${b.konversi}` : '';
    garis.push(
      `${siap ? '✔' : '⚠'} ${i + 1}. ${nama} — ${jumlah} × Rp ${b.harga.toLocaleString('id-ID')}${potong}${konv}`,
    );
    for (const a of b.alasan) garis.push(`   • ${a}`);
  });
  for (const c of catatan) garis.push(`• ${c}`);
  if (baris.length > 0 && baris.every((b) => b.kecocokan === 'yakin' && b.alasan.length === 0)) {
    garis.push('Semua baris terbaca bersih — tinjau lalu Konfirmasi untuk membuat draft.');
  } else if (baris.length > 0) {
    garis.push('Baris bertanda ⚠ perlu ditinjau (pilih saran / koreksi isian) sebelum konfirmasi.');
  }
  return garis.join('\n');
}
