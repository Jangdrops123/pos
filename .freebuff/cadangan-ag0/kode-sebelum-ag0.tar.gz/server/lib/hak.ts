// ============================================================================
// Pemeriksaan hak akses MODUL (Tahap 2) di sisi server/API.
//
// Satu middleware pusat memetakan setiap rute /api → (modul, aksi) sesuai
// matriks Hak Akses (baris = modul, kolom = aksi) lalu menolak bila peran
// efektif tidak memiliki izinnya. Penyembunyian menu di sidebar hanyalah
// lapisan tampilan — server selalu memeriksa ulang.
//
// Selain matriks, middleware ini menjalankan:
//   * Hak khusus "hapus/batalkan transaksi" pada jalur destruktif modul
//     transaksi (void, batal, hapus).
//   * Pembatasan data peran: bila peran dibatasi ke toko/gudang tertentu,
//     parameter toko/gudang apa pun di LUAR cakupan ditolak (403).
// ============================================================================

import type { Request, RequestHandler } from 'express';
import { all } from '../db.ts';
import type { Konteks } from './auth.ts';

/** Metode HTTP → aksi bawaan matriks. */
const AKSI_METODE: Record<string, string> = {
  GET: 'lihat',
  POST: 'tambah',
  PUT: 'ubah',
  PATCH: 'ubah',
  DELETE: 'hapus',
};

/** Modul yang perubahan/hapus datanya termasuk "hapus/batalkan transaksi". */
const MODUL_TRANSAKSI = new Set([
  'penjualan',
  'pos',
  'pembelian',
  'stok',
  'opname',
  'persediaan-sub',
  'dokumen',
  'akuntansi',
]);

/** Label kolom matriks (untuk pesan galat yang jelas). */
const LABEL_AKSI: Record<string, string> = {
  lihat: 'Lihat',
  tambah: 'Tambah',
  ubah: 'Ubah',
  hapus: 'Hapus',
  cetak: 'Cetak',
  ekspor: 'Ekspor',
  impor: 'Impor',
  sahkan: 'Batalkan/Sahkan',
};

const LABEL_MODUL: Record<string, string> = {
  penjualan: 'Penjualan',
  pos: 'POS',
  pembelian: 'Pembelian',
  stok: 'Stok',
  opname: 'Opname',
  'persediaan-sub': 'Persediaan Sub',
  dokumen: 'Daftar Dokumen',
  akuntansi: 'Akuntansi',
  laporan: 'Laporan',
  master: 'Master Data',
  pengaturan: 'Pengaturan',
  'proses-tahunan': 'Proses Tahunan',
};

export interface KeputusanModul {
  /** Diizinkan bila SATU SAJA modul ini memuat aksinya (OR). */
  menus: string[];
  aksi: string;
  /** Jalur destruktif (void/batal/hapus) — ikut hak khusus transaksi. */
  destruktif: boolean;
}

/** Aksi matriks dari jalur + metode (dipertajam oleh kata kunci jalur). */
export function aksiDariRute(path: string, method: string): string {
  const p = path.toLowerCase();
  if (/(cetak|print)/.test(p)) return 'cetak';
  if (/ekspor/.test(p)) return 'ekspor';
  if (/impor/.test(p)) return 'impor';
  if (/(void|batal|sahkan|kirim|terima)/.test(p)) return 'sahkan';
  if (/(massal|set-aktif|nonaktif|aktifkan|ubah)/.test(p)) return method === 'DELETE' ? 'hapus' : 'ubah';
  if (/hapus/.test(p)) return 'hapus';
  return AKSI_METODE[method] ?? 'lihat';
}

/** Petakan jalur /api (tanpa prefix /api) → modul matriks; null = di luar matriks. */
export function modulDariRute(path: string, method: string): KeputusanModul | null {
  const p = path.toLowerCase();
  const aksi = aksiDariRute(path, method);
  const destruktif = /(void|batal|hapus)/.test(p);

  // --- POS & Penjualan: /pos/* dipecah ------------------------------------
  if (p === '/pos' || p.startsWith('/pos/')) {
    const sisa = p.slice('/pos'.length);
    const baca = method === 'GET';
    if (/^\/(sales|returns|receivables)/.test(sisa)) {
      // Riwayat/retur/piutang = modul Penjualan; aksi tulis/hapus/destruktif
      // boleh dari POS (kasir) ATAU Penjualan (operator riwayat).
      return baca
        ? { menus: ['penjualan'], aksi, destruktif }
        : { menus: ['penjualan', 'pos'], aksi, destruktif };
    }
    return { menus: ['pos'], aksi, destruktif };
  }

  const PETA: [string, string[] | null][] = [
    ['/master', ['master']],
    ['/stock', ['stok']],
    ['/opname', ['opname']],
    ['/persediaan', ['persediaan-sub']],
    ['/pembelian', ['pembelian']],
    ['/faktur', ['dokumen']],
    ['/akuntansi', ['akuntansi']],
    ['/laporan', ['laporan']],
    ['/proses-tahunan', ['proses-tahunan']],
    ['/struk', ['pos', 'pengaturan']],
    ['/profil-size', ['pengaturan']],
    // GET Pengaturan: guard per tab (izinTab) sudah menentukan; jalur tulis
    // tetap harus punya izin modul Pengaturan.
    ['/pengaturan', method === 'GET' ? null : ['pengaturan']],
    // Di luar matriks (tetap wajib login): dashboard, tampilan, auth, meta.
    ['/dashboard', null],
    ['/tampilan', null],
    ['/auth', null],
    ['/health', null],
    ['/meta', null],
  ];

  for (const [pre, menus] of PETA) {
    if (p === pre || p.startsWith(`${pre}/`)) {
      return menus ? { menus, aksi, destruktif } : null;
    }
  }
  // Rute baru yang belum dikenal: TIDAK dihukum (tetap wajib login),
  // agar modul mendatang tidak tiba-tiba terkunci.
  return null;
}

/** Boleh sebuah modul+aksi? (dipakai handler spesifik) */
export function bolehModul(req: Request, menu: string, aksi: string): boolean {
  const k = req.konteks;
  if (!k) return false;
  if (k.admin) return true;
  return (k.hak[menu] ?? []).includes(aksi);
}

function pesanTolak(k: KeputusanModul, konteks: Konteks): string {
  const menus = k.menus.map((m) => LABEL_MODUL[m] ?? m).join(' / ');
  const aksi = LABEL_AKSI[k.aksi] ?? k.aksi;
  return `Anda tidak punya akses: peran ${konteks.roleNama} tidak memiliki izin "${aksi}" pada modul ${menus}. Minta Admin mengubah Hak Akses (Pengaturan ▸ Halaman Awal & Peran).`;
}

/** Validasi parameter toko/gudang terhadap cakupan peran. */
function cekCakupan(req: Request, konteks: Konteks): string | null {
  const cakupan = konteks.cakupanToko;
  if (cakupan === null || cakupan === undefined) return null;
  if (cakupan.length === 0) {
    return 'Peran ini tidak memiliki cakupan toko/gudang — hubungi Admin.';
  }

  const nilai: string[] = [];
  for (const kunci of ['toko', 'toko_kode', 'store', 'kode_toko']) {
    const q = req.query[kunci];
    if (q !== undefined && q !== null && String(q) !== '' && String(q) !== 'semua') nilai.push(String(q).trim());
    const b = (req.body as Record<string, unknown> | undefined)?.[kunci];
    if (b !== undefined && b !== null && String(b) !== '' && String(b) !== 'semua') nilai.push(String(b).trim());
  }
  for (const n of nilai) {
    if (!cakupan.includes(n)) return `Peran ini hanya dibatasi ke toko/gudang: ${cakupan.join(', ')}.`;
  }

  // Id gudang (warehouse_id/gudang_id) dinormalisasi ke daftar gudang cakupan.
  const idMinta: number[] = [];
  for (const kunci of ['gudang_id', 'warehouse_id']) {
    const q = req.query[kunci];
    if (q !== undefined && q !== '' && q !== 'semua') idMinta.push(Number(q));
    const b = (req.body as Record<string, unknown> | undefined)?.[kunci];
    if (b !== undefined && b !== '' && b !== 'semua') idMinta.push(Number(b));
  }
  if (idMinta.some((x) => !Number.isFinite(x))) return 'Pilihan toko/gudang tidak valid.';
  if (idMinta.length > 0) {
    const placeholder = cakupan.map(() => '?').join(',');
    const bolehId = new Set(
      all<{ warehouse_id: number | null }>(
        `SELECT warehouse_id FROM stores WHERE kode IN (${placeholder})`,
        ...cakupan,
      ).map((r) => r.warehouse_id),
    );    if (idMinta.some((x) => !bolehId.has(x))) {
      return `Peran ini hanya dibatasi ke toko/gudang: ${cakupan.join(', ')}.`;
    }
  }
  return null;
}

/**
 * Sembunyikan harga beli/HPP dari balasan JSON bila peran tidak memiliki
 * hak khusus "Lihat harga beli/HPP" (Admin selalu melihat).
 */
function sembunyikanHpp(b: unknown): unknown {
  if (Array.isArray(b)) return b.map(sembunyikanHpp);
  if (b && typeof b === 'object') {
    const keluar: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(b as Record<string, unknown>)) {
      if ((k === 'harga_beli' || k === 'hpp') && typeof v === 'number') keluar[k] = null;
      else keluar[k] = sembunyikanHpp(v);
    }
    return keluar;
  }
  return b;
}

/**
 * Middleware: modul + aksi + cakupan. Dijalankan SETELAH `wajibLogin`.
 * Rute di luar matriks (null) tetap lolos — penjaga tersendiri (izinTab,
 * wajibAdmin, dll.) tetap berlaku di rutenya masing-masing.
 */
export const wajibModul: RequestHandler = (req, res, next) => {
  const konteks = req.konteks;
  if (!konteks) return next();

  const keputusan = modulDariRute(req.path, req.method);
  if (keputusan) {
    const lolos = keputusan.menus.some((m) => (konteks.hak[m] ?? []).includes(keputusan.aksi));
    if (!lolos) {
      res.status(403).json({ ok: false, pesan: pesanTolak(keputusan, konteks), kode: 'akses' });
      return;
    }
    // Hak khusus: hapus/batalkan transaksi (Admin selalu lolos).
    if (
      keputusan.destruktif &&
      !konteks.admin &&
      !konteks.khusus.hapus_transaksi &&
      keputusan.menus.some((m) => MODUL_TRANSAKSI.has(m))
    ) {
      res.status(403).json({
        ok: false,
        pesan: 'Peran ini tidak memiliki hak "Hapus/batalkan transaksi". Minta Admin mengubah Hak Khusus.',
        kode: 'hak-khusus',
      });
      return;
    }
  }

  const halanganCakupan = cekCakupan(req, konteks);
  if (halanganCakupan) {
    res.status(403).json({ ok: false, pesan: halanganCakupan, kode: 'cakupan' });
    return;
  }

  // Hak Khusus "Lihat harga beli/HPP" — balasan JSON disaring di sini
  // sehingga berlaku untuk seluruh modul tanpa menyentuh kodenya.
  if (!konteks.admin && !konteks.khusus.lihat_hpp) {
    const asli = res.json.bind(res);
    res.json = ((body: unknown) => asli(sembunyikanHpp(body))) as typeof res.json;
  }

  next();
};
