// ============================================================================
// Inti modul Log In (Tahap 1) — hash password, sesi cookie httpOnly, konteks
// pengguna per permintaan, dan middleware `wajibLogin`.
//
// Kebijakan:
//   * Password selalu di-hash bcrypt ($2b$10$…); teks biasa tidak pernah
//     disimpan maupun dikembalikan ke klien.
//   * 5x salah = terkunci (angka & durasi dari Pengaturan ▸ Keamanan).
//   * Sesi berakhir otomatis bila tidak aktif melewati `sesi_menit`
//     (dapat diatur Admin) — dihitung ulang tiap permintaan.
//   * "Ingat saya" membuat cookie & sesi berlaku 30 hari; tanpa centang,
//     cookie hanya berlaku selama jendela peramban tetap terbuka.
// ============================================================================

import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import type { Request, RequestHandler, Response } from 'express';
import { all, get, getSettings, run } from '../db.ts';
import { tolak } from './http.ts';

export const NAMA_KUKI = 'ns_sesi';
const HARGA_BCRYPT = 10;
const HARI_INGAT = 30;
/** Password awal akun Admin yang dibuat otomatis saat pertama dijalankan. */
export const SANDI_ADMIN_AWAL = 'admin123';

declare global {
  namespace Express {
    interface Request {
      konteks?: Konteks;
    }
  }
}

export type KunciPeran = 'admin' | 'manajer' | 'akuntan' | 'kasir' | 'gudang';

export const SEMUA_AKSI = [
  'lihat',
  'tambah',
  'ubah',
  'hapus',
  'cetak',
  'ekspor',
  'impor',
  'sahkan',
] as const;

export interface HakKhusus {
  lihat_hpp: boolean;
  ubah_harga_kasir: boolean;
  diskon_maks: number;
  hapus_transaksi: boolean;
  proses_tahunan: boolean;
}

export interface Konteks {
  userId: number;
  nama: string;
  username: string;
  email: string | null;
  wa: string | null;
  roleNama: string;
  /** id peran efektif (dapat berbeda dari peran asli bila ada override x-peran). */
  roleId: number;
  peranKunci: KunciPeran;
  admin: boolean;
  adminUtama: boolean;
  wajibGanti: boolean;
  sesiId: number;
  token: string;
  /** Matriks modul → daftar aksi yang diizinkan untuk peran efektif. */
  hak: Record<string, string[]>;
  khusus: HakKhusus;
  cakupanToko: string[] | null;
  /**
   * Identitas & hak PEMILIK SESI apa adanya (tanpa override `x-peran`).
   * Payload /auth/masuk & /auth/sesi memakai ini: header `x-peran` dari
   * klien (bisa sisa pengguna sebelumnya saat ganti akun di peramban yang
   * sama) tidak boleh mengubah "siapa yang masuk" — kalau tidak, peran
   * lokal klien (peranAktif) mewarisi peran akun sebelumnya dan seluruh
   * permintaan berikutnya dikirim dengan peran yang salah.
   */
  asli: {
    roleNama: string;
    peranKunci: KunciPeran;
    admin: boolean;
    hak: Record<string, string[]>;
    khusus: HakKhusus;
    cakupanToko: string[] | null;
  };
}

/* ------------------------------- hash ---------------------------------- */

export function hashSandi(sandi: string): string {
  return bcrypt.hashSync(sandi, HARGA_BCRYPT);
}

export function cocokSandi(sandi: string, hash: string | null | undefined): boolean {
  if (!hash || hash === '!' || !hash.startsWith('$2')) return false;
  try {
    return bcrypt.compareSync(sandi, hash);
  } catch {
    return false;
  }
}

/** Hash SHA-256 (hex) — untuk token reset & kode pemulihan (bukan password). */
export function hashToken(teks: string): string {
  return crypto.createHash('sha256').update(teks).digest('hex');
}

/* --------------------------- generator acak ----------------------------- */

/** Alfabet tanpa karakter menyesatkan (0/O, 1/l/I). */
const ALFA = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
const ALFA_BESAR = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function acakTeks(n: number, alfabet: string): string {
  const b = crypto.randomBytes(n);
  let s = '';
  for (let i = 0; i < n; i++) s += alfabet[b[i] % alfabet.length];
  return s;
}

/** Password acak 12 karakter — selalu memuat huruf besar, kecil, dan angka. */
export function sandiAcak(): string {
  const besar = acakTeks(1, 'ABCDEFGHJKLMNPQRSTUVWXYZ');
  const kecil = acakTeks(1, 'abcdefghijkmnpqrstuvwxyz');
  const angka = acakTeks(1, '23456789');
  const sisa = acakTeks(9, ALFA);
  const campur = `${besar}${kecil}${angka}${sisa}`.split('');
  // Acak urutan tanpa modul kripto khusus (cukup untuk password sementara).
  for (let i = campur.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1);
    [campur[i], campur[j]] = [campur[j], campur[i]];
  }
  return campur.join('');
}

/** Kode pemulihan Admin: 4 grup × 4 karakter (ABCDEFGH…23456789). */
export function kodePemulihanAcak(): string {
  return [0, 1, 2, 3].map(() => acakTeks(4, ALFA_BESAR)).join('-');
}

export interface KebijakanSandi {
  panjang: number;
  hurufAngka: boolean;
  simbol: boolean;
}

export function kebijakanSandi(): KebijakanSandi {
  const s = getSettings();
  const panjang = Number(s.sandi_min_panjang);
  return {
    panjang: Number.isFinite(panjang) && panjang >= 6 ? panjang : 8,
    hurufAngka: s.sandi_wajib_huruf_angka !== 'false',
    simbol: s.sandi_wajib_simbol === 'true',
  };
}

/** Validasi password baru; null = lolos. */
export function validasiSandiBaru(sandi: string): string | null {
  const k = kebijakanSandi();
  if (typeof sandi !== 'string' || sandi.length < k.panjang) {
    return `Password minimal ${k.panjang} karakter.`;
  }
  if (sandi.length > 200) return 'Password maksimal 200 karakter.';
  if (k.hurufAngka && !(/[A-Za-z]/.test(sandi) && /\d/.test(sandi))) {
    return 'Password harus memuat huruf dan angka.';
  }
  if (k.simbol && !/[^\w\s]/.test(sandi)) return 'Password harus memuat simbol.';
  if (sandi.trim() !== sandi) return 'Password tidak boleh diawali/akhir spasi.';
  return null;
}

/** Kekuatan password untuk indikator UI (bukan penolakan). */
export function skorSandi(sandi: string): 0 | 1 | 2 | 3 {
  if (!sandi) return 0;
  const panjangOk = sandi.length >= 8;
  const campuran = /[A-Za-z]/.test(sandi) && /\d/.test(sandi);
  const kuat = sandi.length >= 12 && campuran && /[^\w\s]/.test(sandi);
  if (kuat) return 3;
  if (panjangOk && campuran) return 2;
  if (sandi.length >= 6) return 1;
  return 0;
}

/* ------------------------------ waktu ---------------------------------- */
/** Waktu sekarang format SQL SQLite (UTC, spasi) — konsisten dengan DEFAULT. */
export function waktuSql(d: Date = new Date()): string {
  return d.toISOString().replace('T', ' ').replace('Z', '');
}

/** Ubah format SQL menjadi milidetik (menangani format lama ber-T/Z). */
export function msDariSql(s: string | null | undefined): number {
  if (!s) return Number.NaN;
  const t = s.includes('T') ? s : s.replace(' ', 'T');
  return Date.parse(t.endsWith('Z') ? t : `${t}Z`);
}

function menitSesi(): number {
  const v = Number(getSettings()['sesi_menit']);
  return Number.isFinite(v) && v > 0 ? v : 480;
}

/* ------------------------------- kuki ---------------------------------- */

export function pasangKuki(res: Response, token: string, ingat: boolean): void {
  const bagian = [`${NAMA_KUKI}=${encodeURIComponent(token)}`, 'Path=/', 'HttpOnly', 'SameSite=Lax'];
  if (ingat) bagian.push(`Expires=${new Date(Date.now() + HARI_INGAT * 86_400_000).toUTCString()}`);
  res.setHeader('Set-Cookie', bagian.join('; '));
}

export function lepasKuki(res: Response): void {
  res.setHeader('Set-Cookie', `${NAMA_KUKI}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
}

function bacaToken(req: Request): string | null {
  const kuki = req.headers.cookie;
  if (kuki) {
    for (const bagian of kuki.split(';')) {
      const i = bagian.indexOf('=');
      if (i < 0) continue;
      if (bagian.slice(0, i).trim() === NAMA_KUKI) return decodeURIComponent(bagian.slice(i + 1).trim());
    }
  }
  // Cadangan untuk skrip/uji: header `x-sesi` memuat token yang sama.
  const h = req.headers['x-sesi'];
  return typeof h === 'string' && h ? h : null;
}

/* ------------------------------- peran --------------------------------- */

const PERSIS_KEY: [string, KunciPeran][] = [
  ['administrator', 'admin'],
  ['admin', 'admin'],
  ['owner', 'admin'],
  ['manajer', 'manajer'],
  ['manager', 'manajer'],
  ['akuntan', 'akuntan'],
  ['kasir', 'kasir'],
  ['gudang', 'gudang'],
  ['staf gudang', 'gudang'],
  ['warehouse', 'gudang'],
];

/** Nama peran → kunci klien. Peran buatan → 'manajer' (matriks tetap penentu). */
export function kunciDariNamaPeran(nama: string): KunciPeran {
  const n = nama.toLowerCase().trim();
  for (const [pola, key] of PERSIS_KEY) if (n === pola) return key;
  for (const [pola, key] of PERSIS_KEY) if (n.includes(pola)) return key;
  return 'manajer';
}

/** Nama peran bawaan → nama peran di database (override header x-peran). */
const NAMA_ROLE_HEADER: Record<string, string> = {
  admin: 'Administrator',
  owner: 'Administrator',
  administrator: 'Administrator',
  manajer: 'Manajer',
  manager: 'Manajer',
  akuntan: 'Akuntan',
  kasir: 'Kasir',
  gudang: 'Gudang',
};

const NAMA_ADMIN = new Set(['administrator', 'admin', 'owner']);

export function adalahPeranAdminNama(nama: string): boolean {
  return NAMA_ADMIN.has(nama.toLowerCase().trim());
}

/* ------------------------------- konteks -------------------------------- */

interface BarisSesi {
  id: number;
  token: string;
  user_id: number;
  terakhir_aktif: string;
  kadaluarsa: string | null;
  nama: string;
  username: string;
  email: string | null;
  wa: string | null;
  aktif: number;
  wajib_ganti: number;
  role_id: number;
  role_nama: string;
  cakupan_user: string | null;
  cakupan_role: string | null;
}

/**
 * Bangun konteks dari token sesi. Mengembalikan null bila sesi tidak ada,
 * kedaluwarsa, idle-timeout, atau akun sudah nonaktif — sesi bermasalah
 * langsung dihapus agar tidak dipakai ulang.
 *
 * Diekspor agar rute /auth/masuk bisa membangun payload sesi langsung
 * setelah token baru dibuat (sebelum request berikutnya).
 */
export function konteksDariToken(req: Request, res: Response, token: string): Konteks | null {
  const baris = get<BarisSesi>(
    `SELECT s.id, s.token, s.user_id, s.terakhir_aktif, s.kadaluarsa,
            u.nama, u.username, u.email, u.wa, u.aktif, u.wajib_ganti,
            u.role_id, u.cakupan_toko AS cakupan_user,
            r.nama AS role_nama, r.cakupan_toko AS cakupan_role
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       JOIN roles r ON r.id = u.role_id
      WHERE s.token = ?`,
    token,
  );
  if (!baris) return null;

  const buang = () => {
    run('DELETE FROM sessions WHERE token = ?', token);
    lepasKuki(res);
  };

  const kini = Date.now();
  if (baris.kadaluarsa && msDariSql(baris.kadaluarsa) < kini) {
    buang();
    return null;
  }
  const batas = menitSesi() * 60_000;
  if (kini - msDariSql(baris.terakhir_aktif) > batas) {
    buang();
    return null;
  }
  if (!baris.aktif) {
    buang();
    return null;
  }
  // Perbarui aktivitas (hemat tulis: cukup bila jeda > 30 detik).
  if (kini - msDariSql(baris.terakhir_aktif) > 30_000) {
    run('UPDATE sessions SET terakhir_aktif = ? WHERE id = ?', waktuSql(), baris.id);
  }

  const admin = adalahPeranAdminNama(baris.role_nama);
  // Override `x-peran` HANYA dari sesi Admin (dipakai skrip uji & simulasi peran);
  // sesi non-Admin tidak bisa menaikkan/menurunkan peran lewat header.
  const headerPeran = String(req.headers['x-peran'] ?? '').toLowerCase().trim();
  let roleNama = baris.role_nama;
  let roleId = baris.role_id;
  if (admin && headerPeran && NAMA_ROLE_HEADER[headerPeran]) {
    // lower(?) di kedua sisi — pembanding literal 'Manajer' tidak cocok dengan
    // lower(nama) tanpa di-lower-kan (matriks izin per peran jadi tidak teruji).
    const roleHeader = get<{ id: number; nama: string }>(
      'SELECT id, nama FROM roles WHERE lower(nama) = lower(?)',
      NAMA_ROLE_HEADER[headerPeran],
    );
    if (roleHeader) {
      roleId = roleHeader.id;
      roleNama = roleHeader.nama;
    }
  }

  const adminEfektif = admin && roleId === baris.role_id;
  const cakupan = irisanCakupan(baris.cakupan_user, baris.cakupan_role);
  return {
    userId: baris.user_id,
    nama: baris.nama,
    username: baris.username,
    email: baris.email,
    wa: baris.wa,
    roleNama,
    peranKunci: kunciDariNamaPeran(roleNama),
    admin: adminEfektif,
    adminUtama: admin && baris.username.toLowerCase() === 'admin',
    wajibGanti: baris.wajib_ganti === 1,
    sesiId: baris.id,
    token,
    hak: bacaHak(roleId, adminEfektif),
    roleId,
    khusus: bacaHakKhusus(roleId, adminEfektif),
    cakupanToko: cakupan,
    // Pemilik sesi apa adanya — untuk payload identitas (/masuk, /sesi).
    asli: {
      roleNama: baris.role_nama,
      peranKunci: kunciDariNamaPeran(baris.role_nama),
      admin,
      hak: bacaHak(baris.role_id, admin),
      khusus: bacaHakKhusus(baris.role_id, admin),
      cakupanToko: cakupan,
    },
  };
}

/**
 * Cakupan efektif = irisan cakupan pengguna dan peran (null = tanpa
 * pembatasan; [] = tidak boleh memilih toko mana pun).
 */
function parseCakupan(s: string | null): string[] | null {
  if (!s) return null;
  try {
    const v = JSON.parse(s) as unknown;
    return Array.isArray(v) ? v.map((x) => String(x)) : null;
  } catch {
    return null;
  }
}

export function irisanCakupan(a: string | null, b: string | null): string[] | null {
  const pa = parseCakupan(a);
  const pb = parseCakupan(b);
  if (pa === null) return pb;
  if (pb === null) return pa;
  return pa.filter((x) => pb.includes(x));
}

/* ------------------------- matriks hak akses ---------------------------- */

export function daftarModul(): string[] {
  return [
    'penjualan',
    'pos',
    'pembelian',
    'stok',
    'opname',
    'persediaan-sub',
    'dokumen',
    'akuntansi',
    'laporan',
    'master',
    'pengaturan',
    'proses-tahunan',
  ];
}

export function bacaHak(roleId: number, admin: boolean): Record<string, string[]> {
  const semua = Object.fromEntries(daftarModul().map((m) => [m, [...SEMUA_AKSI]]));
  if (admin) return semua;
  const rows = all<{ menu: string; aksi: string }>(
    'SELECT menu, aksi FROM role_permissions WHERE role_id = ?',
    roleId,
  );
  const keluar: Record<string, string[]> = {};
  for (const m of daftarModul()) keluar[m] = [];
  for (const r of rows) {
    if (!keluar[r.menu]) keluar[r.menu] = [];
    if (!keluar[r.menu].includes(r.aksi)) keluar[r.menu].push(r.aksi);
  }
  return keluar;
}

export function bacaHakKhusus(roleId: number, admin: boolean): HakKhusus {
  if (admin) {
    return { lihat_hpp: true, ubah_harga_kasir: true, diskon_maks: 100, hapus_transaksi: true, proses_tahunan: true };
  }
  const r = get<{
    lihat_hpp: number; ubah_harga_kasir: number; diskon_maks: number;
    hapus_transaksi: number; proses_tahunan: number;
  }>('SELECT lihat_hpp, ubah_harga_kasir, diskon_maks, hapus_transaksi, proses_tahunan FROM role_hak_khusus WHERE role_id = ?', roleId);
  if (!r) {
    // Peran buatan tanpa baris → default ketat (Admin menyalakan per izin).
    return { lihat_hpp: false, ubah_harga_kasir: false, diskon_maks: 0, hapus_transaksi: false, proses_tahunan: false };
  }
  return {
    lihat_hpp: r.lihat_hpp === 1,
    ubah_harga_kasir: r.ubah_harga_kasir === 1,
    diskon_maks: Number(r.diskon_maks) || 0,
    hapus_transaksi: r.hapus_transaksi === 1,
    proses_tahunan: r.proses_tahunan === 1,
  };
}

/* -------------------------- endpoint sesi/autorisasi -------------------- */

const PUBLIK = new Set([
  '/health',
  '/meta',
  '/auth/info',
  '/auth/masuk',
  '/auth/lupa',
  '/auth/lupa/kanal',
  '/auth/kirim-ulang',
  '/auth/reset',
  '/auth/pulihkan',
]);

/** Wajib sesi login untuk seluruh /api kecuali endpoint publik. */
export const wajibLogin: RequestHandler = (req, res, next) => {
  if (PUBLIK.has(req.path)) return next();
  const token = bacaToken(req);
  const konteks = token ? konteksDariToken(req, res, token) : null;
  if (!konteks) {
    res.status(401).json({ ok: false, pesan: 'Anda belum masuk atau sesi sudah berakhir. Silakan masuk kembali.' });
    return;
  }
  req.konteks = konteks;
  next();
};

/** Ambil konteks; melempar 401 bila tidak ada (dipakai handler API). */
export function konteksWajib(req: Request): Konteks {
  if (!req.konteks) throw tolak(401, 'Sesi berakhir. Silakan masuk kembali.');
  return req.konteks;
}

/* ------------------------------ sesi CRUD ------------------------------ */

export function buatSesi(userId: number, ops: { ingat: boolean; perangkat: string; ip: string }): { token: string; id: number } {
  // Bersihkan sesi kedaluwarsa milik pengguna ini agar tidak menumpuk.
  run('DELETE FROM sessions WHERE kadaluarsa IS NOT NULL AND kadaluarsa < ?', waktuSql());
  const token = crypto.randomBytes(32).toString('base64url');
  const res = run(
    `INSERT INTO sessions (token, user_id, perangkat, ip, kadaluarsa, diingat, terakhir_aktif)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    token,
    userId,
    ops.perangkat,
    ops.ip,
    ops.ingat ? waktuSql(new Date(Date.now() + HARI_INGAT * 86_400_000)) : null,
    ops.ingat ? 1 : 0,
    waktuSql(),
  );
  return { token, id: res.lastInsertRowid as number };
}

export function hapusSesi(token: string): void {
  run('DELETE FROM sessions WHERE token = ?', token);
}

export function hapusSesiPengguna(userId: number, kecualiToken?: string): number {
  const r = kecualiToken
    ? run('DELETE FROM sessions WHERE user_id = ? AND token <> ?', userId, kecualiToken)
    : run('DELETE FROM sessions WHERE user_id = ?', userId);
  return r.changes;
}

/** Perangkat singkat dari User-Agent (untuk daftar sesi di Keamanan). */
export function perangkatDariUA(ua: string | undefined): string {
  if (!ua) return 'Perangkat tidak dikenal';
  const browser = /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /Firefox\//.test(ua) ? 'Firefox' : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'Peramban';
  const os = /Windows/.test(ua) ? 'Windows' : /Mac OS/.test(ua) ? 'macOS' : /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iOS' : /Linux/.test(ua) ? 'Linux' : '';
  return os ? `${browser} · ${os}` : browser;
}

export function ipDariReq(req: Request): string {
  return (req.ip ?? req.socket.remoteAddress ?? '').replace('::ffff:', '') || '-';
}

/* --------------------------- akun Admin awal ---------------------------- */

/**
 * Dijalankan sekali saat server naik: memastikan ada akun `admin`
 * (dibuat otomatis pada jalannya pertama) dengan password awal bcrypt dan
 * tanda "wajib ganti password saat login pertama".
 */
export function pastikanAdminAwal(): void {
  const role = get<{ id: number }>("SELECT id FROM roles WHERE lower(nama) = 'administrator' LIMIT 1");
  let roleId = role?.id;
  if (!roleId) {
    roleId = run("INSERT INTO roles (nama, bawaan) VALUES ('Administrator', 1)").lastInsertRowid as number;
  }

  const ada = get<{ id: number; password_hash: string }>(
    "SELECT id, password_hash FROM users WHERE lower(trim(username)) = 'admin' LIMIT 1",
  );

  if (!ada) {
    run(
      `INSERT INTO users (nama, username, password_hash, role_id, wajib_ganti, sandi_diubah_pada)
       VALUES ('Administrator', 'admin', ?, ?, 1, ?)`,
      hashSandi(SANDI_ADMIN_AWAL),
      roleId,
      waktuSql(),
    );
    console.log(`[LOGIN] Akun Admin awal dibuat otomatis — username: admin, password: ${SANDI_ADMIN_AWAL} (wajib ganti saat login pertama).`);
    return;
  }

  if (!ada.password_hash || ada.password_hash === '!' || !ada.password_hash.startsWith('$2')) {
    run(
      "UPDATE users SET password_hash = ?, wajib_ganti = 1, sandi_diubah_pada = ? WHERE id = ?",
      hashSandi(SANDI_ADMIN_AWAL),
      waktuSql(),
      ada.id,
    );
    console.log(`[LOGIN] Password akun admin disetel ulang ke awal — username: admin, password: ${SANDI_ADMIN_AWAL} (wajib ganti saat login pertama).`);
  }
}
