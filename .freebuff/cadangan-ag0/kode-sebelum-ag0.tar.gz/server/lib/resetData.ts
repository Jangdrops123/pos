// Reset Data — Pengaturan ▸ Database & Backup (hanya Admin utama).
//
// Tiga pilihan, makin luas cakupannya:
//   1. transaksi — penjualan, pembelian, retur, Item Masuk/Keluar, Opname,
//      transfer, jurnal, kas; stok kembali 0. Master, pengguna & pengaturan tetap.
//   2. master    — transaksi di atas + produk, kategori, pelanggan, pemasok,
//      gudang (dan turunannya). Pengguna & pengaturan tetap.
//   3. total     — semua di atas + toko, pengguna selain Admin utama, riwayat;
//      pengaturan kembali ke bawaan. Hanya akun Admin utama yang dipertahankan.
//
// Aturan yang dipegang:
//   * Urutan penghapusan SELALU detail dulu baru induk (baris anak → baris
//     induk), ditambah `PRAGMA defer_foreign_keys` supaya pemeriksaan kunci
//     asing ditunda sampai COMMIT — pemicu (trigger) tetap dihormati saat
//     statement dijalankan, jadi urutan inilah yang menentukan.
//   * Nomor urut dokumen (`document_counters`) direset sesuai pilihan: counter
//     transaksi saja untuk pilihan 1/2, seluruh counter untuk pilihan total.
//   * Sebelum eksekusi selalu dibuat cadangan pengaman (VACUUM INTO), sehingga
//     reset yang keliru tetap bisa dibatalkan lewat "Pulihkan dari Backup".
//   * Setiap reset tercatat di Log Aktivitas (siapa/peran, kapan, jenis reset,
//     jumlah data per modul, nama cadangan pengaman).
import { all, db, get, run, withTransaction } from '../db.ts';
import { catatAudit } from './audit.ts';
import { tolak } from './http.ts';
import { JENIS_NOMOR } from './pengaturanBaru.ts';
import { buatBackup } from './sistem.ts';

export type JenisReset = 'transaksi' | 'master' | 'total';

export const JENIS_RESET: { kode: JenisReset; label: string; ket: string }[] = [
  {
    kode: 'transaksi',
    label: 'Reset Transaksi',
    ket: 'Hapus semua transaksi (penjualan, pembelian, retur, Item Masuk/Keluar, Opname, transfer, jurnal, kas) dan kembalikan stok ke 0. Master data, pengguna, dan pengaturan tetap.',
  },
  {
    kode: 'master',
    label: 'Reset Transaksi + Master Data',
    ket: 'Semua isi Reset Transaksi, ditambah produk, kategori, pelanggan, pemasok, dan gudang beserta turunannya. Pengguna dan pengaturan tetap.',
  },
  {
    kode: 'total',
    label: 'Reset Total',
    ket: 'Kembalikan aplikasi ke kondisi awal (data kosong). Hanya akun Admin utama yang dipertahankan, pengaturan kembali ke bawaan.',
  },
];

export function labelReset(jenis: string): string {
  return JENIS_RESET.find((j) => j.kode === jenis)?.label ?? jenis;
}

/** Satu baris tabel yang dikosongkan. `saring` = klausa WHERE (tanpa WHERE). */
interface Sasaran {
  tabel: string;
  saring?: string;
}

export interface ModulReset {
  kode: string;
  label: string;
  tabel: Sasaran[];
  /** Penghapusan ditangani khusus (pengguna / pengaturan / nomor urut). */
  khusus?: 'pengguna' | 'pengaturan' | 'nomor_urut';
}

/* ------------------------- dasar kunci nomor urut ------------------------ */

/** Dasar kunci counter dokumen transaksi (mis. `inv`, `pb`, `persediaan-masuk`). */
const DASAR_NOMOR = [
  ...new Set(JENIS_NOMOR.flatMap((j) => [j.dasarKunci ?? '', j.prefix.toLowerCase()]).filter(Boolean)),
];

/**
 * WHERE untuk counter transaksi. Kunci counter berbentuk `<dasar>-<periode>`
 * (mis. `inv-2026`, `pb-2026-10`), jadi pencocokan awalan memastikan seluruh
 * periode ikut direset — nomor dokumen berikutnya kembali ke 0001.
 */
const saringNomorTransaksi = DASAR_NOMOR.map(
  (d) => `(kunci = '${d}' OR kunci LIKE '${d}-%')`,
).join(' OR ');

/* ----------------------------- modul transaksi --------------------------- */

const MODUL_TRANSAKSI: ModulReset[] = [
  {
    kode: 'retur',
    label: 'Retur Penjualan',
    tabel: [{ tabel: 'sale_return_items' }, { tabel: 'sale_returns' }],
  },
  { kode: 'faktur', label: 'Faktur (dokumen)', tabel: [{ tabel: 'invoices' }] },
  {
    kode: 'penjualan',
    label: 'Penjualan (POS)',
    tabel: [
      { tabel: 'receivables' },
      { tabel: 'sale_payments' },
      { tabel: 'sale_items' },
      { tabel: 'sales' },
      { tabel: 'held_sales' },
      { tabel: 'cashier_shifts' },
    ],
  },
  { kode: 'pembayaran', label: 'Pembayaran piutang/hutang', tabel: [{ tabel: 'payments' }] },
  {
    kode: 'pembelian',
    label: 'Pembelian',
    tabel: [
      { tabel: 'payables' },
      { tabel: 'purchase_scan_logs' },
      { tabel: 'purchase_chat_logs' },
      { tabel: 'purchase_items' },
      { tabel: 'purchases' },
    ],
  },
  {
    kode: 'item_masuk_keluar',
    label: 'Item Masuk / Keluar',
    tabel: [{ tabel: 'sub_stock_items' }, { tabel: 'sub_stock_docs' }],
  },
  {
    kode: 'opname',
    label: 'Opname',
    tabel: [{ tabel: 'opname_scans' }, { tabel: 'opname_items' }, { tabel: 'opname_sessions' }],
  },
  {
    kode: 'transfer',
    label: 'Transfer Gudang',
    tabel: [{ tabel: 'stock_transfer_items' }, { tabel: 'stock_transfers' }],
  },
  {
    kode: 'jurnal',
    label: 'Jurnal',
    // Pemicu "jurnal disahkan tidak dapat diubah" dilepas dulu (status → batal,
    // diizinkan pemicu) sebelum baris & baris jurnalnya dihapus.
    tabel: [{ tabel: 'journal_lines' }, { tabel: 'journals' }],
  },
  { kode: 'kas', label: 'Kas & bank (mutasi kas)', tabel: [{ tabel: 'cash_transactions' }] },
  {
    kode: 'stok',
    label: 'Stok (kartu stok & saldo)',
    tabel: [{ tabel: 'stock_ledger' }, { tabel: 'stock_balances' }],
  },
];

const MODUL_NOMOR_TRANSAKSI: ModulReset = {
  kode: 'nomor_urut',
  label: 'Nomor urut dokumen transaksi',
  tabel: [{ tabel: 'document_counters', saring: saringNomorTransaksi }],
  khusus: 'nomor_urut',
};

/* ------------------------------ modul master ----------------------------- */

const MODUL_MASTER: ModulReset[] = [
  {
    kode: 'produk',
    label: 'Produk, paket & konversi satuan',
    tabel: [
      { tabel: 'unit_conversions' },
      { tabel: 'pack_items' },
      { tabel: 'products' },
      { tabel: 'packs' },
    ],
  },
  {
    kode: 'kategori_merek',
    label: 'Kategori & merek',
    tabel: [{ tabel: 'categories' }, { tabel: 'brands' }],
  },
  { kode: 'satuan', label: 'Satuan', tabel: [{ tabel: 'units' }] },
  { kode: 'pelanggan', label: 'Pelanggan', tabel: [{ tabel: 'customers' }] },
  { kode: 'pemasok', label: 'Pemasok', tabel: [{ tabel: 'suppliers' }] },
  {
    kode: 'gudang',
    label: 'Gudang & lokasi',
    tabel: [{ tabel: 'locations' }, { tabel: 'warehouses' }],
  },
  {
    kode: 'profil_size',
    label: 'Profil size buatan',
    // Profil bawaan (bawaan = 1) termasuk "kondisi awal" — hanya profil buatan
    // pengguna yang dihapus beserta rinciannya.
    tabel: [
      {
        tabel: 'size_profile_sizes',
        saring: 'profile_id IN (SELECT id FROM size_profiles WHERE bawaan = 0)',
      },
      { tabel: 'size_profiles', saring: 'bawaan = 0' },
    ],
  },
];

/* ---------------------------- modul khusus total ------------------------- */

function modulTotal(adminId: number | null): ModulReset[] {
  return [
    { kode: 'toko', label: 'Toko', tabel: [{ tabel: 'stores' }] },
    {
      kode: 'laporan_tersimpan',
      label: 'Laporan tersimpan',
      tabel: [{ tabel: 'report_files' }, { tabel: 'saved_reports' }],
    },
    {
      kode: 'riwayat_impor',
      label: 'Riwayat impor',
      tabel: [{ tabel: 'import_errors' }, { tabel: 'import_batches' }],
    },
    {
      kode: 'riwayat_proses',
      label: 'Riwayat Proses Tahunan',
      tabel: [{ tabel: 'annual_processes' }],
    },
    { kode: 'log_aktivitas', label: 'Log Aktivitas lama', tabel: [{ tabel: 'audit_logs' }] },
    {
      kode: 'pengguna',
      label: 'Pengguna selain Admin utama',
      tabel: [{ tabel: 'users', saring: adminId === null ? undefined : `id <> ${adminId}` }],
      khusus: 'pengguna',
    },
    {
      kode: 'pengaturan',
      label: 'Pengaturan (kembali ke bawaan)',
      tabel: [{ tabel: 'settings' }],
      khusus: 'pengaturan',
    },
    {
      kode: 'nomor_urut',
      label: 'Nomor urut seluruh dokumen',
      tabel: [{ tabel: 'document_counters' }],
      khusus: 'nomor_urut',
    },
  ];
}

/* --------------------------- daftar per pilihan -------------------------- */

/** Tabel yang TIDAK disentuh reset total (konfigurasi & keadaan awal). */
const TABEL_DIPERTAHANKAN = new Set([
  'schema_migrations',
  'roles',
  'role_permissions',
  // TAHAP 1/2 — hak akses & keadaan login ikut "pengguna yang dipertahankan":
  // sesi aktif tidak boleh putus di tengah reset, kode pemulihan & hak khusus
  // per peran adalah konfigurasi (bisa sudah dicetak/disetel Admin).
  'role_hak_khusus',
  'sessions',
  'password_resets',
  'recovery_codes',
  'users',
  'settings',
  'accounts',
  'periods',
  'cash_accounts',
  'expense_categories',
  'payment_method_accounts',
  'struk_profil',
  'invoice_templates',
  'size_profiles',
  'size_profile_sizes',
  'dashboard_layout',
  'dashboard_layout_peran',
  'pengaturan_dashboard',
  'pengaturan_dashboard_peran',
]);

const DIPERTAHANKAN: Record<JenisReset, string[]> = {
  transaksi: [
    'Master data (produk, kategori, pelanggan, pemasok, gudang, satuan, profil size)',
    'Pengguna & peran',
    'Pengaturan sistem',
    'Toko & riwayat impor/laporan tersimpan',
    'COA, periode akuntansi, template faktur & struk',
    'Log Aktivitas',
  ],
  master: [
    'Pengguna & peran',
    'Pengaturan sistem',
    'Profil size bawaan',
    'Toko & riwayat impor/laporan tersimpan',
    'COA, periode akuntansi, template faktur & struk',
    'Log Aktivitas',
  ],
  total: [
    'Akun Admin utama',
    'Peran & matriks hak akses',
    'Pengaturan sistem (dikembalikan ke bawaan)',
    'COA, periode akuntansi, kas/bank, kategori biaya',
    'Profil size bawaan, template faktur & struk',
    'Susunan kartu dashboard',
  ],
};

/** Id akun Admin utama: peran Administrator/Owner terlama (fallback: terlama). */
export function adminUtamaId(): number | null {
  const dariPeran = get<{ id: number }>(
    `SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id
      WHERE lower(r.nama) IN ('administrator', 'owner', 'admin')
      ORDER BY u.id LIMIT 1`,
  );
  if (dariPeran) return Number(dariPeran.id);
  const terlama = get<{ id: number }>('SELECT id FROM users ORDER BY id LIMIT 1');
  return terlama ? Number(terlama.id) : null;
}

export function modulUntuk(jenis: JenisReset): ModulReset[] {
  if (jenis === 'transaksi') return [...MODUL_TRANSAKSI, MODUL_NOMOR_TRANSAKSI];
  if (jenis === 'master') return [...MODUL_TRANSAKSI, ...MODUL_MASTER, MODUL_NOMOR_TRANSAKSI];
  return [...MODUL_TRANSAKSI, ...MODUL_MASTER, ...modulTotal(adminUtamaId())];
}

function jumlahSasaran(s: Sasaran): number {
  try {
    const n = get<{ n: number }>(
      `SELECT COUNT(*) AS n FROM "${s.tabel}"${s.saring ? ` WHERE ${s.saring}` : ''}`,
    );
    return Number(n?.n ?? 0);
  } catch {
    return 0;
  }
}

export interface BarisRingkasan {
  kode: string;
  label: string;
  jumlah: number;
}

export interface RingkasanReset {
  jenis: JenisReset;
  label: string;
  ket: string;
  modul: BarisRingkasan[];
  total: number;
  dipertahankan: string[];
}

/** Langkah 1 — ringkasan jumlah data yang akan dihapus per modul. */
export function ringkasanReset(jenis: JenisReset): RingkasanReset {
  const info = JENIS_RESET.find((j) => j.kode === jenis);
  if (!info) throw tolak(400, 'Jenis reset tidak dikenal (transaksi / master / total).');
  const modul = modulUntuk(jenis).map((m) => ({
    kode: m.kode,
    label: m.label,
    jumlah: m.tabel.reduce((a, s) => a + jumlahSasaran(s), 0),
  }));
  return {
    jenis,
    label: info.label,
    ket: info.ket,
    modul,
    total: modul.reduce((a, m) => a + m.jumlah, 0),
    dipertahankan: DIPERTAHANKAN[jenis],
  };
}

/* ------------------------------ penghapusan ------------------------------ */

/** Buka kunci pemicu jurnal: baris disahkan diubah ke `batal` dulu (diizinkan
 * pemicu "terkunci"), baru baris jurnal & barisnya boleh dihapus. */
function bukaKunciJurnal(): void {
  run(`UPDATE journals SET status = 'batal' WHERE status = 'disahkan'`);
}

/**
 * Lepas rujukan gudang pada tabel yang dipertahankan (toko & riwayat Proses
 * Tahunan) sebelum gudang dihapus pada pilihan master/total.
 */
function lepasRujukanGudang(): void {
  for (const [tabel, kolom] of [
    ['stores', 'warehouse_id'],
    ['annual_processes', 'gudang_id'],
  ] as const) {
    try {
      run(`UPDATE "${tabel}" SET "${kolom}" = NULL WHERE "${kolom}" IS NOT NULL`);
    } catch (e) {
      throw tolak(500, `Gagal melepas rujukan gudang pada ${tabel}: ${e instanceof Error ? e.message : 'galat'}`);
    }
  }
}

/**
 * Lepas rujukan ke pengguna yang akan dihapus dari tabel yang dipertahankan:
 * kolom yang boleh kosong di-set NULL, kolom NOT NULL (mis. preferensi
 * dashboard) barisnya ikut dihapus. Dilakukan sebelum baris pengguna dihapus.
 */
function lepasRujukanUser(idHapus: number[]): void {
  if (!idHapus.length) return;
  const daftar = idHapus.map(() => '?').join(',');
  const tabel = all<{ name: string }>(
    `SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'`,
  ).map((r) => r.name);
  for (const t of tabel) {
    const fks = all<{ from: string; table: string }>(`PRAGMA foreign_key_list("${t}")`).filter(
      (f) => f.table === 'users',
    );
    for (const fk of fks) {
      try {
        const kolom = all<{ name: string; notnull: number }>(`PRAGMA table_info("${t}")`).find(
          (c) => c.name === fk.from,
        );
        if (kolom && kolom.notnull) {
          run(`DELETE FROM "${t}" WHERE "${fk.from}" IN (${daftar})`, ...idHapus);
        } else {
          run(`UPDATE "${t}" SET "${fk.from}" = NULL WHERE "${fk.from}" IN (${daftar})`, ...idHapus);
        }
      } catch {
        /* relasi tidak relevan — dilewati, transaksi tetap atomik */
      }
    }
  }
}

/**
 * Pengaturan kembali ke bawaan = baris `settings` seperti keadaan awal hasil
 * migrasi (seed 002/008/012/017/022). Kunci yang tidak pernah di-seed dihapus
 * saja — pembaca tab Pengaturan jatuh ke nilai bawaan registry.
 *
 * Dua kunci wajib ikut dikembalikan supaya aplikasi tetap jalan setelah reset:
 * `pin_supervisor` (verifikasi ulang kata sandi & PIN void/retur) dan
 * `akuntansi_pemetaan` (semua kode jurnal otomatis).
 */
const PENGATURAN_BAWAAN: { kunci: string; nilai: string; keterangan: string }[] = [
  { kunci: 'stok_minus_izinkan', nilai: 'false', keterangan: 'Izinkan stok menjadi minus jika stok fisik kurang' },
  { kunci: 'pajak_persen', nilai: '0', keterangan: 'Persentase pajak penjualan (PPN) bawaan' },
  { kunci: 'mata_uang', nilai: 'IDR', keterangan: 'Mata uang aplikasi (Rupiah)' },
  { kunci: 'format_tanggal', nilai: 'dd/mm/yyyy', keterangan: 'Format tanggal tampilan aplikasi' },
  { kunci: 'nama_usaha', nilai: 'Toko Retail', keterangan: 'Nama usaha/cabang pada dokumen dan struk' },
  {
    kunci: 'pin_supervisor',
    // SHA-256 dari '1234' (bawaan) — dipakai verifikasi ulang kata sandi.
    nilai: '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4',
    keterangan: 'PIN supervisor void/retur (SHA-256; bawaan 1234)',
  },
  { kunci: 'faktur_prefix_penjualan', nilai: 'INV', keterangan: 'Prefix nomor faktur penjualan (mis. INV-2026-0001)' },
  { kunci: 'faktur_prefix_pembelian', nilai: 'PB', keterangan: 'Prefix nomor faktur pembelian (mis. PB-2026-0001)' },
  { kunci: 'alamat_usaha', nilai: '', keterangan: 'Alamat toko pada faktur & dokumen' },
  { kunci: 'telepon_usaha', nilai: '', keterangan: 'Telepon toko pada faktur & dokumen' },
  { kunci: 'logo_usaha', nilai: '', keterangan: 'URL/logo toko pada faktur (opsional)' },
  {
    kunci: 'aturan_kodi',
    nilai: '{"per_kodi":20,"normal":{"39":4,"40":4,"41":4,"42":4,"43":4}}',
    keterangan: 'Aturan per kodi untuk parser Chatbot: jumlah pasang per kodi & jatah per size',
  },
  {
    kunci: 'akuntansi_pemetaan',
    nilai:
      '{"peran":{"kas_kasir":"1-1100","kas_besar":"1-1110","bank":"1-1200","kas_dalam_penyelesaian":"1-1210","piutang":"1-1300","persediaan":"1-1400","ppn_masukan":"1-1500","uang_muka_pembelian":"1-1600","hutang_usaha":"2-1100","ppn_keluaran":"2-1200","uang_muka_pelanggan":"2-1400","laba_ditahan":"3-3000","penjualan":"4-1100","diskon_penjualan":"4-1200","retur_penjualan":"4-1300","pendapatan_lain":"4-2000","selisih_stok_lebih":"4-2100","hpp":"5-1000","diskon_pembelian":"5-2000","retur_pembelian":"5-3000","selisih_stok_kurang":"6-1900","selisih_kas":"6-1950","beban_admin_bank":"6-1700"},"metode":{"tunai":"kas_kasir","transfer":"bank","qris":"kas_dalam_penyelesaian","kredit":"piutang"}}',
    keterangan: 'Pemetaan peran akun otomatis & metode bayar → kode akun COA',
  },
  {
    kunci: 'akuntansi_ppn',
    nilai: '{"aktif":false,"tarif":11,"harga_termasuk":false}',
    keterangan: 'Pengaturan PPN: aktif (PKP), tarif %, harga sudah termasuk PPN',
  },
  {
    kunci: 'size_profile_default',
    nilai: 'sepatu-pria',
    keterangan: 'Profil size default untuk chatbot (kode profil)',
  },
];

function kembalikanPengaturanBawaan(): number {
  const sebelum = jumlahSasaran({ tabel: 'settings' });
  run('DELETE FROM settings');
  for (const p of PENGATURAN_BAWAAN) {
    run(
      'INSERT INTO settings (kunci, nilai, keterangan) VALUES (?, ?, ?)',
      p.kunci,
      p.nilai,
      p.keterangan,
    );
  }
  return sebelum;
}

/**
 * Setelah master dihapus, rujukan pengaturan yang menggantung (gudang/satuan/
 * profil size yang sudah tidak ada) dikembalikan ke bawaan supaya tidak
 * menunjuk data yang sudah tidak ada.
 */
function bersihkanRujukanMaster(): void {
  const hilang = (kunci: string, cek: (nilai: string) => boolean): void => {
    const nilai = get<{ nilai: string | null }>('SELECT nilai FROM settings WHERE kunci = ?', kunci)
      ?.nilai;
    if (nilai && !cek(nilai)) run('DELETE FROM settings WHERE kunci = ?', kunci);
  };
  hilang('gudang_bawaan', (v) => Boolean(get('SELECT id FROM warehouses WHERE id = ?', v)));
  hilang('peng.umum-regional.satuan_bawaan', (v) =>
    Boolean(get('SELECT id FROM units WHERE id = ?', v)),
  );
  hilang('size_profile_default', (v) => Boolean(get('SELECT id FROM size_profiles WHERE kode = ?', v)));
}

/* -------------------------------- hasil ---------------------------------- */

export interface HasilReset {
  jenis: JenisReset;
  label: string;
  waktu: string;
  modul: BarisRingkasan[];
  total: number;
  nomor_urut: number;
  pengguna_dihapus: number;
  pengguna_dipertahankan: number;
  pengaturan: number;
  log_dihapus: number;
  cadangan_pengaman: string;
  dipertahankan: string[];
  dilewati: string[];
}

/**
 * Jalankan reset. Seluruh tahap berjalan dalam SATU transaksi: gagal di tengah
 * berarti tidak ada data yang hilang. Cadangan pengaman dibuat di luar
 * transaksi (VACUUM INTO tidak boleh di dalam transaksi) sehingga selalu ada
 * untuk fitur "Pulihkan dari Backup".
 */
export function jalankanReset(jenis: JenisReset, userId: number | null, peran: string): HasilReset {
  const info = JENIS_RESET.find((j) => j.kode === jenis);
  if (!info) throw tolak(400, 'Jenis reset tidak dikenal (transaksi / master / total).');

  const adminId = adminUtamaId();
  const daftarModul = modulUntuk(jenis);
  const dihitung: BarisRingkasan[] = daftarModul.map((m) => ({
    kode: m.kode,
    label: m.label,
    jumlah: m.tabel.reduce((a, s) => a + jumlahSasaran(s), 0),
  }));
  const total = dihitung.reduce((a, m) => a + m.jumlah, 0);
  const jumlahModul = (kode: string): number => dihitung.find((m) => m.kode === kode)?.jumlah ?? 0;

  // Cadangan pengaman — dibuat sebelum satu baris pun dihapus.
  const cadangan = buatBackup(`sebelum ${info.label}`);

  return withTransaction(() => {
    // Pemeriksaan kunci asing ditunda sampai COMMIT: urutan detail → induk
    // tetap dijalankan agar pemicu penghapusan tidak menolak statement.
    db.exec('PRAGMA defer_foreign_keys = ON');

    const dilewati: string[] = [];
    let nomorUrut = 0;
    let penggunaHapus = 0;
    let pengaturan = 0;

    for (const m of daftarModul) {
      if (m.khusus === 'pengaturan') {
        pengaturan = kembalikanPengaturanBawaan();
        continue;
      }
      if (m.khusus === 'pengguna') {
        if (adminId !== null) {
          const lain = all<{ id: number }>('SELECT id FROM users WHERE id <> ?', adminId).map((r) =>
            Number(r.id),
          );
          lepasRujukanUser(lain);
        }
        penggunaHapus = hapusSasaran(m.tabel);
        continue;
      }
      if (m.khusus === 'nomor_urut') {
        nomorUrut = hapusSasaran(m.tabel);
        continue;
      }
      if (m.kode === 'jurnal') bukaKunciJurnal();
      if (m.kode === 'gudang') lepasRujukanGudang();
      for (const s of m.tabel) {
        try {
          hapusSatu(s);
        } catch (e) {
          dilewati.push(`${m.label} (${s.tabel}): ${e instanceof Error ? e.message : 'gagal'}`);
        }
      }
    }

    if (jenis === 'master') bersihkanRujukanMaster();
    if (jenis === 'total') sapuTabelLain(dilewati);

    // Log Aktivitas: reset dicatat setelah pembersihan — pada Reset Total
    // inilah satu-satunya (dan yang paling penting) baris log yang tersisa.
    catatAudit({
      userId,
      aksi: 'reset',
      tabel: 'pengaturan',
      recordId: jenis,
      sesudah: {
        jenis: info.label,
        peran,
        total_dihapus: total,
        modul: Object.fromEntries(dihitung.map((m) => [m.kode, m.jumlah])),
        nomor_urut: nomorUrut,
        cadangan_pengaman: cadangan,
      },
      alasan: `Reset Data — ${info.label}`,
    });

    return {
      jenis,
      label: info.label,
      waktu: new Date().toISOString(),
      modul: dihitung,
      total,
      nomor_urut: nomorUrut,
      pengguna_dihapus: penggunaHapus,
      pengguna_dipertahankan: Number(
        get<{ n: number }>('SELECT COUNT(*) AS n FROM users')?.n ?? 0,
      ),
      pengaturan,
      log_dihapus: jumlahModul('log_aktivitas'),
      cadangan_pengaman: cadangan,
      dipertahankan: DIPERTAHANKAN[jenis],
      dilewati,
    } satisfies HasilReset;
  });
}

function hapusSatu(s: Sasaran): number {
  return run(`DELETE FROM "${s.tabel}"${s.saring ? ` WHERE ${s.saring}` : ''}`).changes;
}

function hapusSasaran(tabel: Sasaran[]): number {
  return tabel.reduce((a, s) => a + hapusSatu(s), 0);
}

/**
 * Sapu tabel yang tidak termasuk daftar mana pun (termasuk tabel baru hasil
 * migrasi mendatang) supaya Reset Total benar-benar menyisakan "data kosong".
 * Kegagalan satu tabel dicatat sebagai `dilewati` — tidak membatalkan reset.
 */
function sapuTabelLain(dilewati: string[]): void {
  const dipertahankan = new Set(TABEL_DIPERTAHANKAN);
  const dipakai = new Set(
    [...MODUL_TRANSAKSI, ...MODUL_MASTER, ...modulTotal(adminUtamaId())].flatMap((m) =>
      m.tabel.map((s) => s.tabel),
    ),
  );
  const semua = all<{ name: string }>(
    `SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name`,
  ).map((r) => r.name);
  for (const t of semua) {
    if (dipertahankan.has(t) || dipakai.has(t)) continue;
    try {
      run(`DELETE FROM "${t}"`);
    } catch (e) {
      dilewati.push(`${t}: ${e instanceof Error ? e.message : 'gagal'}`);
    }
  }
}
