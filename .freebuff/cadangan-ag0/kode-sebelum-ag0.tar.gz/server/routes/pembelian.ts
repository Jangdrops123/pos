import { Router } from 'express';
import { all, get, run, withTransaction } from '../db.ts';
import { nomorOtomatis } from '../lib/pengaturanBaru.ts';
import { asyncHandler, bacaPaginasi, pesanKesalahan, polaCari, tolak } from '../lib/http.ts';
import { catatAudit } from '../lib/audit.ts';
import { penggunaSaatIni, wajibAdmin } from '../lib/akses.ts';
import { ubahStok } from '../lib/stok.ts';
import { uraiPembelian, uraiPembelianBaris } from '../lib/urai.ts';
import { buatFakturPembelian } from '../lib/faktur.ts';

/**
 * API Pembelian/Inbound — alur Purchase Order (opsional) → Penerimaan Barang
 * (GRN) → Faktur Pembelian dengan status: draft → diterima → disahkan.
 *
 * PENTING (sesuai spesifikasi): stok masuk + jurnal persediaan/hutang BARU
 * dibuat saat PENGESAHAN. Tahap GRN ('diterima') hanya mencatat penerimaan
 * (no. GRN + waktu) — tidak menggerakkan stok, tidak menulis jurnal.
 *
 * Tiga metode input (Biasa, Scan Barcode, Chatbot) memakai dokumen draft,
 * data, dan alur pengesahan YANG SAMA — hanya sisi input yang berbeda
 * (endpoint scan/chatbot menyusul pada prompt berikutnya).
 */

const METODE = new Set(['biasa', 'scan', 'chatbot']);
const STATUS_DIFORMAT = new Set(['draft', 'diterima', 'disahkan', 'batal']);

/** Nomor dokumen per bulan: PB-2026-10-0001, GRN-…, FP-…. */
function nomorDokumen(prefix: string): string {
  // Mengikuti Pengaturan ▸ Penomoran Dokumen; nilai bawaan = perilaku lama.
  const jenis = prefix === 'GRN' ? 'penerimaan' : prefix === 'FP' ? 'faktur_pemasok' : 'pembelian';
  return nomorOtomatis(jenis);
}

/** Lokasi pertama sebuah gudang (penerimaan stok masuk). */
function lokasiGudang(warehouseId: number): number {
  const l = get<{ id: number }>(`SELECT id FROM locations WHERE warehouse_id = ? ORDER BY id LIMIT 1`, warehouseId);
  if (!l) throw tolak(400, 'Gudang tidak memiliki lokasi — buat dulu di Master › Gudang & Lokasi.');
  return l.id;
}

interface BarisMasuk {
  product_id: number;
  qty: number;
  unit_id: number | null;
  harga_beli: number;
  diskon: number;
  /** Dari box mana baris ini (metode Scan) — null = satuan/manual. */
  pack_id: number | null;
  /** Asal input: 'box' | 'satuan' | 'manual' (metode Scan). */
  sumber_scan: string | null;
}

const SUMBER_SCAN = new Set(['box', 'satuan', 'manual']);

interface LogScanMasuk {
  barcode: string;
  tipe: string;
  pack_id: number | null;
  product_id: number | null;
}

/** Validasi riwayat scan yang menyertai pembuatan draft (metode Scan). */
function validasiLogScan(body: Record<string, unknown>): LogScanMasuk[] {
  const raw = Array.isArray(body.scan_logs) ? (body.scan_logs as Record<string, unknown>[]) : [];
  return raw.slice(0, 500).map((l) => {
    const barcode = String(l.barcode ?? '').trim();
    if (!barcode) throw tolak(400, 'Riwayat scan: barcode kosong.');
    if (barcode.length > 80) throw tolak(400, 'Riwayat scan: barcode maksimal 80 karakter.');
    const tipe = String(l.tipe ?? '');
    if (!['box', 'satuan', 'tidak_dikenal'].includes(tipe)) {
      throw tolak(400, 'Riwayat scan: tipe harus box/satuan/tidak_dikenal.');
    }
    const packId = l.pack_id ? Number(l.pack_id) : null;
    if (packId && !get<{ id: number }>(`SELECT id FROM packs WHERE id = ?`, packId)) {
      throw tolak(400, 'Riwayat scan: paket tidak ditemukan.');
    }
    const productId = l.product_id ? Number(l.product_id) : null;
    if (productId && !get<{ id: number }>(`SELECT id FROM products WHERE id = ?`, productId)) {
      throw tolak(400, 'Riwayat scan: produk tidak ditemukan.');
    }
    return { barcode, tipe, pack_id: packId, product_id: productId };
  });
}

interface IsiPembelian {
  metode: string;
  supplier_id: number;
  warehouse_id: number;
  tanggal: string;
  no_po: string | null;
  pajak_persen: number;
  items: BarisMasuk[];
}

/** Validasi body buat/ubah draft — melempar 400/409 dengan pesan ramah. */
function validasiIsi(body: Record<string, unknown>): IsiPembelian {
  const supplier = Number(body.supplier_id);
  if (!Number.isInteger(supplier) || !get<{ id: number }>(`SELECT id FROM suppliers WHERE id = ?`, supplier)) {
    throw tolak(400, 'Pemasok tidak ditemukan.');
  }
  const gudang = Number(body.warehouse_id);
  if (!Number.isInteger(gudang) || !get<{ id: number }>(`SELECT id FROM warehouses WHERE id = ?`, gudang)) {
    throw tolak(400, 'Gudang tujuan tidak ditemukan.');
  }
  const metode = String(body.metode_input ?? 'biasa');
  if (!METODE.has(metode)) throw tolak(400, 'Metode input tidak dikenal (biasa/scan/chatbot).');

  let tanggal = new Date().toISOString();
  if (body.tanggal) {
    const d = new Date(String(body.tanggal));
    if (Number.isNaN(d.getTime())) throw tolak(400, 'Tanggal tidak valid.');
    tanggal = d.toISOString();
  }
  const no_po = String(body.no_po ?? '').trim() || null;
  const pajakPersen = Number(body.pajak_persen ?? 0);
  if (!Number.isFinite(pajakPersen) || pajakPersen < 0 || pajakPersen > 100) {
    throw tolak(400, 'Pajak harus antara 0–100%.');
  }

  const raw = Array.isArray(body.items) ? (body.items as Record<string, unknown>[]) : [];
  if (raw.length === 0) throw tolak(400, 'Pembelian harus memiliki minimal satu item.');
  const lihat = new Set<string>();
  const items = raw.map((i) => {
    const productId = Number(i.product_id);
    const v = get<{ id: number; satuan_dasar_id: number | null }>(
      `SELECT id, satuan_dasar_id FROM products WHERE id = ?`,
      productId,
    );
    if (!v) throw tolak(400, 'Produk tidak ditemukan.');
    const qty = Number(i.qty);
    if (!Number.isFinite(qty) || qty <= 0) throw tolak(400, 'Jumlah harus lebih dari 0.');
    const harga = Number(i.harga_beli ?? 0);
    if (!Number.isFinite(harga) || harga < 0) throw tolak(400, 'Harga beli tidak valid.');
    const diskon = Number(i.diskon ?? 0);
    if (!Number.isFinite(diskon) || diskon < 0 || diskon > qty * harga + 1e-9) {
      throw tolak(400, 'Diskon item tidak boleh negatif atau melebihi nilai item.');
    }
    const unitId = i.unit_id ? Number(i.unit_id) : null;
    if (unitId && !get<{ id: number }>(`SELECT id FROM units WHERE id = ?`, unitId)) {
      throw tolak(400, 'Satuan tidak ditemukan.');
    }
    if (unitId && v.satuan_dasar_id && unitId !== v.satuan_dasar_id) {
      const konversi = get<{ id: number }>(
        `SELECT id FROM unit_conversions WHERE product_id = ? AND unit_id = ?`,
        productId,
        unitId,
      );
      if (!konversi) {
        throw tolak(400, 'Satuan terpilih belum dikonversi ke satuan dasar — lengkapi di Master › Konversi Satuan.');
      }
    }
    const packId = i.pack_id ? Number(i.pack_id) : null;
    if (packId && !get<{ id: number }>(`SELECT id FROM packs WHERE id = ?`, packId)) {
      throw tolak(400, 'Paket/box tidak ditemukan.');
    }
    const sumberScan = i.sumber_scan ? String(i.sumber_scan) : null;
    if (sumberScan && !SUMBER_SCAN.has(sumberScan)) {
      throw tolak(400, 'Sumber scan tidak dikenal (box/satuan/manual).');
    }
    // Kecocokan unik per produk + paket: produk yang sama boleh muncul dua kali
    // bila satu baris dari box dan satu lagi satuan (indeks unik purchase_items).
    const kunci = `${productId}|${packId ?? -1}`;
    if (lihat.has(kunci)) throw tolak(409, 'Produk kembar dalam daftar item pembelian.');
    lihat.add(kunci);
    return { product_id: productId, qty, unit_id: unitId, harga_beli: harga, diskon, pack_id: packId, sumber_scan: sumberScan };
  });

  return { metode, supplier_id: supplier, warehouse_id: gudang, tanggal, no_po, pajak_persen: pajakPersen, items };
}

/** Total dokumen: dasar = Σ(item) − diskon; pajak = round(dasar × %). */
function hitungTotal(items: BarisMasuk[], pajakPersen: number) {
  const subtotal = items.reduce((a, i) => a + i.qty * i.harga_beli, 0);
  const diskon = items.reduce((a, i) => a + i.diskon, 0);
  const dasar = subtotal - diskon;
  const pajak = Math.round((dasar * pajakPersen) / 100);
  return { subtotal, diskon, pajak, total: dasar + pajak };
}

const SELECT_PEMBELIAN = `
  SELECT p.*, s.nama AS pemasok, s.termin_hari, w.kode AS gudang_kode, w.nama AS gudang_nama,
         u.nama AS pembuat,
         (SELECT COUNT(*) FROM purchase_items i WHERE i.purchase_id = p.id) AS jumlah_item,
         (SELECT COALESCE(SUM(qty), 0) FROM purchase_items i WHERE i.purchase_id = p.id) AS jumlah_qty
  FROM purchases p
  JOIN suppliers s ON s.id = p.supplier_id
  JOIN warehouses w ON w.id = p.warehouse_id
  LEFT JOIN users u ON u.id = p.dibuat_oleh`;

function bacaPembelian(id: number): Record<string, unknown> {
  const p = get<Record<string, unknown>>(`${SELECT_PEMBELIAN} WHERE p.id = ?`, id);
  if (!p) throw tolak(404, 'Dokumen pembelian tidak ditemukan.');
  const items = all<Record<string, unknown>>(
    `SELECT i.*, i.sku, i.nama_produk AS produk, i.product_id, prod.satuan_dasar_id,
            un.nama AS satuan, un_dasar.nama AS satuan_dasar
     FROM purchase_items i
     JOIN products prod ON prod.id = i.product_id
     LEFT JOIN units un ON un.id = i.unit_id
     LEFT JOIN units un_dasar ON un_dasar.id = prod.satuan_dasar_id
     WHERE i.purchase_id = ?
     ORDER BY i.id`,
    id,
  );
  const jurnal =
    get<Record<string, unknown>>(
      `SELECT no_jurnal, tanggal, status FROM journals WHERE sumber_tipe = 'pembelian' AND sumber_id = ?`,
      id,
    ) ?? null;
  const hutang =
    get<Record<string, unknown>>(
      `SELECT id, jatuh_tempo, total, terbayar, status FROM payables WHERE purchase_id = ?`,
      id,
    ) ?? null;
  return { ...p, items, jurnal, hutang };
}

export function routerPembelian(): Router {
  const r = Router();

  // ==========================================================================
  // Daftar dokumen (semua metode input — draft & hasil pengesahan bersama)
  // ==========================================================================
  r.get('/', (req, res) => {
    const p = bacaPaginasi(req, {
      urutBawaan: 'dibuat_pada',
      arahBawaan: 'DESC',
      urutDiizinkan: ['dibuat_pada', 'tanggal', 'total', 'no_dokumen'],
    });
    const syarat: string[] = [];
    const params: unknown[] = [];
    if (p.cari) {
      syarat.push(
        `(p.no_dokumen LIKE ? ESCAPE '\\' OR p.no_grn LIKE ? ESCAPE '\\' OR p.no_faktur LIKE ? ESCAPE '\\'
          OR p.no_po LIKE ? ESCAPE '\\' OR s.nama LIKE ? ESCAPE '\\')`,
      );
      const pola = polaCari(p.cari);
      params.push(pola, pola, pola, pola, pola);
    }
    const status = String(req.query.status ?? '');
    if (STATUS_DIFORMAT.has(status)) {
      syarat.push('p.status = ?');
      params.push(status);
    }
    const metode = String(req.query.metode ?? '');
    if (METODE.has(metode)) {
      syarat.push('p.metode_input = ?');
      params.push(metode);
    }
    if (req.query.gudang) {
      syarat.push('p.warehouse_id = ?');
      params.push(Number(req.query.gudang));
    }
    const where = syarat.length ? `WHERE ${syarat.join(' AND ')}` : '';

    const total = Number(
      get<{ n: number }>(
        `SELECT COUNT(*) AS n FROM purchases p JOIN suppliers s ON s.id = p.supplier_id ${where}`,
        ...params,
      )?.n ?? 0,
    );
    const data = all<Record<string, unknown>>(
      `${SELECT_PEMBELIAN} ${where} ORDER BY ${p.urut} ${p.arah}, p.id DESC LIMIT ? OFFSET ?`,
      ...params,
      p.per,
      p.offset,
    );
    res.json({ data, total, hal: p.hal, per: p.per });
  });

  // ==========================================================================
  // Mode Biasa: kolom cari (autocomplete) — satu endpoint yang mengembalikan
  // data lengkap per produk: kode item, SKU/barcode, stok di gudang tujuan,
  // harga beli terakhir dari pemasok tsb (fallback harga master), dan opsi
  // konversi satuan. Pencarian multi-kata, case-insensitive, dibatasi 10 baris
  // agar tetap ringan (klien men-cache daftar ini sekali per pemasok/gudang).
  // ==========================================================================
  r.get('/produk-cari', (req, res) => {
    const cari = String(req.query.cari ?? '').trim();
    const supplierId = Number(req.query.supplier_id) || null;
    const gudangId = Number(req.query.gudang_id) || null;
    // `ids` = daftar product_id dipisah koma (dipakai form Ubah untuk memperkaya
    // baris dokumen lama: konversi satuan & kode item) — tanpa kata kunci.
    const ids = String(req.query.ids ?? '')
      .split(',')
      .map((s) => Number(s.trim()))
      .filter((n) => Number.isInteger(n) && n > 0)
      .slice(0, 100);
    const kata = cari ? cari.split(/\s+/).filter(Boolean) : [];
    const syarat = ['p.aktif = 1'];
    const params: unknown[] = [];
    if (ids.length > 0) {
      syarat.push(`p.id IN (${ids.map(() => '?').join(',')})`);
      params.push(...ids);
    }
    for (const k of kata) {
      syarat.push(
        `(COALESCE(p.kode_item, '') LIKE ? ESCAPE '\\' OR p.nama LIKE ? ESCAPE '\\'
           OR p.sku LIKE ? ESCAPE '\\' OR COALESCE(p.barcode, '') LIKE ? ESCAPE '\\')`,
      );
      const pola = polaCari(k);
      params.push(pola, pola, pola, pola);
    }
    const data = all<Record<string, unknown>>(
      `SELECT p.id AS product_id, p.sku, p.barcode, p.harga_beli,
              p.nama AS produk, p.kode_item, p.satuan_dasar_id,
              un.nama AS satuan_dasar,
              (SELECT COALESCE(SUM(sb.qty), 0) FROM stock_balances sb
                WHERE sb.product_id = p.id ${gudangId ? 'AND sb.warehouse_id = ?' : ''}) AS stok,
              (SELECT pi.harga_beli FROM purchase_items pi
                 JOIN purchases pp ON pp.id = pi.purchase_id
                WHERE pi.product_id = p.id ${supplierId ? 'AND pp.supplier_id = ?' : ''}
                ORDER BY pp.tanggal DESC, pi.id DESC LIMIT 1) AS harga_terakhir,
              (SELECT GROUP_CONCAT(un2.id || '|' || un2.nama || '=' || uc.jumlah_per_satuan_dasar)
                 FROM unit_conversions uc JOIN units un2 ON un2.id = uc.unit_id
                WHERE uc.product_id = p.id) AS konversi
         FROM products p
         LEFT JOIN units un ON un.id = p.satuan_dasar_id
        WHERE ${syarat.join(' AND ')} AND p.deleted_at IS NULL
        ORDER BY p.nama, p.sku
        LIMIT ${ids.length ? 200 : 10}`,
      ...(gudangId ? [gudangId] : []),
      ...(supplierId ? [supplierId] : []),
      ...params,
    ).map((r) => ({
      ...r,
      konversi: r.konversi
        ? String(r.konversi)
            .split(',')
            .map((s) => {
              const [id, nama] = s.split('|');
              const jml = s.slice(s.lastIndexOf('=') + 1);
              return { unit_id: Number(id), nama, jumlah_per_satuan_dasar: Number(jml) };
            })
        : [],
    }));
    res.json({ data });
  });

  r.get('/:id', (req, res) => {
    res.json({ data: bacaPembelian(Number(req.params.id)) });
  });

  // ==========================================================================
  // Chatbot: urai teks bebas → baris draft (parser aturan/regex, tanpa API
  // eksternal) — riwayat pesan disimpan per sesi, diklaim ke dokumen saat
  // draft dibuat (lihat POST '/' → chat_sesi).
  // ==========================================================================
  r.post(
    '/chat/urai',
    asyncHandler((req, res) => {
      const body = (req.body ?? {}) as Record<string, unknown>;
      const teks = String(body.teks ?? '').trim();
      if (!teks) throw tolak(400, 'Teks chat kosong — ketik keterangan pembelian dulu.');
      if (teks.length > 4000) throw tolak(400, 'Teks chat terlalu panjang (maksimal 4000 karakter).');
      const chatSesi = String(body.chat_sesi ?? '').trim() || null;
      const purchaseId = body.purchase_id ? Number(body.purchase_id) : null;
      if (purchaseId && !get<{ id: number }>(`SELECT id FROM purchases WHERE id = ?`, purchaseId)) {
        throw tolak(404, 'Dokumen pembelian tidak ditemukan.');
      }

      const hasil = uraiPembelian(teks);
      const logId = Number(
        run(
          `INSERT INTO purchase_chat_logs (purchase_id, chat_sesi, pesan_user, pesan_bot, hasil_parse_json)
           VALUES (?, ?, ?, ?, ?)`,
          purchaseId,
          chatSesi,
          teks,
          hasil.pesan_bot,
          JSON.stringify({ pemasok: hasil.pemasok, baris: hasil.baris, catatan: hasil.catatan }),
        ).lastInsertRowid,
      );
      res.status(201).json({ log_id: logId, ...hasil });
    }),
  );

  // AF4/AF5 — hitung ulang SATU baris pratinjau setelah pengguna mengganti
  // profil / Db / Tp. Tanpa penyimpanan riwayat (hanya pratinjau).
  r.post(
    '/chat/ulang',
    asyncHandler((req, res) => {
      const body = (req.body ?? {}) as Record<string, unknown>;
      const teks = String(body.teks ?? '').trim();
      if (!teks) throw tolak(400, 'Teks baris kosong.');
      if (teks.length > 1000) throw tolak(400, 'Teks baris terlalu panjang (maksimal 1000 karakter).');
      const ubah = (body.ubah ?? {}) as { profil_id?: number | null; db?: number | null; tp?: number | null };
      res.json(uraiPembelianBaris(teks, ubah));
    }),
  );

  // Riwayat input per dokumen pembelian (untuk modal "Lihat"): percakapan chatbot
  // dan/atau log pemindaian barcode — bentuk keluaran seragam agar UI satu panel.
  r.get('/:id/chat', (req, res) => {
    const id = Number(req.params.id);
    if (!get<{ id: number }>(`SELECT id FROM purchases WHERE id = ?`, id)) {
      throw tolak(404, 'Dokumen pembelian tidak ditemukan.');
    }
    const chat = all<Record<string, unknown>>(
      `SELECT id, chat_sesi, pesan_user, pesan_bot, waktu
         FROM purchase_chat_logs
        WHERE purchase_id = ?
        ORDER BY id`,
      id,
    ).map((c) => ({ ...c, sumber: 'chat' }));
    const scan = all<Record<string, unknown>>(
      `SELECT sl.id, sl.barcode, sl.tipe, sl.pack_id, sl.product_id, sl.waktu,
              pk.nama AS pack_nama, pr.sku
         FROM purchase_scan_logs sl
         LEFT JOIN packs pk ON pk.id = sl.pack_id
         LEFT JOIN products pr ON pr.id = sl.product_id
        WHERE sl.purchase_id = ?
        ORDER BY sl.id`,
      id,
    ).map((s) => ({
      id: Number(s.id),
      chat_sesi: null,
      pesan_user: `📷 ${String(s.barcode)}`,
      pesan_bot:
        s.tipe === 'box'
          ? `Box "${String(s.pack_nama ?? s.pack_id)}" — seluruh isi masuk draft.`
          : s.tipe === 'satuan'
            ? `Produk satuan: ${String(s.sku ?? s.product_id)} — 1 pcs.`
            : 'Barcode belum terdaftar (tidak masuk draft).',
      waktu: s.waktu,
      sumber: 'scan',
    }));
    const data = ([...chat, ...scan] as Record<string, unknown>[]).sort(
      (a, b) => String(a.waktu).localeCompare(String(b.waktu)) || Number(a.id) - Number(b.id),
    );
    res.json({ data });
  });

  // ==========================================================================
  // Scan Barcode (metode Scan): resolve barcode → paket/box ATAU produk
  // satuan, atau tidak dikenal (dialog pendaftaran di sisi klien).
  // ==========================================================================
  r.post(
    '/scan',
    asyncHandler((req, res) => {
      const barcode = String((req.body ?? {}).barcode ?? '').trim();
      if (!barcode) throw tolak(400, 'Barcode kosong — pindai atau ketik barcode dulu.');
      if (barcode.length > 80) throw tolak(400, 'Barcode maksimal 80 karakter.');

      // 1) Paket/Box lebih dulu (barcode_box).
      const pack = get<{ id: number; kode_box: string; nama: string; barcode_box: string }>(
        `SELECT id, kode_box, nama, barcode_box FROM packs WHERE barcode_box = ?`,
        barcode,
      );
      if (pack) {
        const items = all<Record<string, unknown>>(
          `SELECT pi.product_id, pi.qty AS qty_per_box, pr.sku, pr.harga_beli, pr.satuan_dasar_id, pr.nama AS produk
             FROM pack_items pi
             JOIN products pr ON pr.id = pi.product_id
            WHERE pi.pack_id = ?
            ORDER BY pr.sku`,
          pack.id,
        );
        if (items.length === 0) {
          throw tolak(409, `Paket "${pack.nama}" tidak memiliki isi — lengkapi dulu di Master › Paket.`);
        }
        const totalPcs = items.reduce((n, i) => n + Number(i.qty_per_box), 0);
        res.json({ tipe: 'box', barcode, pack: { ...pack, total_pcs: totalPcs, items }, produk: null });
        return;
      }

      // 2) Produk satuan (barcode produk, case-insensitive).
      const pr = get<Record<string, unknown>>(
        `SELECT id AS product_id, sku, barcode, harga_beli, satuan_dasar_id, nama AS produk
           FROM products
          WHERE barcode IS NOT NULL AND lower(barcode) = lower(?) AND deleted_at IS NULL`,
        barcode,
      );
      if (pr) {
        res.json({ tipe: 'satuan', barcode, produk: pr, pack: null });
        return;
      }

      // 3) Tidak dikenal — klien menampilkan dialog pendaftaran.
      res.json({ tipe: 'tidak_dikenal', barcode, pack: null, produk: null });
    }),
  );

  // ==========================================================================
  // Draft (PO opsional): buat / ubah / hapus — TIDAK menggerakkan stok
  // ==========================================================================
  r.post(
    '/',
    asyncHandler((req, res) => {
      const pengguna = penggunaSaatIni(req);
      const body = (req.body ?? {}) as Record<string, unknown>;
      const isi = validasiIsi(body);
      const t = hitungTotal(isi.items, isi.pajak_persen);
      const chatSesi = String(body.chat_sesi ?? '').trim() || null;
      const logsScan = validasiLogScan(body);

      const idBaru = withTransaction(() => {
        const noDok = nomorDokumen('PB');
        const id = Number(
          run(
            `INSERT INTO purchases (no_dokumen, no_po, tanggal, supplier_id, warehouse_id, metode_input,
                                    subtotal, diskon, pajak_persen, pajak, total, status, dibuat_oleh)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?)`,
            noDok,
            isi.no_po,
            isi.tanggal,
            isi.supplier_id,
            isi.warehouse_id,
            isi.metode,
            t.subtotal,
            t.diskon,
            isi.pajak_persen,
            t.pajak,
            t.total,
            pengguna.id,
          ).lastInsertRowid,
        );
        for (const i of isi.items) tulisItem(id, i);
        // Riwayat scan barcode untuk dokumen ini (metode Scan).
        for (const l of logsScan) {
          run(
            `INSERT INTO purchase_scan_logs (purchase_id, barcode, tipe, pack_id, product_id, user_id)
             VALUES (?, ?, ?, ?, ?, ?)`,
            id,
            l.barcode,
            l.tipe,
            l.pack_id,
            l.product_id,
            pengguna.id,
          );
        }
        // Klaim riwayat chat sesi ini ke dokumen (pesan pra-dokumen).
        if (chatSesi) {
          run(
            `UPDATE purchase_chat_logs SET purchase_id = ? WHERE chat_sesi = ? AND purchase_id IS NULL`,
            id,
            chatSesi,
          );
        }
        catatAudit({
          userId: pengguna.id,
          aksi: 'tambah',
          tabel: 'purchases',
          recordId: id,
          sesudah: { no_dokumen: noDok, metode_input: isi.metode, supplier_id: isi.supplier_id, warehouse_id: isi.warehouse_id, items: isi.items.length, total: t.total },
        });
        return id;
      });

      res.status(201).json({ id: idBaru, data: bacaPembelian(idBaru) });
    }),
  );

  r.put(
    '/:id',
    asyncHandler((req, res) => {
      const id = Number(req.params.id);
      const pengguna = penggunaSaatIni(req);
      const lama = get<Record<string, unknown>>(`SELECT * FROM purchases WHERE id = ?`, id);
      if (!lama) throw tolak(404, 'Dokumen pembelian tidak ditemukan.');
      if (lama.status !== 'draft') {
        throw tolak(409, `Hanya draft yang bisa diubah — status saat ini "${lama.status}". Dokumen diterima/disahkan harus dibatalkan dulu.`);
      }
      const isi = validasiIsi((req.body ?? {}) as Record<string, unknown>);
      const t = hitungTotal(isi.items, isi.pajak_persen);

      withTransaction(() => {
        run(
          `UPDATE purchases SET no_po = ?, tanggal = ?, supplier_id = ?, warehouse_id = ?,
                  subtotal = ?, diskon = ?, pajak_persen = ?, pajak = ?, total = ?, diubah_pada = ?
           WHERE id = ?`,
          isi.no_po,
          isi.tanggal,
          isi.supplier_id,
          isi.warehouse_id,
          t.subtotal,
          t.diskon,
          isi.pajak_persen,
          t.pajak,
          t.total,
          new Date().toISOString(),
          id,
        );
        run(`DELETE FROM purchase_items WHERE purchase_id = ?`, id);
        for (const i of isi.items) tulisItem(id, i);
        catatAudit({
          userId: pengguna.id,
          aksi: 'ubah',
          tabel: 'purchases',
          recordId: id,
          sebelum: { no_po: lama.no_po, supplier_id: lama.supplier_id, warehouse_id: lama.warehouse_id, total: lama.total },
          sesudah: { no_po: isi.no_po, supplier_id: isi.supplier_id, warehouse_id: isi.warehouse_id, total: t.total, items: isi.items.length },
        });
      });

      res.json({ ok: true, data: bacaPembelian(id) });
    }),
  );

  r.delete(
    '/:id',
    wajibAdmin,
    asyncHandler((req, res) => {
      const id = Number(req.params.id);
      const pengguna = penggunaSaatIni(req);
      const lama = get<Record<string, unknown>>(`SELECT * FROM purchases WHERE id = ?`, id);
      if (!lama) throw tolak(404, 'Dokumen pembelian tidak ditemukan.');
      if (lama.status !== 'draft') throw tolak(409, 'Hanya draft yang bisa dihapus.');
      withTransaction(() => {
        run(`DELETE FROM purchases WHERE id = ?`, id);
        catatAudit({ userId: pengguna.id, aksi: 'hapus', tabel: 'purchases', recordId: id, sebelum: lama });
      });
      res.json({ ok: true });
    }),
  );

  // ==========================================================================
  // GRN (Penerimaan Barang): draft → diterima. BELUM ada stok/jurnal.
  // ==========================================================================
  r.post(
    '/:id/terima',
    asyncHandler((req, res) => {
      const id = Number(req.params.id);
      const pengguna = penggunaSaatIni(req);
      const body = (req.body ?? {}) as Record<string, unknown>;

      withTransaction(() => {
        const p = get<Record<string, unknown>>(`SELECT * FROM purchases WHERE id = ?`, id);
        if (!p) throw tolak(404, 'Dokumen pembelian tidak ditemukan.');
        if (p.status === 'batal') throw tolak(409, 'Dokumen dibatalkan tidak bisa diterima.');
        if (p.status !== 'draft') throw tolak(409, `Hanya draft yang bisa diterima (GRN) — status saat ini "${p.status}".`);
        const jumlah = Number(
          get<{ n: number }>(`SELECT COUNT(*) AS n FROM purchase_items WHERE purchase_id = ?`, id)?.n ?? 0,
        );
        if (jumlah === 0) throw tolak(400, 'Dokumen tanpa item — lengkapi item sebelum diterima.');

        const noGrn = String(body.no_grn ?? '').trim() || nomorDokumen('GRN');
        if (get<{ id: number }>(`SELECT id FROM purchases WHERE no_grn = ? AND id <> ?`, noGrn, id)) {
          throw tolak(409, `No. GRN "${noGrn}" sudah dipakai dokumen lain.`);
        }

        // Catat penerimaan saja — stok & jurnal baru dibuat saat disahkan.
        const sekarang = new Date().toISOString();
        run(
          `UPDATE purchases SET status = 'diterima', no_grn = ?, diterima_pada = ?, diubah_pada = ? WHERE id = ?`,
          noGrn,
          sekarang,
          sekarang,
          id,
        );
        catatAudit({
          userId: pengguna.id,
          aksi: 'terima',
          tabel: 'purchases',
          recordId: id,
          sebelum: { status: 'draft' },
          sesudah: { status: 'diterima', no_grn: noGrn },
        });
      });

      res.json({ ok: true, data: bacaPembelian(id) });
    }),
  );

  // ==========================================================================
  // Pengesahan (Faktur): stok masuk + kartu stok + jurnal persediaan/utang
  // + baris hutang pemasok — semuanya dalam SATU transaksi.
  // ==========================================================================
  r.post(
    '/:id/sahkan',
    asyncHandler((req, res) => {
      const id = Number(req.params.id);
      const pengguna = penggunaSaatIni(req);
      const body = (req.body ?? {}) as Record<string, unknown>;

      const noFakturMinta = String(body.no_faktur ?? '').trim() || null;
      let jatuhTempo: string | null = null;
      if (body.jatuh_tempo) {
        const d = new Date(String(body.jatuh_tempo));
        if (Number.isNaN(d.getTime())) throw tolak(400, 'Jatuh tempo tidak valid.');
        jatuhTempo = d.toISOString().slice(0, 10);
      }

      let faktur: { id: number; no_faktur: string } | null = null;
      withTransaction(() => {
        const p = get<Record<string, unknown>>(`SELECT * FROM purchases WHERE id = ?`, id);
        if (!p) throw tolak(404, 'Dokumen pembelian tidak ditemukan.');
        if (p.status === 'batal') throw tolak(409, 'Dokumen dibatalkan tidak bisa disahkan.');
        if (p.status !== 'diterima') {
          throw tolak(409, `Hanya dokumen berstatus diterima (GRN) yang bisa disahkan — status saat ini "${p.status}".`);
        }

        const items = all<{ product_id: number; qty: number; unit_id: number | null; subtotal: number; location_id: number | null; satuan_dasar_id: number | null; sku: string; nama_produk: string }>(
          `SELECT i.product_id, i.qty, i.unit_id, i.subtotal, i.location_id, i.sku, i.nama_produk, prod.satuan_dasar_id
           FROM purchase_items i
           JOIN products prod ON prod.id = i.product_id
           WHERE i.purchase_id = ?
           ORDER BY i.id`,
          id,
        );
        if (items.length === 0) throw tolak(400, 'Dokumen tanpa item — tidak bisa disahkan.');

        const noFaktur = noFakturMinta || nomorDokumen('FP');
        if (noFakturMinta && get<{ id: number }>(`SELECT id FROM purchases WHERE no_faktur = ? AND id <> ?`, noFakturMinta, id)) {
          throw tolak(409, `No. faktur "${noFakturMinta}" sudah dipakai dokumen lain.`);
        }

        const lokasi = lokasiGudang(Number(p.warehouse_id));

        // 1) Stok masuk per produk (SATU-JALUR ubahStok → kartu stok ikut).
        for (const it of items) {
          const qtyDasar = konversiKeDasar(it);
          if (!(qtyDasar > 0)) throw tolak(400, `Qty produk ${it.sku} tidak masuk akal setelah konversi satuan.`);
          ubahStok({
            productId: it.product_id,
            warehouseId: Number(p.warehouse_id),
            locationId: it.location_id ?? lokasi,
            masuk: qtyDasar,
            hargaMasuk: qtyDasar > 0 ? Number(it.subtotal) / qtyDasar : undefined,
            tipeDokumen: 'pembelian',
            dokumenId: id,
            userId: pengguna.id,
          });
        }

        // 2) AKUNTANSI DASAR — tanpa jurnal. Pembelian tercatat sebagai hutang
        //    pemasok (di bawah); kas baru bergerak saat pembayaran hutang
        //    dilakukan (otomatis Kas Keluar). Stok sudah diubah di atas.

        // 3) Hutang pemasok (faktur): jatuh tempo dari input atau termin pemasok.
        let tempo = jatuhTempo;
        if (!tempo) {
          const s = get<{ termin_hari: number }>(`SELECT termin_hari FROM suppliers WHERE id = ?`, Number(p.supplier_id));
          const termin = Number(s?.termin_hari ?? 0);
          if (termin > 0) {
            tempo = new Date(Date.now() + termin * 86400000).toISOString().slice(0, 10);
          }
        }
        run(
          `INSERT INTO payables (purchase_id, supplier_id, jatuh_tempo, total, status, dibuat_oleh)
           VALUES (?, ?, ?, ?, 'belum', ?)`,
          id,
          Number(p.supplier_id),
          tempo,
          Number(p.total),
          pengguna.id,
        );

        const sekarang = new Date().toISOString();
        run(
          `UPDATE purchases SET status = 'disahkan', no_faktur = ?, disahkan_pada = ?, diubah_pada = ? WHERE id = ?`,
          noFaktur,
          sekarang,
          sekarang,
          id,
        );
        // BAGIAN I: faktur disusun otomatis saat pengesahan (termasuk dokumen
        // yang lahir dari mode Chatbot) — nomor urut dari Pengaturan.
        const fakturBaru = buatFakturPembelian(id, pengguna.id);
        faktur = fakturBaru;
        catatAudit({
          userId: pengguna.id,
          aksi: 'sahkan',
          tabel: 'purchases',
          recordId: id,
          sebelum: { status: 'diterima' },
          sesudah: {
            status: 'disahkan',
            no_faktur: noFaktur,
            total: p.total,
            faktur_otomatis: fakturBaru?.no_faktur ?? null,
          },
        });
      });

      res.json({ ok: true, data: bacaPembelian(id), faktur: faktur ?? undefined });
    }),
  );

  // ==========================================================================
  // Batal: draft/diterima cukup ubah status; disahkan = balikkan stok +
  // batalkan jurnal & hutang (pola sama void POS).
  // ==========================================================================
  r.post(
    '/:id/batal',
    wajibAdmin,
    asyncHandler((req, res) => {
      const id = Number(req.params.id);
      const pengguna = penggunaSaatIni(req);
      const alasan = String((req.body ?? {}).alasan ?? '').trim() || 'Pembatalan pembelian oleh admin';

      try {
        withTransaction(() => {
          const p = get<Record<string, unknown>>(`SELECT * FROM purchases WHERE id = ?`, id);
          if (!p) throw tolak(404, 'Dokumen pembelian tidak ditemukan.');
          if (p.status === 'batal') throw tolak(409, 'Dokumen sudah dibatalkan.');

          if (p.status === 'disahkan') {
            // 1) Balikkan stok mengikuti jejak kartu stok dokumen ini.
            const gerak = all<{ product_id: number; qty: number }>(
              `SELECT product_id, SUM(qty_masuk) - SUM(qty_keluar) AS qty
               FROM stock_ledger
               WHERE tipe_dokumen IN ('pembelian', 'pembelian_batal') AND dokumen_id = ?
               GROUP BY product_id`,
              id,
            );
            for (const m of gerak) {
              if (m.qty > 0) {
                ubahStok({
                  productId: m.product_id,
                  warehouseId: Number(p.warehouse_id),
                  keluar: m.qty,
                  tipeDokumen: 'pembelian_batal',
                  dokumenId: id,
                  userId: pengguna.id,
                });
              }
            }
            // 2) AKUNTANSI DASAR — tanpa jurnal pembalik. Pembatalan hanya
            //    membalikkan stok (di atas) & menandai hutang → batal.
            run(
              `UPDATE payables SET status = 'batal', diubah_pada = ? WHERE purchase_id = ? AND status <> 'batal'`,
              new Date().toISOString(),
              id,
            );
          }

          run(`UPDATE purchases SET status = 'batal', diubah_pada = ? WHERE id = ?`, new Date().toISOString(), id);
          catatAudit({
            userId: pengguna.id,
            aksi: 'batal',
            tabel: 'purchases',
            recordId: id,
            sebelum: { status: p.status },
            sesudah: { status: 'batal' },
            alasan,
          });
        });
      } catch (err) {
        const { pesan } = pesanKesalahan(err);
        if (pesan.includes('Stok tidak mencukupi')) {
          throw tolak(409, `Pembatalan gagal: stok hasil pembelian sudah terpakai transaksi lain. Selesaikan lewat Opname. (${pesan})`);
        }
        throw err;
      }

      res.json({ ok: true, data: bacaPembelian(id) });
    }),
  );

  return r;
}

/** Qty dalam SATUAN DASAR (konversi unit_conversions bila berbeda). */
function konversiKeDasar(it: { product_id: number; qty: number; unit_id: number | null; satuan_dasar_id: number | null; sku: string }): number {
  if (!it.unit_id || !it.satuan_dasar_id || Number(it.unit_id) === Number(it.satuan_dasar_id)) return Number(it.qty);
  const k = get<{ jumlah_per_satuan_dasar: number }>(
    `SELECT jumlah_per_satuan_dasar FROM unit_conversions WHERE product_id = ? AND unit_id = ?`,
    it.product_id,
    it.unit_id,
  );
  if (!k) throw tolak(400, `Satuan item ${it.sku} belum dikonversi ke satuan dasar — lengkapi di Master › Konversi Satuan.`);
  return Number(it.qty) * Number(k.jumlah_per_satuan_dasar);
}

function tulisItem(purchaseId: number, i: BarisMasuk): void {
  // Snapshot nama & SKU saat transaksi — riwayat tetap utuh walau master berubah.
  const pr = get<{ nama: string; sku: string }>(`SELECT nama, sku FROM products WHERE id = ?`, i.product_id);
  if (!pr) throw tolak(400, 'Produk tidak ditemukan.');
  run(
    `INSERT INTO purchase_items (purchase_id, product_id, nama_produk, sku, qty, unit_id, harga_beli, diskon, subtotal, pack_id, sumber_scan)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    purchaseId,
    i.product_id,
    pr.nama,
    pr.sku,
    i.qty,
    i.unit_id,
    i.harga_beli,
    i.diskon,
    i.qty * i.harga_beli - i.diskon,
    i.pack_id,
    i.sumber_scan,
  );
}
