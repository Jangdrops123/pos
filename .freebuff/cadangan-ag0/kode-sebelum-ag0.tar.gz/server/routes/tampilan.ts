// Preferensi tampilan per pengguna (P3): tema, aksen, sidebar.
// Disimpan di tabel settings (kunci: tema, aksen, sidebar_tampilan) —
// modul login menyusul, jadi preferensi menempel pada pengguna bawaan
// (sama seperti pengaturan dashboard). Nilai dikirim juga oleh klien ke
// localStorage agar pemuatan tanpa kedip.
//
// BAGIAN Y2 — Identitas Aplikasi: satu sumber data untuk nama, tagline,
// judul tab, favicon, warna aksen & latar ikon, varian logo (Siang/Malam/
// Ikon kecil), cakupan (semua toko / per toko), serta opsi pemakaian identitas
// untuk faktur & struk. Semua perubahan dicatat di `audit_logs` dan hanya
// boleh dilakukan Admin/Owner.
import fs from 'node:fs';
import path from 'node:path';
import { Router } from 'express';
import { fileURLToPath } from 'node:url';
import { all, get, run } from '../db.ts';
import { asyncHandler, tolak } from '../lib/http.ts';
import { catatAudit } from '../lib/audit.ts';
import { penggunaSaatIni, wajibAdminIdentitas } from '../lib/akses.ts';

const TEMA = new Set(['terang', 'gelap', 'sistem']);
const AKSEN = new Set(['', 'biru', 'indigo', 'hijau', 'oranye']);
const SIDEBAR = new Set(['gelap', 'terang']);

const baca = (kunci: string, daftar: Set<string>, awal: string): string => {
  const v = get<{ nilai: string }>(`SELECT nilai FROM settings WHERE kunci = ?`, kunci)?.nilai ?? '';
  return daftar.has(v) ? v : awal;
};

const tulis = (kunci: string, nilai: string) =>
  run(
    `INSERT INTO settings (kunci, nilai, diubah_pada) VALUES (?, ?, strftime('%Y-%m-%d %H:%M:%f', 'now'))
     ON CONFLICT(kunci) DO UPDATE SET nilai = excluded.nilai, diubah_pada = excluded.diubah_pada`,
    kunci,
    nilai,
  );

/* ============== X1/Y2 — Identitas aplikasi (nama, tagline, logo) ========= */

const ROOT_DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const LOGO_DIR = path.join(ROOT_DIR, 'data', 'uploads', 'identitas');
const LOGO_MAKS_BYTES = 2 * 1024 * 1024; /* X1.1 / Y2.1 — maks 2 MB */
const LOGO_MIME: Record<string, string> = {
  'image/webp': 'webp',
  'image/jpeg': 'jpg',
  'image/png': 'png',
};
const VARIAN = new Set(['siang', 'malam', 'ikon']);
const LATAR = new Set(['', 'surface', 'surface-2', 'primer-lembut', 'panel']);
const CAKUPAN = new Set(['semua', 'per-toko']);

type KunciLogo = 'app_logo_siang' | 'app_logo_malam' | 'app_logo_ikon';
const KUNCI_VARIAN: Record<string, KunciLogo> = {
  siang: 'app_logo_siang',
  malam: 'app_logo_malam',
  ikon: 'app_logo_ikon',
};

/** Semua kunci identitas yang ikut kebawaan / cakupan per toko. */
const KUNCI_TEKS = [
  'app_nama',
  'app_tagline',
  'app_judul_tab',
  'app_favicon',
  'app_aksen',
  'app_logo_latar',
  'app_pakai_faktur',
] as const;

/** Nilai mentah baris settings — `null` bila baris belum pernah ditulis. */
function bacaMentah(kunci: string): string | null {
  return get<{ nilai: string | null }>(`SELECT nilai FROM settings WHERE kunci = ?`, kunci)?.nilai ?? null;
}

/** Naikkan versi identitas — klien memakai nilai ini untuk cache-busting logo. */
function naikkanVersi(): string {
  const v = Number(bacaMentah('app_identitas_versi') ?? '0') + 1;
  tulis('app_identitas_versi', String(v));
  return String(v);
}

/**
 * Baca satu nilai identitas dengan cakupan: bila mode "per toko" dan kode toko
 * tersedia, baris `@<toko>` menang; baris yang belum pernah ditulis memakai
 * nilai bawaan (baris kosong = pilihan sadar pengguna, tetap dikembalikan).
 */
function ambil(dasar: string, toko: string | null, bawaan = ''): string {
  if (toko) {
    const khusus = bacaMentah(`${dasar}@${toko}`);
    if (khusus !== null) return khusus;
  }
  const umum = bacaMentah(dasar);
  return umum === null ? bawaan : umum;
}

/** Tulis satu nilai identitas sesuai cakupan aktif. */
function simpanKunci(dasar: string, nilai: string, cakupan: string, toko: string | null): void {
  tulis(cakupan === 'per-toko' && toko ? `${dasar}@${toko}` : dasar, nilai);
}

/**
 * Hapus baris identitas agar kembali memakai nilai BAWAAN (penting: baris
 * yang berisi "" berarti "pilihan sadar pengguna", bukan nilai bawaan).
 */
function hapusKunci(dasar: string, cakupan: string, toko: string | null): void {
  run(`DELETE FROM settings WHERE kunci = ?`, cakupan === 'per-toko' && toko ? `${dasar}@${toko}` : dasar);
}

/** Simpan berkas logo (PNG/JPEG/WebP maks 2 MB; SVG sebagai teks UTF-8). */
function simpanLogo(varian: string, body: Record<string, unknown>): string {
  const teks = String(body.data_base64 ?? '').trim();
  fs.mkdirSync(LOGO_DIR, { recursive: true });
  const namaAman = `${varian}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  // SVG — teks murni (Y2.1 mengizinkan SVG).
  const svg = /^data:image\/svg\+xml(;charset=[\w-]+)?,(.*)$/s.exec(teks);
  if (svg) {
    const isi = decodeURIComponent(svg[2]);
    if (Buffer.byteLength(isi, 'utf8') > LOGO_MAKS_BYTES) throw tolak(413, 'Logo melebihi batas 2 MB.');
    if (!/<svg[\s>]/i.test(isi)) throw tolak(400, 'Berkas SVG tidak valid.');
    const namaFile = `${namaAman}.svg`;
    fs.writeFileSync(path.join(LOGO_DIR, namaFile), isi, 'utf8');
    return `/uploads/identitas/${namaFile}`;
  }
  const m = /^data:(image\/(?:webp|jpeg|png));base64,([A-Za-z0-9+/=]+)$/.exec(teks);
  if (!m) throw tolak(400, 'Format logo tidak didukung (PNG, JPG, WebP, atau SVG).');
  const biner = Buffer.from(m[2], 'base64');
  if (biner.length === 0) throw tolak(400, 'Berkas logo kosong.');
  if (biner.length > LOGO_MAKS_BYTES) throw tolak(413, 'Logo melebihi batas 2 MB.');
  const namaFile = `${namaAman}.${LOGO_MIME[m[1]]}`;
  fs.writeFileSync(path.join(LOGO_DIR, namaFile), biner);
  return `/uploads/identitas/${namaFile}`;
}

/** Hapus berkas logo internal (abaikan gagal; cegah path traversal). */
function hapusBerkas(url: string | null): void {
  if (!url || !url.startsWith('/uploads/identitas/')) return;
  const tujuan = path.join(ROOT_DIR, 'data', 'uploads', url.replace(/^\/uploads\//, ''));
  if (!tujuan.startsWith(path.join(ROOT_DIR, 'data', 'uploads'))) return;
  try {
    fs.rmSync(tujuan, { force: true });
  } catch {
    /* file mungkin sudah tidak ada */
  }
}

/** Bentuk identitas untuk klien (+ ?v= versi pada logo internal). */
function bacaIdentitas(toko: string | null = null) {
  const cakupan = bacaMentah('app_cakupan') === 'per-toko' ? 'per-toko' : 'semua';
  const efektif = cakupan === 'per-toko' ? toko : null;
  const versi = bacaMentah('app_identitas_versi') ?? '1';
  const versiUrl = (u: string) => (u.startsWith('/uploads/') ? `${u}?v=${versi}` : u);
  return {
    nama: ambil('app_nama', efektif, 'NusaSuite'),
    tagline: ambil('app_tagline', efektif, 'POS · WMS · Akuntansi'),
    judulTab: ambil('app_judul_tab', efektif),
    favicon: versiUrl(ambil('app_favicon', efektif)),
    aksen: AKSEN.has(ambil('app_aksen', efektif)) ? ambil('app_aksen', efektif) : '',
    logoSiang: versiUrl(ambil('app_logo_siang', efektif)),
    logoMalam: versiUrl(ambil('app_logo_malam', efektif)),
    ikon: versiUrl(ambil('app_logo_ikon', efektif)),
    latar: LATAR.has(ambil('app_logo_latar', efektif)) ? ambil('app_logo_latar', efektif) : '',
    pakaiFaktur: ambil('app_pakai_faktur', efektif) === 'true',
    cakupan,
    toko: efektif,
    versi,
  };
}

type Identitas = ReturnType<typeof bacaIdentitas>;

/** URL logo faktur (tanpa ?v=) yang dipakai saat opsi "juga untuk faktur" aktif. */
function logoFaktur(i: Identitas): string {
  const bersih = (u: string) => (u.startsWith('/uploads/') ? u.split('?')[0] : u);
  return bersih(i.logoSiang) || bersih(i.logoMalam) || bersih(i.ikon);
}

/**
 * Y2.2 — opsi "Pakai logo dan nama ini juga untuk faktur dan struk".
 * Saat dicentang, nama_usaha & logo_usaha (Profil Usaha → kop faktur/struk)
 * disalin dari identitas; nilai sebelumnya disimpan agar saat dicentang lagi
 * nilainya tidak hilang. Saat dilepas, snapshot dipulihkan → logo faktur
 * kembali terpisah.
 */
function sinkronFaktur(pakai: boolean, i: Identitas): void {
  const kunciSnapshot = 'app_faktur_snapshot';
  const lama = bacaMentah(kunciSnapshot);
  if (pakai) {
    if (!lama) {
      tulis(
        kunciSnapshot,
        JSON.stringify({
          nama: bacaMentah('nama_usaha') ?? '',
          logo: bacaMentah('logo_usaha') ?? '',
        }),
      );
    }
    tulis('nama_usaha', i.nama);
    tulis('logo_usaha', logoFaktur(i));
    return;
  }
  if (!lama) return;
  try {
    const s = JSON.parse(lama) as { nama?: unknown; logo?: unknown };
    tulis('nama_usaha', String(s.nama ?? ''));
    tulis('logo_usaha', String(s.logo ?? ''));
  } catch {
    /* snapshot rusak — biarkan nilai sekarang */
  }
  tulis(kunciSnapshot, '');
}

/** Salin ulang logo ke Profil Usaha bila opsi faktur sedang aktif. */
function sinkronLogoFaktur(toko: string | null): void {
  const id = bacaIdentitas(toko);
  if (!id.pakaiFaktur) return;
  tulis('logo_usaha', logoFaktur(id));
}

/** Validasi & ambil teks dari body. */
function teksBody(body: Record<string, unknown>, kunci: string, maks: number): string {
  return String(body[kunci] ?? '').trim().slice(0, maks);
}

export function routerTampilan(): Router {
  const r = Router();

  r.get(
    '/tampilan',
    asyncHandler((_req, res) => {
      res.json({
        tema: baca('tema', TEMA, 'sistem'),
        aksen: baca('aksen', AKSEN, ''),
        sidebar: baca('sidebar_tampilan', SIDEBAR, 'gelap'),
      });
    }),
  );

  r.put(
    '/tampilan',
    asyncHandler((req, res) => {
      const body = (req.body ?? {}) as Record<string, unknown>;
      const tema = String(body.tema ?? '');
      const aksen = String(body.aksen ?? '');
      const sidebar = String(body.sidebar ?? '');
      if (!TEMA.has(tema)) throw tolak(400, 'Tema tidak dikenal (terang/gelap/sistem).');
      if (!AKSEN.has(aksen)) throw tolak(400, 'Aksen tidak dikenal (biru/indigo/hijau/oranye).');
      if (!SIDEBAR.has(sidebar)) throw tolak(400, 'Sidebar tidak dikenal (gelap/terang).');
      tulis('tema', tema);
      tulis('aksen', aksen);
      tulis('sidebar_tampilan', sidebar);
      res.json({ ok: true, tema, aksen, sidebar });
    }),
  );

  /* ------------------- Y2 — Identitas Aplikasi -------------------------- */

  /**
   * Baca identitas. Publik (sidebar & layar muat membacanya), tetapi nilai
   * per toko hanya dikembalikan bila `?toko=` diberikan — klien mengirim kode
   * toko aktif sehingga perubahan langsung terlihat tanpa muat ulang.
   */
  r.get(
    '/tampilan/identitas',
    asyncHandler((req, res) => {
      const toko = String(req.query.toko ?? '').trim() || null;
      res.json(bacaIdentitas(toko));
    }),
  );

  /** Data pendukung halaman Identitas Aplikasi (hanya Admin/Owner). */
  r.get(
    '/tampilan/identitas/meta',
    wajibAdminIdentitas,
    asyncHandler((_req, res) => {
      const toko = all<{ kode: string; nama: string }>(
        'SELECT kode, nama FROM stores WHERE aktif = 1 ORDER BY nama',
      ).map((t) => ({ nilai: t.kode, label: `${t.nama} (${t.kode})` }));
      res.json({
        multiToko: toko.length > 1,
        toko,
        cakupan: bacaMentah('app_cakupan') === 'per-toko' ? 'per-toko' : 'semua',
        pakaiFaktur: bacaMentah('app_pakai_faktur') === 'true',
        namaUsaha: bacaMentah('nama_usaha') ?? '',
        logoUsaha: bacaMentah('logo_usaha') ?? '',
      });
    }),
  );

  // Nama, tagline, judul tab, favicon, aksen, latar ikon, cakupan, opsi faktur.
  r.put(
    '/tampilan/identitas',
    wajibAdminIdentitas,
    asyncHandler((req, res) => {
      const pengguna = penggunaSaatIni(req);
      const body = (req.body ?? {}) as Record<string, unknown>;

      const nama = teksBody(body, 'nama', 60);
      if (!nama) throw tolak(400, 'Nama aplikasi tidak boleh kosong.');
      const tagline = teksBody(body, 'tagline', 80);
      const judulTab = teksBody(body, 'judulTab', 80);
      const favicon = teksBody(body, 'favicon', 240);
      if (favicon && !favicon.startsWith('/')) {
        throw tolak(400, 'Favicon harus berupa jalur berkas internal (diawali "/").');
      }
      const aksen = String(body.aksen ?? '');
      if (!AKSEN.has(aksen)) throw tolak(400, 'Warna aksen aplikasi tidak dikenal.');
      const latar = String(body.latar ?? '');
      if (!LATAR.has(latar)) throw tolak(400, 'Warna latar ikon tidak dikenal.');
      const cakupan = String(body.cakupan ?? 'semua');
      if (!CAKUPAN.has(cakupan)) throw tolak(400, 'Cakupan tidak dikenal (semua / per-toko).');
      const toko = String(body.toko ?? '').trim() || null;
      if (cakupan === 'per-toko' && !toko) {
        throw tolak(400, 'Cakupan "Berbeda per toko" membutuhkan toko aktif.');
      }
      if (toko && !all('SELECT id FROM stores WHERE kode = ?', toko).length) {
        throw tolak(404, `Toko "${toko}" tidak ditemukan.`);
      }
      const pakaiFaktur = body.pakaiFaktur === true || body.pakaiFaktur === 'true';
      const target = cakupan === 'per-toko' ? toko : null;

      const sebelum = bacaIdentitas(target);

      tulis('app_cakupan', cakupan);
      simpanKunci('app_nama', nama, cakupan, target);
      simpanKunci('app_tagline', tagline, cakupan, target);
      simpanKunci('app_judul_tab', judulTab, cakupan, target);
      simpanKunci('app_favicon', favicon, cakupan, target);
      simpanKunci('app_aksen', aksen, cakupan, target);
      simpanKunci('app_logo_latar', latar, cakupan, target);
      simpanKunci('app_pakai_faktur', pakaiFaktur ? 'true' : 'false', cakupan, target);

      // Versi dinaikkan lebih dulu supaya balasan & cache klien langsung
      // memakai nomor versi baru (logo lama tidak pernah tersaji ulang).
      naikkanVersi();
      const sesudah = bacaIdentitas(target);
      sinkronFaktur(pakaiFaktur, sesudah);

      catatAudit({
        userId: pengguna.id,
        aksi: 'ubah',
        tabel: 'settings',
        recordId: cakupan === 'per-toko' ? `app_identitas@${toko}` : 'app_identitas',
        sebelum: { nama: sebelum.nama, tagline: sebelum.tagline, judulTab: sebelum.judulTab, aksen: sebelum.aksen, latar: sebelum.latar, cakupan: sebelum.cakupan, pakaiFaktur: sebelum.pakaiFaktur },
        sesudah: { nama, tagline, judulTab, aksen, latar, cakupan, pakaiFaktur },
        alasan: 'Pengaturan ▸ Identitas Aplikasi',
      });
      res.json(sesudah);
    }),
  );

  // Unggah logo (siang/malam/ikon) — disimpan ke /uploads/identitas (Y2.1).
  r.post(
    '/tampilan/identitas/logo',
    wajibAdminIdentitas,
    asyncHandler((req, res) => {
      const pengguna = penggunaSaatIni(req);
      const body = (req.body ?? {}) as Record<string, unknown>;
      const varian = String(body.varian ?? '');
      if (!VARIAN.has(varian)) throw tolak(400, 'Varian logo tidak dikenal (siang/malam/ikon).');
      const toko = String(body.toko ?? '').trim() || null;
      const cakupan = bacaMentah('app_cakupan') === 'per-toko' ? 'per-toko' : 'semua';
      if (cakupan === 'per-toko' && !toko) throw tolak(400, 'Pilih toko aktif terlebih dahulu.');
      const kunci = KUNCI_VARIAN[varian];
      const efektif = cakupan === 'per-toko' ? toko : null;
      const kunciTulis = efektif ? `${kunci}@${efektif}` : kunci;
      const url = simpanLogo(varian, body);
      const lama = bacaMentah(kunciTulis) ?? '';
      // Berkas lama tidak lagi dirujuk — hapus agar tidak menumpuk (Y2.1).
      hapusBerkas(lama || null);
      tulis(kunciTulis, url);
      const versi = naikkanVersi();
      sinkronLogoFaktur(efektif);
      catatAudit({
        userId: pengguna.id,
        aksi: 'ubah',
        tabel: 'settings',
        recordId: kunciTulis,
        sebelum: { url: lama },
        sesudah: { url },
        alasan: 'Pengaturan ▸ Identitas Aplikasi',
      });
      res.json({ ok: true, url: url.startsWith('/uploads/') ? `${url}?v=${versi}` : url, versi });
    }),
  );

  // Kembali ke logo bawaan (Y2.1 — tombol Hapus).
  r.post(
    '/tampilan/identitas/logo/hapus',
    wajibAdminIdentitas,
    asyncHandler((req, res) => {
      const pengguna = penggunaSaatIni(req);
      const body = (req.body ?? {}) as Record<string, unknown>;
      const varian = String(body.varian ?? '');
      if (!VARIAN.has(varian)) throw tolak(400, 'Varian logo tidak dikenal (siang/malam/ikon).');
      const toko = String(body.toko ?? '').trim() || null;
      const cakupan = bacaMentah('app_cakupan') === 'per-toko' ? 'per-toko' : 'semua';
      const efektif = cakupan === 'per-toko' ? toko : null;
      const kunci = KUNCI_VARIAN[varian];
      const kunciTulis = efektif ? `${kunci}@${efektif}` : kunci;
      const lama = bacaMentah(kunciTulis) ?? '';
      hapusBerkas(lama || null);
      tulis(kunciTulis, '');
      const versi = naikkanVersi();
      sinkronLogoFaktur(efektif);
      catatAudit({
        userId: pengguna.id,
        aksi: 'hapus',
        tabel: 'settings',
        recordId: kunciTulis,
        sebelum: { url: lama },
        sesudah: { url: '' },
        alasan: 'Pengaturan ▸ Identitas Aplikasi',
      });
      res.json({ ok: true, versi });
    }),
  );

  // Y2.1 — "Kembalikan bawaan": seluruh identitas kembali ke nilai bawaan.
  r.post(
    '/tampilan/identitas/bawaan',
    wajibAdminIdentitas,
    asyncHandler((req, res) => {
      const pengguna = penggunaSaatIni(req);
      const body = (req.body ?? {}) as Record<string, unknown>;
      const toko = String(body.toko ?? '').trim() || null;
      const cakupan = bacaMentah('app_cakupan') === 'per-toko' ? 'per-toko' : 'semua';
      const efektif = cakupan === 'per-toko' ? toko : null;
      const sebelum = bacaIdentitas(efektif);

      // Logo ikut dihapus (file fisik) agar bersih — hanya varian cakupan ini.
      for (const v of ['siang', 'malam', 'ikon'] as const) {
        const kunci =
          cakupan === 'per-toko' && efektif ? `${KUNCI_VARIAN[v]}@${efektif}` : KUNCI_VARIAN[v];
        hapusBerkas(bacaMentah(kunci) || null);
        hapusKunci(KUNCI_VARIAN[v], cakupan, efektif);
      }
      for (const k of KUNCI_TEKS) hapusKunci(k, cakupan, efektif);
      if (efektif === null) hapusKunci('app_cakupan', 'semua', null);

      naikkanVersi();
      const sesudah = bacaIdentitas(efektif);
      sinkronFaktur(false, sesudah);
      const versi = sesudah.versi;

      catatAudit({
        userId: pengguna.id,
        aksi: 'pulihkan',
        tabel: 'settings',
        recordId: efektif ? `app_identitas@${efektif}` : 'app_identitas',
        sebelum: { nama: sebelum.nama, tagline: sebelum.tagline },
        sesudah: { nama: sesudah.nama, tagline: sesudah.tagline },
        alasan: 'Pengaturan ▸ Identitas Aplikasi — kembalikan bawaan',
      });
      res.json({ ok: true, versi, identitas: sesudah });
    }),
  );

  return r;
}
