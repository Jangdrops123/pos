// Pengaturan ▸ API — daftar tab, baca/tulis nilai, kembalikan ke bawaan,
// dan Log Aktivitas. Semua perubahan dicatat di `audit_logs`
// (siapa, kapan, sebelum/sesudah).
import express, { Router } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { all, get, getSettings, run, withTransaction } from '../db.ts';
import { PERAN_ADMIN, penggunaSaatIni, peranDariHeader } from '../lib/akses.ts';
import type { RequestHandler } from 'express';
import { asyncHandler, tolak } from '../lib/http.ts';
import {
  LOKASI_BACKUP,
  buatBackup,
  daftarBackup,
  infoSistem,
  pathBackup,
  periksaPembaruan,
  pulihkanBackup,
} from '../lib/sistem.ts';
import { cocokKataSandi } from '../lib/prosesTahunan.ts';
import { JENIS_RESET, jalankanReset, ringkasanReset, type JenisReset } from '../lib/resetData.ts';
import { ENTITAS } from './master/konfigurasi.ts';
import { catatAudit } from '../lib/audit.ts';
import {
  GRUP,
  JENIS_NOMOR,
  KARTU_DASHBOARD_PENGATURAN,
  TAB_PENGATURAN,
  bacaTab,
  bawaanTab,
  cariTab,
  konfigNomor,
  pratinjauNomor,
  prefixNomor,
  resetTab,
  tulisTab,
  validasi,
  type Perubahan,
} from '../lib/pengaturanBaru.ts';

interface BarisToko {
  id: number;
  kode: string;
  nama: string;
  alamat: string | null;
  telepon: string | null;
  email: string | null;
  logo: string | null;
  warehouse_id: number | null;
  gudang_nama: string | null;
  aktif: number;
}

function catatPerubahan(
  req: Parameters<typeof penggunaSaatIni>[0],
  tabKode: string,
  tabLabel: string,
  toko: string | null,
  daftar: Perubahan[],
  aksi: 'ubah' | 'pulihkan',
): void {
  if (!daftar.length) return;
  const pengguna = penggunaSaatIni(req);
  catatAudit({
    userId: pengguna.id,
    aksi,
    tabel: 'pengaturan',
    recordId: toko ? `${tabKode}@${toko}` : tabKode,
    sebelum: Object.fromEntries(daftar.map((p) => [p.kunci, p.sebelum])),
    sesudah: Object.fromEntries(daftar.map((p) => [p.kunci, p.sesudah])),
    alasan: `Pengaturan ▸ ${tabLabel}${toko ? ` (toko ${toko})` : ''}`,
  });
}

/**
 * Hak akses tab Pengaturan.
 *
 * Hanya Admin yang boleh membuka Pengaturan. Admin dapat memberi izin peran
 * lain per tab (mis. Manajer ke Penomoran & Pajak) lewat baris settings
 * `peng.akses.<kode-tab>` berisi daftar peran — endpoint
 * `PUT /pengguna/akses/:tab`.
 *
 * Peran aktif diambil dari header `x-peran` (dikirim klien dari Pengaturan,
 * sama seperti guard modul Akuntansi) sehingga matriks ini benar-benar
 * dijalankan dan bisa diuji. Saat modul login ada, ganti dengan baca sesi —
 * seluruh pemanggil izinTab tidak berubah.
 */
const PERAN_DIKENAL_PENGATURAN = new Set(['admin', 'owner', 'administrator', 'manajer', 'akuntan', 'kasir', 'gudang']);

/** Peran Admin: `admin` (dikirim klien) maupun owner/administrator (sesi). */
const adalahPeranAdmin = (peran: string): boolean => PERAN_ADMIN.has(peran) || peran === 'admin';

export function izinTab(req: Parameters<typeof penggunaSaatIni>[0], kodeTab: string): boolean {
  const peran = peranDariHeader(req);
  if (adalahPeranAdmin(peran)) return true;
  // Y2.1 / Y2.6 — Identitas Aplikasi selalu dan hanya untuk Admin/Owner,
  // tidak bisa diberi izin lewat matriks Hak Akses.
  if (kodeTab === 'identitas-aplikasi') return false;
  const mentah = get<{ nilai: string | null }>('SELECT nilai FROM settings WHERE kunci = ?', `peng.akses.${kodeTab}`)?.nilai;
  if (!mentah) return false;
  try {
    const daftar = JSON.parse(mentah) as unknown;
    if (!Array.isArray(daftar)) return false;
    // Hanya peran yang dikenal sistem yang bisa diberi izin.
    return daftar.some((x) => {
      const p = String(x).toLowerCase().trim();
      return p === peran && PERAN_DIKENAL_PENGATURAN.has(p);
    });
  } catch {
    return false;
  }
}

/**
 * Baris log aktivitas untuk tab Log Aktivitas.
 *
 * Sengaja mencakup SEMUA tabel (bukan hanya `pengaturan`) agar modul lain
 * (produk, transaksi, jurnal, toko) ikut terlihat — sesuai kebutuhan tab
 * "Log Aktivitas" yang memfilter pengguna, modul, dan tanggal.
 */
export interface BarisLog {
  id: number;
  waktu: string;
  aksi: string;
  tab: string;
  alasan: string | null;
  oleh: string;
  sebelum: Record<string, unknown> | null;
  sesudah: Record<string, unknown> | null;
}

/** Tabel yang pernah muncul di log — dipakai sebagai pilihan filter modul. */
function daftarModulLog(): string[] {
  const rows = all<{ tabel: string }>(
    'SELECT DISTINCT tabel FROM audit_logs ORDER BY tabel',
  ).map((r) => r.tabel);
  return rows.includes('stores') ? ['stores', ...rows.filter((t) => t !== 'stores')] : rows;
}

function parseJson(s: string | null): Record<string, unknown> | null {
  if (!s) return null;
  try {
    return JSON.parse(s) as Record<string, unknown>;
  } catch {
    return null;
  }
}

function bacaLogAktivitas(
  req: Parameters<typeof penggunaSaatIni>[0],
  batas: number,
  saring?: { pengguna?: string; modul?: string; dari?: string; sampai?: string },
): { baris: BarisLog[] } {
  // Modul login menyusul — bila user_id kosong, tampilkan peran aktif dari
  // permintaan agar kolom "siapa" tetap terisi.
  const namaPengguna = penggunaSaatIni(req).nama;
  const where: string[] = [];
  const arg: (string | number)[] = [];

  const pengguna = saring?.pengguna?.trim();
  if (pengguna) {
    where.push("(u.nama LIKE ? OR (u.nama IS NULL AND ? = 'lainnya'))");
    arg.push(`%${pengguna}%`, pengguna);
  }
  const modul = saring?.modul?.trim();
  if (modul && modul !== 'semua') {
    where.push('l.tabel = ?');
    arg.push(modul);
  }
  const dari = saring?.dari?.trim();
  if (dari) {
    where.push('l.waktu >= ?');
    arg.push(`${dari} 00:00:00`);
  }
  const sampai = saring?.sampai?.trim();
  if (sampai) {
    where.push('l.waktu <= ?');
    arg.push(`${sampai} 23:59:59`);
  }

  const rows = all<{
    id: number; waktu: string; aksi: string; tabel: string; record_id: string | null;
    data_sebelum: string | null; data_sesudah: string | null; alasan: string | null; nama: string | null;
  }>(
    `SELECT l.id, l.waktu, l.aksi, l.tabel, l.record_id, l.data_sebelum, l.data_sesudah, l.alasan, u.nama
       FROM audit_logs l LEFT JOIN users u ON u.id = l.user_id
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY l.id DESC LIMIT ?`,
    ...arg,
    batas,
  );

  return {
    baris: rows.map((x) => ({
      id: x.id,
      waktu: x.waktu,
      aksi: x.aksi,
      tab: x.tabel,
      alasan: x.alasan,
      oleh: x.nama ?? namaPengguna,
      sebelum: parseJson(x.data_sebelum),
      sesudah: parseJson(x.data_sesudah),
    })),
  };
}

/**
 * Guard untuk endpoint data satu tab (info, cadangan, riwayat, ekspor, ...).
 * Boleh: Admin, ATAU peran yang diberi izin Admin pada SALAH SATU tab yang
 * disebut — jadi tab yang dibuka non-Admin benar-benar bisa dipakai.
 */
const wajibIzinTabInfo = (...kodeTab: string[]): RequestHandler => (req, _res, next) => {
  if (kodeTab.some((k) => izinTab(req, k))) return next();
  next(
    tolak(
      403,
      `Endpoint ini hanya untuk Admin (atau peran yang diizinkan Admin pada tab ${kodeTab.join(' / ')}). ` +
        'Minta Admin memberi izin pada Pengguna & Hak Akses.',
    ),
  );
};

/**
 * Reset Data (Database & Backup) — hanya Admin utama.
 *
 * Izin tab saja tidak cukup: Admin boleh memberi izin tab Database pada peran
 * lain, tetapi menghapus seluruh data tetap hak Admin utama. Peran aktif dibaca
 * dari header `x-peran` (sama seperti guard Akuntansi) — saat modul login ada,
 * ganti dengan baca sesi; seluruh pemanggil tidak berubah.
 */
const wajibAdminUtama: RequestHandler = (req, _res, next) => {
  if (!adalahPeranAdmin(peranDariHeader(req))) {
    next(tolak(403, 'Reset Data hanya untuk Admin utama.'));
    return;
  }
  next();
};

/** Tolak permintaan bila peran aktif tidak punya izin membuka tab ini. */
const wajibIzinTab: RequestHandler = (req, _res, next) => {
  const kode = String(req.params.tab ?? '');
  if (!TAB_PENGATURAN.some((t) => t.kode === kode)) return next();
  if (!izinTab(req, kode)) {
    next(tolak(403, 'Pengaturan hanya untuk Admin. Minta Admin memberi izin tab ini pada Pengguna & Hak Akses.'));
    return;
  }
  next();
};

export function routerPengaturan(): Router {
  const r = Router();

  /* --------------------------- DAFTAR TAB -------------------------------- */

  r.get(
    '/daftar',
    asyncHandler((req, res) => {
      res.json({
        grup: GRUP,
        kartu: KARTU_DASHBOARD_PENGATURAN,
        jenisNomor: JENIS_NOMOR.map((j) => ({
          kode: j.kode,
          label: j.label,
          prefix: prefixNomor(j.kode),
          contoh: pratinjauNomor(j.kode),
          konfig: konfigNomor(j.kode),
        })),
        tab: TAB_PENGATURAN.map((t) => ({
          kode: t.kode,
          grup: t.grup,
          label: t.label,
          ket: t.ket ?? null,
          cakupan: t.cakupan,
          kustom: t.kustom ?? null,
          informatif: Boolean(t.informatif),
          dampak: t.dampak ?? null,
          // Izin per tab untuk peran aktif — dipakai navigasi kiri agar peran
          // non-Admin hanya melihat tab yang diizinkan Admin padanya.
          boleh: izinTab(req, t.kode),
          bidang: t.bidang.map((b) => ({
            kunci: b.kunci,
            label: b.label,
            tipe: b.tipe,
            opsi: b.opsi ?? null,
            ket: b.ket ?? null,
            satuan: b.satuan ?? null,
            min: b.min ?? null,
            max: b.max ?? null,
            wajib: Boolean(b.wajib),
            cakupan: b.cakupan ?? t.cakupan,
            opsiUrl: b.opsiUrl ?? null,
            pratinjau: Boolean(b.pratinjau),
            dampak: b.dampak ?? null,
            ke: b.ke ?? null,
            nonaktif: b.nonaktif ?? null,
          })),
        })),
      });
    }),
  );

  /* --------------------------- LOG AKTIVITAS ----------------------------- */

  r.get(
    '/log/aktivitas',
    wajibIzinTabInfo('log-aktivitas'),
    asyncHandler((req, res) => {
      const limit = Math.min(2000, Math.max(1, Number.parseInt(String(req.query.per ?? '100'), 10) || 100));
      const { baris } = bacaLogAktivitas(req, limit, {
        pengguna: String(req.query.pengguna ?? ''),
        modul: String(req.query.modul ?? ''),
        dari: String(req.query.dari ?? ''),
        sampai: String(req.query.sampai ?? ''),
      });
      res.json({ data: baris, modul: daftarModulLog() });
    }),
  );

  /* ------------------------------ TOKO ----------------------------------- */

  r.get(
    '/toko/opsi',
    asyncHandler((_req, res) => {
      const rows = all<{ id: number; kode: string; nama: string }>(
        'SELECT id, kode, nama FROM stores WHERE aktif = 1 ORDER BY nama',
      );
      res.json({ data: rows.map((t) => ({ id: t.id, nilai: t.kode, label: `${t.nama} (${t.kode})` })) });
    }),
  );

  r.get(
    '/toko',
    asyncHandler((_req, res) => {
      const rows = all<BarisToko>(
        `SELECT s.*, w.nama AS gudang_nama
           FROM stores s LEFT JOIN warehouses w ON w.id = s.warehouse_id
          ORDER BY s.nama`,
      );
      res.json({ data: rows, gudang: all('SELECT id, kode, nama FROM warehouses ORDER BY nama') });
    }),
  );

  const bacaToko = (body: Record<string, unknown>): { kode: string; nama: string; alamat: string | null; telepon: string | null; email: string | null; logo: string | null; warehouse_id: number | null; aktif: boolean } => {
    const kode = String(body.kode ?? '').trim().toUpperCase();
    const nama = String(body.nama ?? '').trim();
    if (!kode) throw tolak(400, 'Kode toko wajib diisi.');
    if (kode.length > 20) throw tolak(400, 'Kode toko maksimal 20 karakter.');
    if (!nama) throw tolak(400, 'Nama toko wajib diisi.');
    if (nama.length > 120) throw tolak(400, 'Nama toko maksimal 120 karakter.');
    const teks = (k: string): string | null => {
      const v = String(body[k] ?? '').trim();
      return v ? v.slice(0, 400) : null;
    };
    const wid = body.warehouse_id === null || body.warehouse_id === undefined || body.warehouse_id === ''
      ? null
      : Number(body.warehouse_id);
    if (wid !== null && !Number.isInteger(wid)) throw tolak(400, 'Gudang tidak valid.');
    return {
      kode, nama,
      alamat: teks('alamat'), telepon: teks('telepon'), email: teks('email'), logo: teks('logo'),
      warehouse_id: wid,
      aktif: body.aktif === undefined ? true : Boolean(body.aktif),
    };
  };

  r.post(
    '/toko',
    wajibIzinTabInfo('toko-gudang'),
    asyncHandler((req, res) => {
      const t = bacaToko((req.body ?? {}) as Record<string, unknown>);
      const pengguna = penggunaSaatIni(req);
      const id = withTransaction(() => {
        const hasil = run(
          `INSERT INTO stores (kode, nama, alamat, telepon, email, logo, warehouse_id, aktif)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          t.kode, t.nama, t.alamat, t.telepon, t.email, t.logo, t.warehouse_id, t.aktif ? 1 : 0,
        );
        const idBaru = Number(hasil.lastInsertRowid);
        catatAudit({
          userId: pengguna.id, aksi: 'tambah', tabel: 'stores', recordId: idBaru,
          sesudah: { kode: t.kode, nama: t.nama, alamat: t.alamat, telepon: t.telepon, gudang_id: t.warehouse_id },
        });
        return idBaru;
      });
      res.status(201).json({ id, pesan: `Toko "${t.nama}" ditambahkan.` });
    }),
  );

  r.put(
    '/toko/:id',
    wajibIzinTabInfo('toko-gudang'),
    asyncHandler((req, res) => {
      const id = Number(req.params.id);
      const lama = all<Record<string, unknown>>('SELECT * FROM stores WHERE id = ?', id)[0];
      if (!lama) throw tolak(404, 'Toko tidak ditemukan.');
      const t = bacaToko((req.body ?? {}) as Record<string, unknown>);
      const pengguna = penggunaSaatIni(req);
      withTransaction(() => {
        run(
          `UPDATE stores SET kode = ?, nama = ?, alamat = ?, telepon = ?, email = ?, logo = ?,
                            warehouse_id = ?, aktif = ? WHERE id = ?`,
          t.kode, t.nama, t.alamat, t.telepon, t.email, t.logo, t.warehouse_id, t.aktif ? 1 : 0, id,
        );
        catatAudit({
          userId: pengguna.id, aksi: 'ubah', tabel: 'stores', recordId: id,
          sebelum: { kode: lama.kode, nama: lama.nama, alamat: lama.alamat, telepon: lama.telepon, gudang_id: lama.warehouse_id },
          sesudah: { kode: t.kode, nama: t.nama, alamat: t.alamat, telepon: t.telepon, gudang_id: t.warehouse_id },
        });
      });
      res.json({ pesan: 'Toko diperbarui.' });
    }),
  );

  r.delete(
    '/toko/:id',
    wajibIzinTabInfo('toko-gudang'),
    asyncHandler((req, res) => {
      const id = Number(req.params.id);
      const lama = all<Record<string, unknown>>('SELECT * FROM stores WHERE id = ?', id)[0];
      if (!lama) throw tolak(404, 'Toko tidak ditemukan.');
      const dipakai = all<{ n: number }>(
        `SELECT (SELECT COUNT(*) FROM stock_balances WHERE warehouse_id = w.id AND qty <> 0) AS n
           FROM warehouses w WHERE w.id = ?`,
        lama.warehouse_id ?? -1,
      )[0];
      if (dipakai && dipakai.n > 0) {
        throw tolak(409, 'Gudang toko ini masih memuat stok — pindahkan atau opname dulu sebelum menghapus toko.');
      }
      const pengguna = penggunaSaatIni(req);
      withTransaction(() => {
        run('DELETE FROM stores WHERE id = ?', id);
        // Pengaturan per toko ikut dibersihkan.
        run(`DELETE FROM settings WHERE kunci LIKE 'peng.%@' || ?`, String(lama.kode));
        catatAudit({
          userId: pengguna.id, aksi: 'hapus', tabel: 'stores', recordId: id,
          sebelum: { kode: lama.kode, nama: lama.nama },
        });
      });
      res.json({ pesan: 'Toko dihapus.' });
    }),
  );

  /* --------------------------- BACA / TULIS TAB --------------------------- */

  r.get(
    '/:tab',
    wajibIzinTab,
    asyncHandler((req, res) => {
      const tab = cariTab(String(req.params.tab));
      const toko = tab.cakupan === 'toko' ? String(req.query.toko ?? '').trim() || null : null;
      res.json({
        tab: tab.kode,
        label: tab.label,
        cakupan: tab.cakupan,
        toko,
        nilai: bacaTab(tab, toko),
        bawaan: bawaanTab(tab),
      });
    }),
  );

  r.put(
    '/:tab',
    wajibIzinTab,
    asyncHandler((req, res) => {
      const tab = cariTab(String(req.params.tab));
      const toko = tab.cakupan === 'toko' ? String(req.query.toko ?? '').trim() || null : null;
      if (tab.cakupan === 'toko' && !toko) throw tolak(400, 'Pilih toko terlebih dahulu.');
      if (toko && !all('SELECT id FROM stores WHERE kode = ?', toko).length) {
        throw tolak(404, `Toko "${toko}" tidak ditemukan.`);
      }
      const body = (req.body ?? {}) as { nilai?: unknown };
      if (!body.nilai || typeof body.nilai !== 'object') throw tolak(400, 'Data nilai tidak ditemukan.');
      const nilai = body.nilai as Record<string, unknown>;
      validasi(tab, nilai);
      const daftar = tulisTab(tab, nilai, toko);
      catatPerubahan(req, tab.kode, tab.label, toko, daftar, 'ubah');
      res.json({ pesan: daftar.length ? `${daftar.length} pengaturan disimpan.` : 'Tidak ada perubahan.', jumlah: daftar.length });
    }),
  );

  r.post(
    '/:tab/bawaan',
    wajibIzinTab,
    asyncHandler((req, res) => {
      const tab = cariTab(String(req.params.tab));
      const toko = tab.cakupan === 'toko' ? String(req.body?.toko ?? req.query.toko ?? '').trim() || null : null;
      if (tab.cakupan === 'toko' && !toko) throw tolak(400, 'Pilih toko terlebih dahulu.');
      const daftar = resetTab(tab, toko);
      catatPerubahan(req, tab.kode, tab.label, toko, daftar, 'pulihkan');
      res.json({
        pesan: daftar.length ? `${daftar.length} pengaturan dikembalikan ke bawaan.` : 'Sudah memakai nilai bawaan.',
        jumlah: daftar.length,
      });
    }),
  );

  /* ================== SISTEM: INFO, CADANGAN, PEMULIHAN ================= */

  r.get(
    '/sistem/info',
    wajibIzinTabInfo('database', 'tentang'),
    asyncHandler((_req, res) => {
      res.json({ ...infoSistem(), cadangan: daftarBackup() });
    }),
  );

  r.post(
    '/sistem/backup',
    wajibIzinTabInfo('database'),
    asyncHandler((req, res) => {
      const pengguna = penggunaSaatIni(req);
      const alasan = String(req.body?.alasan ?? 'cadangan manual').slice(0, 120);
      const nama = buatBackup(alasan);
      catatAudit({
        userId: pengguna.id, aksi: 'tambah', tabel: 'pengaturan', recordId: 'database',
        sesudah: { cadangan: nama, alasan },
      });
      res.status(201).json({ nama, pesan: `Cadangan ${nama} berhasil dibuat.` });
    }),
  );

  r.get(
    '/sistem/backup/unduh',
    wajibIzinTabInfo('database'),
    asyncHandler((req, res) => {
      const nama = String(req.query.nama ?? '');
      const p = pathBackup(nama);
      catatAudit({
        userId: penggunaSaatIni(req).id, aksi: 'ekspor', tabel: 'pengaturan',
        recordId: 'database', sesudah: { cadangan: nama },
      });
      res.download(p, nama);
    }),
  );

  r.post(
    '/sistem/pulihkan',
    wajibIzinTabInfo('database'),
    asyncHandler((req, res) => {
      const nama = String(req.body?.nama ?? '');
      const konfirmasi = String(req.body?.konfirmasi ?? '');
      if (konfirmasi !== 'PULIHKAN') {
        throw tolak(400, 'Konfirmasi salah. Ketik PULIHKAN untuk melanjutkan.');
      }
      const pengguna = penggunaSaatIni(req);
      pulihkanBackup(nama);
      catatAudit({
        userId: pengguna.id, aksi: 'ubah', tabel: 'pengaturan', recordId: 'database',
        sesudah: { dipulihkan_dari: nama },
        alasan: 'Pemulihan database dari cadangan',
      });
      res.json({ pesan: `Database dipulihkan dari ${nama}. Muat ulang aplikasi untuk melihat hasilnya.` });
    }),
  );

  r.get(
    '/sistem/pembaruan',
    wajibIzinTabInfo('tentang'),
    asyncHandler((_req, res) => {
      res.json(periksaPembaruan());
    }),
  );

  /* ==================== SISTEM: RESET DATA (ADMIN) ====================== */

  // Langkah 1 — ringkasan jumlah data yang akan dihapus per modul.
  r.get(
    '/sistem/reset/ringkasan',
    wajibIzinTabInfo('database'),
    wajibAdminUtama,
    asyncHandler((req, res) => {
      res.json(ringkasanReset(String(req.query.jenis ?? '') as JenisReset));
    }),
  );

  // Langkah 4 — eksekusi: kata "RESET" + kata sandi Admin, satu transaksi.
  r.post(
    '/sistem/reset',
    wajibIzinTabInfo('database'),
    wajibAdminUtama,
    asyncHandler((req, res) => {
      const jenis = String(req.body?.jenis ?? '') as JenisReset;
      if (!JENIS_RESET.some((j) => j.kode === jenis)) {
        throw tolak(400, 'Jenis reset tidak dikenal (transaksi / master / total).');
      }
      if (String(req.body?.konfirmasi ?? '') !== 'RESET') {
        throw tolak(400, 'Konfirmasi salah. Ketik kata RESET dengan huruf kapital untuk melanjutkan.');
      }
      if (!cocokKataSandi(String(req.body?.sandi ?? ''))) {
        throw tolak(401, 'Kata sandi Admin tidak cocok. Reset dibatalkan.');
      }
      const hasil = jalankanReset(jenis, penggunaSaatIni(req).id, peranDariHeader(req));
      res.json({
        pesan: `${hasil.label} selesai — ${hasil.total} baris data diproses. Cadangan pengaman ${hasil.cadangan_pengaman} dibuat sebelum reset.`,
        ...hasil,
      });
    }),
  );

  // Pulihkan dari Backup — unggah file cadangan (.db) yang pernah diunduh.
  // express.json global hanya memproses JSON; body biner diteruskan ke parser
  // raw di sini (batas 256 MB cukup untuk basis data berukuran besar).
  r.post(
    '/sistem/pulihkan/unggah',
    wajibIzinTabInfo('database'),
    wajibAdminUtama,
    express.raw({ type: () => true, limit: '256mb' }),
    asyncHandler((req, res) => {
      if (String(req.query.konfirmasi ?? '') !== 'PULIHKAN') {
        throw tolak(400, 'Konfirmasi salah. Ketik PULIHKAN untuk melanjutkan.');
      }
      const body = req.body as Buffer;
      if (!Buffer.isBuffer(body) || body.length === 0) throw tolak(400, 'File backup tidak diterima.');
      if (body.length < 16 || body.subarray(0, 15).toString('latin1') !== 'SQLite format 3') {
        throw tolak(400, 'Berkas bukan cadangan database SQLite yang valid.');
      }
      fs.mkdirSync(LOKASI_BACKUP, { recursive: true });
      const stempel = new Date().toISOString().replace(/[:.]/g, '-');
      let nama = `unggahan-${stempel}.db`;
      let urut = 1;
      while (fs.existsSync(path.join(LOKASI_BACKUP, nama))) nama = `unggahan-${stempel}-${urut++}.db`;
      const tujuan = path.join(LOKASI_BACKUP, nama);
      fs.writeFileSync(tujuan, body);
      try {
        pulihkanBackup(nama);
      } catch (e) {
        try {
          fs.unlinkSync(tujuan);
        } catch {
          /* berkas sudah tidak ada — abaikan */
        }
        throw e;
      }
      catatAudit({
        userId: penggunaSaatIni(req).id,
        aksi: 'pulihkan',
        tabel: 'pengaturan',
        recordId: 'database',
        sesudah: { dipulihkan_dari: nama, asal: 'unggahan' },
        alasan: 'Pemulihan database dari file backup hasil unduhan',
      });
      res.json({ nama, pesan: `Database dipulihkan dari ${nama}. Muat ulang aplikasi untuk melihat hasilnya.` });
    }),
  );

  /* ==================== SISTEM: IMPOR & EKSPOR ========================= */

  /**
   * Daftar modul impor beserta contoh kolomnya.
   *
   * Hanya modul yang benar-benar punya kemampuan impor yang menunjuk berkas
   * contoh. Pembelian dan Penjualan belum memiliki impor, jadi ditandai
   * `tersedia: false` dengan alasannya — bukan tautan mati. Opname kini punya
   * wizard Impor Excel (BAGIAN L) di layar Stok ▸ Opname.
   */
  r.get(
    '/impor/modul',
    wajibIzinTabInfo('impor-ekspor'),
    asyncHandler((_req, res) => {
      const entitas = Object.values(ENTITAS).map((e) => ({
        kode: e.kode,
        label: e.label,
        kolom: e.kolom.map((k) => ({ key: k.key, label: k.label })),
        template: `/api/master/${e.kode}/template`,
        tersedia: true,
        ket: null as string | null,
      }));

      // Modul dengan rute template sendiri (kolomnya lebih kaya dari entitas generik).
      const khusus: { kode: string; label: string; template: string; ket: string | null }[] = [
        { kode: 'produk', label: 'Produk', template: '/api/master/produk/template', ket: null },
        { kode: 'paket', label: 'Paket / Bundling', template: '/api/master/paket/template', ket: null },
        { kode: 'persediaan', label: 'Persediaan Sub (Item Masuk / Keluar)', template: '/api/persediaan/template', ket: null },
        { kode: 'opname', label: 'Opname', template: '/api/opname/template?isi=kosong', ket: 'Impor lewat wizard Stok ▸ Opname (ikon Impor Excel): pilih/buat sesi → unduh template → validasi → konfirmasi (Draft / Sahkan).' },
      ];

      // Modul yang belum mendukung impor — ditampilkan nonaktif dengan petunjuk.
      const belumAda: { kode: string; label: string; ket: string }[] = [
        { kode: 'pembelian', label: 'Pembelian', ket: 'Modul Pembelian belum memiliki impor massal. Masukkan dokumen lewat layar Pembelian (biasa, scan barcode, atau chatbot).' },
        { kode: 'penjualan', label: 'Penjualan', ket: 'Modul Penjualan belum memiliki impor massal. Transaksi dibuat lewat POS atau layar Penjualan.' },
      ];

      res.json({
        data: [
          ...entitas,
          ...khusus.map((k) => ({ ...k, kolom: [] as { key: string; label: string }[], tersedia: true })),
          ...belumAda.map((b) => ({ ...b, kolom: [] as { key: string; label: string }[], template: '', tersedia: false })),
        ],
      });
    }),
  );

  r.get(
    '/impor/riwayat',
    wajibIzinTabInfo('impor-ekspor'),
    asyncHandler((req, res) => {
      const limit = Math.min(200, Math.max(1, Number.parseInt(String(req.query.per ?? '50'), 10) || 50));
      const rows = all<{
        id: number; modul: string; nama_file: string; total_baris: number;
        baris_valid: number; baris_error: number; status: string; waktu: string; nama: string | null;
      }>(
        `SELECT b.*, u.nama FROM import_batches b LEFT JOIN users u ON u.id = b.user_id
          ORDER BY b.id DESC LIMIT ?`,
        limit,
      );
      res.json({ data: rows });
    }),
  );

  /* ==================== SISTEM: NOTIFIKASI & PESAN ===================== */

  r.post(
    '/notifikasi/tes',
    wajibIzinTabInfo('notifikasi'),
    asyncHandler((req, res) => {
      const kanal = String(req.body?.kanal ?? '');
      const s = getSettings();
      if (kanal === 'wa') {
        if (s['wa_kirim_otomatis'] !== 'true') {
          throw tolak(409, 'WhatsApp otomatis belum aktif — masih memerlukan WhatsApp Business API. Pengiriman harian memakai tautan wa.me yang dibuka kasir.');
        }
      } else if (kanal === 'email') {
        if (s['smtp_aktif'] !== 'true') throw tolak(409, 'Pengirim email (SMTP) belum aktif atau belum lengkap.');
        if (!s['smtp_host'] || !s['smtp_pengguna']) throw tolak(409, 'Isi host SMTP dan pengguna SMTP terlebih dahulu.');
      } else {
        throw tolak(400, 'Kanal tidak dikenal (wa / email).');
      }
      res.json({ pesan: 'Konfigurasi terlihat lengkap. Pengiriman tes dijalankan saat modul pengiriman aktif.' });
    }),
  );

  /* ======================== SISTEM: LOG AKTIVITAS ====================== */

  r.get(
    '/log/ekspor',
    wajibIzinTabInfo('log-aktivitas'),
    asyncHandler((req, res) => {
      const { baris } = bacaLogAktivitas(req, 2000);
      const kepala = ['waktu', 'oleh', 'aksi', 'tab', 'sebelum', 'sesudah'];
      const esc = (v: unknown): string => {
        const t = v === null || v === undefined ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v);
        return `"${t.replace(/"/g, '""')}"`;
      };
      const isi = baris.map((x) =>
        [x.waktu, x.oleh, x.aksi, x.tab, x.sebelum, x.sesudah].map(esc).join(','),
      );
      catatAudit({
        userId: penggunaSaatIni(req).id, aksi: 'ekspor', tabel: 'pengaturan',
        recordId: 'log-aktivitas', sesudah: { baris: baris.length },
      });
      // BOM UTF-8 agar Excel membuka huruf Indonesia dengan benar.
      const csv = `\uFEFF${[kepala.join(','), ...isi].join('\r\n')}\r\n`;
      res
        .set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="log-aktivitas.csv"' })
        .send(csv);
    }),
  );

  /* ==================== SISTEM: PENGGUNA & HAK AKSES =================== */

  r.get(
    '/pengguna/daftar',
    wajibIzinTabInfo('pengguna'),
    asyncHandler((_req, res) => {
      res.json({
        data: all(
          `SELECT u.id, u.nama, u.username, u.email, u.aktif, r.nama AS peran
             FROM users u LEFT JOIN roles r ON r.id = u.role_id ORDER BY u.nama`,
        ),
        peran: all('SELECT id, nama FROM roles ORDER BY nama'),
      });
    }),
  );

  r.get(
    '/pengguna/izin',
    wajibIzinTabInfo('pengguna'),
    asyncHandler((_req, res) => {
      const keluar: Record<string, string[]> = {};
      for (const t of TAB_PENGATURAN) {
        const mentah = get<{ nilai: string | null }>(
          'SELECT nilai FROM settings WHERE kunci = ?',
          `peng.akses.${t.kode}`,
        )?.nilai;
        if (!mentah) {
          keluar[t.kode] = [];
          continue;
        }
        try {
          const daftar = JSON.parse(mentah) as unknown;
          keluar[t.kode] = Array.isArray(daftar) ? daftar.map((x) => String(x)) : [];
        } catch {
          keluar[t.kode] = [];
        }
      }
      res.json(keluar);
    }),
  );

  /* ------------------ Keamanan: perangkat & sesi aktif ------------------ */

  r.get(
    '/keamanan/sesi',
    wajibIzinTabInfo('keamanan'),
    asyncHandler(async (_req, res) => {
      // Modul Log In belum dijalankan: tidak ada token sesi yang tersimpan,
      // jadi tidak ada perangkat yang bisa dikeluarkan. Dikembalikan kosong
      // (bukan galat) agar panel bisa menjelaskan keadaannya dengan jujur.
      const adaSesi = get<{ n: number }>(
        `SELECT COUNT(*) AS n FROM sqlite_master WHERE type = 'table' AND name = 'sessions'`,
      )?.n;
      if (adaSesi) {
        res.json({
          data: all(
            `SELECT perangkat AS perangkat, ip, terakhir_aktif AS terakhir FROM sessions ORDER BY terakhir_aktif DESC LIMIT 50`,
          ),
        });
        return;
      }
      res.json({ data: [] });
    }),
  );

  r.put(
    '/pengguna/akses/:tab',
    wajibIzinTabInfo('pengguna'),
    asyncHandler((req, res) => {
      const kode = String(req.params.tab);
      if (!TAB_PENGATURAN.some((t) => t.kode === kode)) throw tolak(404, `Tab "${kode}" tidak ditemukan.`);
      const body = (req.body ?? {}) as { peran?: unknown };
      if (!Array.isArray(body.peran)) throw tolak(400, 'Daftar peran tidak valid.');
      const dikenal = new Set(all<{ nama: string }>('SELECT nama FROM roles').map((r) => r.nama.toLowerCase()));
      const dipilih = body.peran.filter((x) => dikenal.has(String(x).toLowerCase())).map((x) => String(x));
      const kunci = `peng.akses.${kode}`;
      const sebelum = get<{ nilai: string | null }>('SELECT nilai FROM settings WHERE kunci = ?', kunci)?.nilai ?? '';
      run(
        `INSERT INTO settings (kunci, nilai, diubah_pada) VALUES (?, ?, strftime('%Y-%m-%d %H:%M:%f', 'now'))
         ON CONFLICT(kunci) DO UPDATE SET nilai = excluded.nilai, diubah_pada = excluded.diubah_pada`,
        kunci,
        JSON.stringify(dipilih),
      );
      catatAudit({
        userId: penggunaSaatIni(req).id, aksi: 'ubah', tabel: 'pengaturan', recordId: kunci,
        sebelum: { izin: sebelum }, sesudah: { izin: JSON.stringify(dipilih) },
      });
      res.json({ pesan: `Izin tab diperbarui untuk ${dipilih.length} peran.`, peran: dipilih });
    }),
  );

  return r;
}
