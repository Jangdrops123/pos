// ============================================================================
// API Pengguna & Hak Akses (Tahap 1 + Tahap 2)
//
//   GET    /daftar              daftar pengguna (status, login terakhir, …)
//   POST   /                    tambah pengguna
//   PUT    /:id                 ubah pengguna
//   POST   /:id/sandi           reset password oleh Admin (tampil sekali)
//   POST   /:id/status          aktifkan / nonaktifkan
//   POST   /:id/buka            buka kunci akun
//   DELETE /:id                 hapus pengguna
//   POST   /massal              aksi massal (aktifkan/nonaktifkan/hapus/buka)
//   GET    /peran               daftar peran + matriks + hak khusus + cakupan
//   POST   /peran               tambah peran baru (Admin)
//   PUT    /peran/:id           ubah nama peran (Admin)
//   DELETE /peran/:id           hapus peran — bila tidak dipakai pengguna (Admin)
//   PUT    /matriks/:roleId     simpan matriks + hak khusus + cakupan (Admin)
//
// Aturan:
//   * Kelola pengguna: Admin ATAU peran yang diizinkan tab Pengguna.
//   * Peran & matriks: hanya sesi Admin (override header x-peran tidak berlaku).
//   * Username unik tanpa membedakan huruf besar/kecil, spasi dipangkas.
//   * Akun Admin utama tidak bisa dihapus, dan tidak bisa dinonaktifkan oleh
//     dirinya sendiri; selalu ada minimal satu Admin aktif.
//   * Semua perubahan tercatat di Log Aktivitas (siapa, kapan, sebelum/sesudah)
//     tanpa pernah menyimpan nilai password.
// ============================================================================

import { Router, type Request, type RequestHandler } from 'express';
import { all, get, run, withTransaction } from '../db.ts';
import { catatAudit } from '../lib/audit.ts';
import {
  SEMUA_AKSI,
  daftarModul,
  konteksWajib,
  hashSandi,
  hapusSesiPengguna,
  sandiAcak,
  validasiSandiBaru,
  waktuSql,
} from '../lib/auth.ts';
import { asyncHandler, tolak } from '../lib/http.ts';
import { izinTab } from './pengaturan.ts';

/* ------------------------------ guard ---------------------------------- */

/** Boleh mengelola pengguna: Admin, atau peran yang diizinkan tab Pengguna. */
const wajibKelolaPengguna: RequestHandler = (req, res, next) => {
  const k = konteksWajib(req);
  if (k.admin || izinTab(req, 'pengguna')) {
    next();
    return;
  }
  res.status(403).json({
    ok: false,
    pesan: 'Pengelola pengguna hanya untuk Admin (atau peran yang diizinkan Admin pada tab Pengguna).',
  });
};

/** Hanya sesi Admin (tanpa override peran) yang boleh menyentuh peran/matriks. */
const wajibAdminMatriks: RequestHandler = (req, res, next) => {
  const k = konteksWajib(req);
  if (k.admin) {
    next();
    return;
  }
  res.status(403).json({ ok: false, pesan: 'Pengaturan peran & hak akses hanya untuk Admin.' });
};

/* ------------------------------ helpers -------------------------------- */

interface BarisPengguna {
  id: number;
  nama: string;
  username: string;
  email: string | null;
  wa: string | null;
  aktif: number;
  wajib_ganti: number;
  kunci_sampai: string | null;
  login_terakhir: string | null;
  peran_id: number;
  peran: string;
  cakupan_toko: string | null;
  cakupan_peran: string | null;
}

function parseJsonArray(s: string | null): string[] | null {
  if (!s) return null;
  try {
    const v = JSON.parse(s) as unknown;
    return Array.isArray(v) ? v.map((x) => String(x)) : null;
  } catch {
    return null;
  }
}

function irisan(a: string[] | null, b: string[] | null): string[] | null {
  if (a === null) return b;
  if (b === null) return a;
  return a.filter((x) => b.includes(x));
}

function statusPengguna(u: BarisPengguna): 'aktif' | 'nonaktif' | 'terkunci' {
  if (u.kunci_sampai && new Date(u.kunci_sampai.replace(' ', 'T') + 'Z').getTime() > Date.now()) return 'terkunci';
  return u.aktif === 1 ? 'aktif' : 'nonaktif';
}

function bacaPengguna(id: number): BarisPengguna {
  const u = get<BarisPengguna>(
    `SELECT u.id, u.nama, u.username, u.email, u.wa, u.aktif, u.wajib_ganti,
            u.kunci_sampai, u.login_terakhir, u.cakupan_toko,
            r.id AS peran_id, r.nama AS peran, r.cakupan_toko AS cakupan_peran
       FROM users u JOIN roles r ON r.id = u.role_id
      WHERE u.id = ?`,
    id,
  );
  if (!u) throw tolak(404, 'Pengguna tidak ditemukan.');
  return u;
}

const USERNAME_POLA = /^[A-Za-z0-9._@-]{2,64}$/;

function bacaInput(body: Record<string, unknown>, ops: { perluSandi: boolean; idUbah?: number }) {
  const nama = String(body.nama ?? '').trim();
  if (!nama) throw tolak(400, 'Nama wajib diisi.');
  if (nama.length > 120) throw tolak(400, 'Nama maksimal 120 karakter.');

  const username = String(body.username ?? '').trim().replace(/\s+/g, '');
  if (!USERNAME_POLA.test(username)) {
    throw tolak(400, 'Username 2–64 karakter, hanya huruf, angka, titik, underscore, tanda minus/@.');
  }
  const kembar = get<{ id: number }>(
    'SELECT id FROM users WHERE lower(trim(username)) = lower(?) AND id <> ?',
    username,
    ops.idUbah ?? -1,
  );
  if (kembar) throw tolak(409, `Username "${username}" sudah dipakai (tidak membedakan huruf besar/kecil).`);

  const email = String(body.email ?? '').trim();
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw tolak(400, 'Format email tidak valid.');
  const wa = String(body.wa ?? '').trim();
  if (wa && !/^[0-9+\-\s]{8,20}$/.test(wa)) throw tolak(400, 'No. WhatsApp tidak valid (8–20 digit).');

  const peranId = Number(body.peran_id);
  const role = get<{ id: number; nama: string }>('SELECT id, nama FROM roles WHERE id = ?', peranId);
  if (!role) throw tolak(400, 'Peran tidak ditemukan.');

  const cakupan = body.cakupan_toko === null || body.cakupan_toko === undefined || body.cakupan_toko === ''
    ? null
    : (Array.isArray(body.cakupan_toko) ? body.cakupan_toko.map((x) => String(x)) : [String(body.cakupan_toko)]);
  if (cakupan) {
    const ada = all<{ kode: string }>('SELECT kode FROM stores').map((s) => s.kode);
    const asing = cakupan.filter((c) => !ada.includes(c));
    if (asing.length) throw tolak(400, `Toko/gudang tidak dikenal: ${asing.join(', ')}.`);
  }

  const sandi = String(body.sandi ?? '');
  const wajibGanti = body.wajib_ganti === true || body.wajib_ganti === 'true' || body.wajib_ganti === 1;
  if (ops.perluSandi) {
    if (!sandi) throw tolak(400, 'Password awal wajib diisi.');
    const salah = validasiSandiBaru(sandi);
    if (salah) throw tolak(400, salah);
  } else if (sandi) {
    const salah = validasiSandiBaru(sandi);
    if (salah) throw tolak(400, salah);
  }

  return { nama, username, email: email || null, wa: wa || null, peranId: role.id, cakupan, sandi, wajibGanti };
}

/** Larangan protektif untuk akun Admin utama & diri sendiri. */
function larangHapus(req: Request, target: BarisPengguna): void {
  const k = konteksWajib(req);
  if (target.peran.toLowerCase() === 'administrator') {
    throw tolak(400, 'Akun Admin utama tidak bisa dihapus. Nonaktifkan akun lain sebagai gantinya.');
  }
  if (target.id === k.userId) throw tolak(400, 'Anda tidak bisa menghapus akun sendiri.');
}

function larangStatus(req: Request, target: BarisPengguna, aktif: boolean): void {
  const k = konteksWajib(req);
  const isAdminTarget = target.peran.toLowerCase() === 'administrator';
  if (isAdminTarget && !k.admin) throw tolak(403, 'Hanya Admin yang boleh mengubah status akun Admin.');
  if (!aktif) {
    if (target.id === k.userId) {
      throw tolak(
        400,
        isAdminTarget
          ? 'Akun Admin utama tidak bisa dinonaktifkan oleh dirinya sendiri.'
          : 'Anda tidak bisa menonaktifkan akun sendiri.',
      );
    }
    if (isAdminTarget) {
      const sisa =
        get<{ n: number }>(
          "SELECT COUNT(*) AS n FROM users u JOIN roles r ON r.id = u.role_id WHERE lower(r.nama) = 'administrator' AND u.aktif = 1 AND u.id <> ?",
          target.id,
        )?.n ?? 0;
      if (sisa === 0) throw tolak(400, 'Harus ada minimal satu akun Admin yang aktif.');
    }
  }
}

function hapusBarisPengguna(id: number): void {
  try {
    withTransaction(() => {
      // Audit tetap ada tapi kehilangan tautan ke baris pengguna yang dihapus
      // (ON DELETE tidak disediakan kolom user_id) — agar penghapusan tetap jalan.
      run('UPDATE audit_logs SET user_id = NULL WHERE user_id = ?', id);
      run('DELETE FROM users WHERE id = ?', id);
    });
  } catch (e) {
    const pesan = e instanceof Error ? e.message : String(e);
    if (/FOREIGN KEY/i.test(pesan)) {
      throw tolak(
        409,
        'Pengguna masih memiliki riwayat data (transaksi/dokumen). Gunakan aksi "Nonaktifkan" sebagai gantinya.',
      );
    }
    throw e;
  }
}

/* --------------------------- matriks & peran ---------------------------- */

function flatHak(roleId: number): Record<string, string> {
  const rows = all<{ menu: string; aksi: string }>('SELECT menu, aksi FROM role_permissions WHERE role_id = ?', roleId);
  const keluar: Record<string, string> = {};
  for (const m of daftarModul()) keluar[m] = '';
  for (const r of rows) keluar[r.menu] = keluar[r.menu] ? `${keluar[r.menu]},${r.aksi}` : r.aksi;
  return keluar;
}

interface BarisKhusus {
  lihat_hpp: number;
  ubah_harga_kasir: number;
  diskon_maks: number;
  hapus_transaksi: number;
  proses_tahunan: number;
}

function bacaKhusus(roleId: number, admin: boolean): BarisKhusus {
  const r = get<BarisKhusus>(
    'SELECT lihat_hpp, ubah_harga_kasir, diskon_maks, hapus_transaksi, proses_tahunan FROM role_hak_khusus WHERE role_id = ?',
    roleId,
  );
  if (r) return r;
  return admin
    ? { lihat_hpp: 1, ubah_harga_kasir: 1, diskon_maks: 100, hapus_transaksi: 1, proses_tahunan: 1 }
    : { lihat_hpp: 0, ubah_harga_kasir: 0, diskon_maks: 0, hapus_transaksi: 0, proses_tahunan: 0 };
}

function validasiHak(body: Record<string, unknown>): { menu: string; aksi: string }[] {
  const hak = body.hak;
  if (!hak || typeof hak !== 'object' || Array.isArray(hak)) throw tolak(400, 'Matriks hak akses tidak valid.');
  const modul = daftarModul();
  const aksiDiizinkan = SEMUA_AKSI as readonly string[];
  const keluar: { menu: string; aksi: string }[] = [];
  for (const [menu, daftar] of Object.entries(hak as Record<string, unknown>)) {
    if (!modul.includes(menu)) throw tolak(400, `Modul tidak dikenal: ${menu}.`);
    if (!Array.isArray(daftar)) throw tolak(400, `Isi matriks untuk ${menu} tidak valid.`);
    const unik = [...new Set(daftar.map((x) => String(x)))];
    for (const a of unik) {
      if (!aksiDiizinkan.includes(a)) throw tolak(400, `Aksi tidak dikenal: ${a}.`);
      keluar.push({ menu, aksi: a });
    }
  }
  return keluar;
}

/* ------------------------------- router -------------------------------- */

export function routerPengguna(): Router {
  const r = Router();

  /* ------------------------- DAFTAR PENGGUNA --------------------------- */

  r.get(
    '/daftar',
    wajibKelolaPengguna,
    asyncHandler((_req, res) => {
      const rows = all<BarisPengguna>(
        `SELECT u.id, u.nama, u.username, u.email, u.wa, u.aktif, u.wajib_ganti,
                u.kunci_sampai, u.login_terakhir, u.cakupan_toko,
                r.id AS peran_id, r.nama AS peran, r.cakupan_toko AS cakupan_peran,
                (SELECT COUNT(*) FROM sessions s WHERE s.user_id = u.id) AS jumlah_sesi
           FROM users u JOIN roles r ON r.id = u.role_id
          ORDER BY u.nama`,
      );
      res.json({
        data: rows.map((u) => ({
          id: u.id,
          nama: u.nama,
          username: u.username,
          email: u.email,
          wa: u.wa,
          peran_id: u.peran_id,
          peran: u.peran,
          cakupan_toko: parseJsonArray(u.cakupan_toko),
          cakupan_efektif: irisan(parseJsonArray(u.cakupan_toko), parseJsonArray(u.cakupan_peran)),
          status: statusPengguna(u),
          kunci_sampai: u.kunci_sampai,
          login_terakhir: u.login_terakhir,
          wajib_ganti: u.wajib_ganti === 1,
          admin_utama: u.peran.toLowerCase() === 'administrator' && u.username.toLowerCase() === 'admin',
          jumlah_sesi: Number((u as unknown as { jumlah_sesi: number }).jumlah_sesi) || 0,
        })),
        peran: all('SELECT id, nama FROM roles ORDER BY nama'),
        toko: all('SELECT kode, nama FROM stores ORDER BY nama'),
      });
    }),
  );

  /* ------------------------------ TAMBAH -------------------------------- */

  r.post(
    '/',
    wajibKelolaPengguna,
    asyncHandler((req, res) => {
      const k = konteksWajib(req);
      const b = bacaInput((req.body ?? {}) as Record<string, unknown>, { perluSandi: true });
      if (b.peranId && get<{ nama: string }>('SELECT nama FROM roles WHERE id = ?', b.peranId)?.nama.toLowerCase() === 'administrator' && !k.admin) {
        throw tolak(403, 'Hanya Admin yang boleh membuat akun Admin.');
      }
      const id = withTransaction(() => {
        const hasil = run(
          `INSERT INTO users (nama, username, email, wa, password_hash, role_id, cakupan_toko, wajib_ganti, sandi_diubah_pada)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          b.nama,
          b.username,
          b.email,
          b.wa,
          hashSandi(b.sandi),
          b.peranId,
          b.cakupan ? JSON.stringify(b.cakupan) : null,
          b.wajibGanti ? 1 : 0,
          waktuSql(),
        );
        const idBaru = Number(hasil.lastInsertRowid);
        catatAudit({
          userId: k.userId,
          aksi: 'tambah',
          tabel: 'users',
          recordId: idBaru,
          sesudah: {
            nama: b.nama,
            username: b.username,
            email: b.email,
            wa: b.wa,
            peran_id: b.peranId,
            cakupan_toko: b.cakupan,
            wajib_ganti: b.wajibGanti,
          },
          alasan: 'Tambah pengguna',
        });
        return idBaru;
      });
      res.status(201).json({ id, pesan: `Pengguna "${b.nama}" ditambahkan.` });
    }),
  );

  /* ------------------------------- UBAH --------------------------------- */

  r.put(
    '/:id',
    wajibKelolaPengguna,
    asyncHandler((req, res) => {
      const k = konteksWajib(req);
      const id = Number(req.params.id);
      const lama = bacaPengguna(id);
      if (lama.peran.toLowerCase() === 'administrator' && !k.admin) {
        throw tolak(403, 'Hanya Admin yang boleh mengubah akun Admin.');
      }
      const b = bacaInput((req.body ?? {}) as Record<string, unknown>, { perluSandi: false, idUbah: id });
      if (lama.peran.toLowerCase() === 'administrator' && b.peranId !== lama.peran_id) {
        throw tolak(400, 'Peran akun Admin utama tidak bisa diubah.');
      }
      const gantiPeran = b.peranId !== lama.peran_id;

      withTransaction(() => {
        run(
          `UPDATE users SET nama = ?, username = ?, email = ?, wa = ?, role_id = ?, cakupan_toko = ?,
                            wajib_ganti = ?, diubah_pada = ?
            WHERE id = ?`,
          b.nama,
          b.username,
          b.email,
          b.wa,
          b.peranId,
          b.cakupan ? JSON.stringify(b.cakupan) : null,
          b.wajibGanti ? 1 : 0,
          waktuSql(),
          id,
        );
        if (gantiPeran) hapusSesiPengguna(id);
        const sesudah: Record<string, unknown> = {
          nama: b.nama,
          username: b.username,
          email: b.email,
          wa: b.wa,
          peran_id: b.peranId,
          cakupan_toko: b.cakupan,
          wajib_ganti: b.wajibGanti,
        };
        if (b.sandi) sesudah.password_baru = '(diubah oleh Admin)';
        catatAudit({
          userId: k.userId,
          aksi: 'ubah',
          tabel: 'users',
          recordId: id,
          sebelum: {
            nama: lama.nama,
            username: lama.username,
            email: lama.email,
            wa: lama.wa,
            peran_id: lama.peran_id,
            cakupan_toko: parseJsonArray(lama.cakupan_toko),
            wajib_ganti: lama.wajib_ganti === 1,
          },
          sesudah,
          alasan: gantiPeran ? 'Ubah pengguna — peran diganti, seluruh sesi lama ditutup' : 'Ubah pengguna',
        });
        if (b.sandi) {
          run(
            'UPDATE users SET password_hash = ?, sandi_diubah_pada = ? WHERE id = ?',
            hashSandi(b.sandi),
            waktuSql(),
            id,
          );
          hapusSesiPengguna(id);
        }
      });
      res.json({ pesan: `Pengguna "${b.nama}" diperbarui.` });
    }),
  );

  /* --------------------- RESET PASSWORD OLEH ADMIN ---------------------- */

  r.post(
    '/:id/sandi',
    wajibKelolaPengguna,
    asyncHandler((req, res) => {
      const k = konteksWajib(req);
      const id = Number(req.params.id);
      const u = bacaPengguna(id);
      if (u.peran.toLowerCase() === 'administrator' && !k.admin) {
        throw tolak(403, 'Hanya Admin yang boleh mereset password akun Admin.');
      }
      const sandi = sandiAcak();
      withTransaction(() => {
        run(
          'UPDATE users SET password_hash = ?, wajib_ganti = 1, sandi_diubah_pada = ?, gagal = 0, kunci_sampai = NULL WHERE id = ?',
          hashSandi(sandi),
          waktuSql(),
          id,
        );
        hapusSesiPengguna(id);
        catatAudit({
          userId: k.userId,
          aksi: 'ubah',
          tabel: 'users',
          recordId: id,
          sebelum: { wajib_ganti: u.wajib_ganti === 1 },
          sesudah: { wajib_ganti: true },
          alasan: 'Reset password oleh Admin — password sementara acak, wajib ganti saat login berikutnya',
        });
      });
      res.json({
        sandi, // tampil SEKALI di layar admin; tidak pernah disimpan sebagai teks.
        pesan: `Password sementara untuk "${u.nama}" (catat sekarang — hanya tampil sekali). Akun ditandai wajib ganti password saat login berikutnya, dan semua sesi lama ikut dikeluarkan.`,
      });
    }),
  );

  /* ------------------------ AKTIF / NONAKTIF / BUKA -------------------- */

  r.post(
    '/:id/status',
    wajibKelolaPengguna,
    asyncHandler((req, res) => {
      const k = konteksWajib(req);
      const id = Number(req.params.id);
      const u = bacaPengguna(id);
      const aktif = (req.body as { aktif?: unknown })?.aktif === true || (req.body as { aktif?: unknown })?.aktif === 1 || (req.body as { aktif?: unknown })?.aktif === 'true';
      larangStatus(req, u, aktif);
      withTransaction(() => {
        run('UPDATE users SET aktif = ?, diubah_pada = ? WHERE id = ?', aktif ? 1 : 0, waktuSql(), id);
        if (!aktif) hapusSesiPengguna(id);
        catatAudit({
          userId: k.userId,
          aksi: aktif ? 'aktifkan' : 'nonaktifkan',
          tabel: 'users',
          recordId: id,
          sebelum: { aktif: u.aktif === 1 },
          sesudah: { aktif },
          alasan: aktif ? 'Aktifkan pengguna' : 'Nonaktifkan pengguna',
        });
      });
      res.json({ pesan: `Pengguna "${u.nama}" ${aktif ? 'diaktifkan' : 'dinonaktifkan'}${aktif ? '' : ' dan sesinya dikeluarkan'}.` });
    }),
  );

  r.post(
    '/:id/buka',
    wajibKelolaPengguna,
    asyncHandler((req, res) => {
      const k = konteksWajib(req);
      const id = Number(req.params.id);
      const u = bacaPengguna(id);
      withTransaction(() => {
        run('UPDATE users SET kunci_sampai = NULL, gagal = 0, diubah_pada = ? WHERE id = ?', waktuSql(), id);
        catatAudit({
          userId: k.userId,
          aksi: 'ubah',
          tabel: 'users',
          recordId: id,
          sebelum: { kunci_sampai: u.kunci_sampai },
          sesudah: { kunci_sampai: null },
          alasan: 'Buka kunci akun',
        });
      });
      res.json({ pesan: `Kunci akun "${u.nama}" dibuka — percobaan masuk dihitung ulang.` });
    }),
  );

  /* ------------------------------- HAPUS -------------------------------- */

  r.delete(
    '/:id',
    wajibKelolaPengguna,
    asyncHandler((req, res) => {
      const k = konteksWajib(req);
      const id = Number(req.params.id);
      const u = bacaPengguna(id);
      larangHapus(req, u);
      hapusBarisPengguna(id);
      catatAudit({
        userId: k.userId,
        aksi: 'hapus',
        tabel: 'users',
        recordId: id,
        sebelum: { nama: u.nama, username: u.username, peran: u.peran },
        alasan: 'Hapus pengguna',
      });
      res.json({ pesan: `Pengguna "${u.nama}" dihapus.` });
    }),
  );

  /* ---------------------------- AKSI MASSAL ----------------------------- */

  r.post(
    '/massal',
    wajibKelolaPengguna,
    asyncHandler((req, res) => {
      const k = konteksWajib(req);
      const b = (req.body ?? {}) as { aksi?: unknown; ids?: unknown };
      const aksi = String(b.aksi ?? '');
      const ids = Array.isArray(b.ids) ? b.ids.map((x) => Number(x)).filter((x) => Number.isFinite(x)) : [];
      if (!ids.length) throw tolak(400, 'Pilih minimal satu pengguna.');
      if (!['aktifkan', 'nonaktifkan', 'hapus', 'buka'].includes(aksi)) {
        throw tolak(400, 'Aksi massal tidak dikenal.');
      }

      const hasil: string[] = [];
      for (const id of ids) {
        const u = bacaPengguna(id);
        if (aksi === 'hapus') {
          larangHapus(req, u);
          hapusBarisPengguna(id);
          catatAudit({ userId: k.userId, aksi: 'hapus', tabel: 'users', recordId: id, sebelum: { nama: u.nama, username: u.username, peran: u.peran }, alasan: 'Hapus pengguna (massal)' });
          hasil.push(u.nama);
          continue;
        }
        if (aksi === 'buka') {
          run('UPDATE users SET kunci_sampai = NULL, gagal = 0 WHERE id = ?', id);
          catatAudit({ userId: k.userId, aksi: 'ubah', tabel: 'users', recordId: id, sebelum: { kunci_sampai: u.kunci_sampai }, sesudah: { kunci_sampai: null }, alasan: 'Buka kunci akun (massal)' });
          hasil.push(u.nama);
          continue;
        }
        const aktif = aksi === 'aktifkan';
        larangStatus(req, u, aktif);
        run('UPDATE users SET aktif = ? WHERE id = ?', aktif ? 1 : 0, id);
        if (!aktif) hapusSesiPengguna(id);
        catatAudit({ userId: k.userId, aksi: aktif ? 'aktifkan' : 'nonaktifkan', tabel: 'users', recordId: id, sebelum: { aktif: u.aktif === 1 }, sesudah: { aktif }, alasan: `${aktif ? 'Aktifkan' : 'Nonaktifkan'} pengguna (massal)` });
        hasil.push(u.nama);
      }
      res.json({ pesan: `${hasil.length} pengguna diproses (${aksi}).`, nama: hasil });
    }),
  );

  /* ------------------------------- PERAN -------------------------------- */

  r.get(
    '/peran',
    wajibKelolaPengguna,
    asyncHandler((_req, res) => {
      const roles = all<{ id: number; nama: string; bawaan: number; cakupan_toko: string | null }>(
        'SELECT id, nama, bawaan, cakupan_toko FROM roles ORDER BY bawaan DESC, nama',
      );
      res.json({
        data: roles.map((rl) => ({
          id: rl.id,
          nama: rl.nama,
          bawaan: rl.bawaan === 1,
          cakupan_toko: parseJsonArray(rl.cakupan_toko),
          jumlah_pengguna: get<{ n: number }>('SELECT COUNT(*) AS n FROM users WHERE role_id = ?', rl.id)?.n ?? 0,
          hak: flatHak(rl.id),
          khusus: bacaKhusus(rl.id, rl.nama.toLowerCase() === 'administrator'),
        })),
        modul: daftarModul(),
        aksi: SEMUA_AKSI,
        toko: all('SELECT kode, nama FROM stores ORDER BY nama'),
      });
    }),
  );

  r.post(
    '/peran',
    wajibAdminMatriks,
    asyncHandler((req, res) => {
      const k = konteksWajib(req);
      const nama = String((req.body as { nama?: unknown })?.nama ?? '').trim();
      if (!nama) throw tolak(400, 'Nama peran wajib diisi.');
      if (nama.length > 60) throw tolak(400, 'Nama peran maksimal 60 karakter.');
      const kembar = get<{ id: number }>('SELECT id FROM roles WHERE lower(nama) = lower(?)', nama);
      if (kembar) throw tolak(409, `Peran "${nama}" sudah ada.`);
      const id = Number(
        run('INSERT INTO roles (nama, bawaan) VALUES (?, 0)', nama).lastInsertRowid,
      );
      catatAudit({ userId: k.userId, aksi: 'tambah', tabel: 'roles', recordId: id, sesudah: { nama }, alasan: 'Tambah peran' });
      res.status(201).json({ id, pesan: `Peran "${nama}" ditambahkan. Hak aksesnya masih kosong — isi matriks lalu Simpan.` });
    }),
  );

  r.put(
    '/peran/:id',
    wajibAdminMatriks,
    asyncHandler((req, res) => {
      const k = konteksWajib(req);
      const id = Number(req.params.id);
      const lama = get<{ id: number; nama: string }>('SELECT id, nama FROM roles WHERE id = ?', id);
      if (!lama) throw tolak(404, 'Peran tidak ditemukan.');
      const nama = String((req.body as { nama?: unknown })?.nama ?? '').trim();
      if (!nama) throw tolak(400, 'Nama peran wajib diisi.');
      const kembar = get<{ id: number }>('SELECT id FROM roles WHERE lower(nama) = lower(?) AND id <> ?', nama, id);
      if (kembar) throw tolak(409, `Peran "${nama}" sudah ada.`);
      run('UPDATE roles SET nama = ? WHERE id = ?', nama, id);
      catatAudit({ userId: k.userId, aksi: 'ubah', tabel: 'roles', recordId: id, sebelum: { nama: lama.nama }, sesudah: { nama }, alasan: 'Ubah nama peran' });
      res.json({ pesan: `Peran menjadi "${nama}".` });
    }),
  );

  r.delete(
    '/peran/:id',
    wajibAdminMatriks,
    asyncHandler((req, res) => {
      const k = konteksWajib(req);
      const id = Number(req.params.id);
      const lama = get<{ id: number; nama: string; bawaan: number }>('SELECT id, nama, bawaan FROM roles WHERE id = ?', id);
      if (!lama) throw tolak(404, 'Peran tidak ditemukan.');
      const dipakai = get<{ n: number }>('SELECT COUNT(*) AS n FROM users WHERE role_id = ?', id)?.n ?? 0;
      if (dipakai > 0) throw tolak(409, `Peran "${lama.nama}" masih dipakai ${dipakai} pengguna — pindahkan mereka ke peran lain dulu.`);
      withTransaction(() => {
        run('DELETE FROM role_permissions WHERE role_id = ?', id);
        run('DELETE FROM role_hak_khusus WHERE role_id = ?', id);
        run('DELETE FROM roles WHERE id = ?', id);
      });
      catatAudit({ userId: k.userId, aksi: 'hapus', tabel: 'roles', recordId: id, sebelum: { nama: lama.nama }, alasan: 'Hapus peran' });
      res.json({ pesan: `Peran "${lama.nama}" dihapus.` });
    }),
  );

  /* ---------------------- MATRIKS + HAK KHUSUS + TOKO ------------------- */

  r.put(
    '/matriks/:roleId',
    wajibAdminMatriks,
    asyncHandler((req, res) => {
      const k = konteksWajib(req);
      const roleId = Number(req.params.roleId);
      const role = get<{ id: number; nama: string; cakupan_toko: string | null }>(
        'SELECT id, nama, cakupan_toko FROM roles WHERE id = ?',
        roleId,
      );
      if (!role) throw tolak(404, 'Peran tidak ditemukan.');

      const body = (req.body ?? {}) as Record<string, unknown>;
      const pasang = validasiHak(body);
      const khususIn = (body.khusus ?? {}) as Record<string, unknown>;
      const khususLama = bacaKhusus(roleId, false);
      const diskon = Number(khususIn.diskon_maks ?? khususLama.diskon_maks);
      if (!Number.isFinite(diskon) || diskon < 0 || diskon > 100) {
        throw tolak(400, 'Batas diskon harus antara 0–100%.');
      }
      const bool = (v: unknown, d: number): number => (typeof v === 'boolean' ? (v ? 1 : 0) : d);
      const khususBaru = {
        lihat_hpp: bool(khususIn.lihat_hpp, khususLama.lihat_hpp),
        ubah_harga_kasir: bool(khususIn.ubah_harga_kasir, khususLama.ubah_harga_kasir),
        diskon_maks: diskon,
        hapus_transaksi: bool(khususIn.hapus_transaksi, khususLama.hapus_transaksi),
        // Proses Tahunan: HANYA Admin — nilai peran non-Admin selalu dipaksa 0.
        proses_tahunan: role.nama.toLowerCase() === 'administrator' ? 1 : 0,
      };

      const cakupanIn = body.cakupan_toko;
      let cakupan: string[] | null = null;
      if (Array.isArray(cakupanIn) && cakupanIn.length > 0) {
        cakupan = cakupanIn.map((x) => String(x));
        const ada = all<{ kode: string }>('SELECT kode FROM stores').map((s) => s.kode);
        const asing = cakupan.filter((c) => !ada.includes(c));
        if (asing.length) throw tolak(400, `Toko/gudang tidak dikenal: ${asing.join(', ')}.`);
      } else if (cakupanIn !== null && cakupanIn !== undefined && cakupanIn !== '' && !Array.isArray(cakupanIn)) {
        throw tolak(400, 'Cakupan toko/gudang tidak valid.');
      }

      const sebelum: Record<string, unknown> = {
        ...flatHak(roleId),
        ...Object.fromEntries(Object.entries(khususLama).map(([kk, vv]) => [`khusus.${kk}`, vv])),
        cakupan_toko: role.cakupan_toko,
      };

      withTransaction(() => {
        run('DELETE FROM role_permissions WHERE role_id = ?', roleId);
        for (const p of pasang) {
          run('INSERT INTO role_permissions (role_id, menu, aksi) VALUES (?, ?, ?)', roleId, p.menu, p.aksi);
        }
        run(
          `INSERT INTO role_hak_khusus (role_id, lihat_hpp, ubah_harga_kasir, diskon_maks, hapus_transaksi, proses_tahunan)
           VALUES (?, ?, ?, ?, ?, ?)
           ON CONFLICT(role_id) DO UPDATE SET lihat_hpp = excluded.lihat_hpp,
             ubah_harga_kasir = excluded.ubah_harga_kasir, diskon_maks = excluded.diskon_maks,
             hapus_transaksi = excluded.hapus_transaksi, proses_tahunan = excluded.proses_tahunan`,
          roleId,
          khususBaru.lihat_hpp,
          khususBaru.ubah_harga_kasir,
          khususBaru.diskon_maks,
          khususBaru.hapus_transaksi,
          khususBaru.proses_tahunan,
        );
        run('UPDATE roles SET cakupan_toko = ? WHERE id = ?', cakupan ? JSON.stringify(cakupan) : null, roleId);
      });

      const sesudah: Record<string, unknown> = {
        ...flatHak(roleId),
        ...Object.fromEntries(Object.entries(khususBaru).map(([kk, vv]) => [`khusus.${kk}`, vv])),
        cakupan_toko: cakupan ? JSON.stringify(cakupan) : null,
      };
      catatAudit({
        userId: k.userId,
        aksi: 'ubah',
        tabel: 'role_permissions',
        recordId: roleId,
        sebelum,
        sesudah,
        alasan: `Simpan Hak Akses peran "${role.nama}" — langsung berlaku tanpa login ulang`,
      });

      res.json({
        pesan: `Hak akses peran "${role.nama}" disimpan — langsung berlaku untuk seluruh penggunanya.`,
        hak: flatHak(roleId),
        khusus: khususBaru,
        cakupan_toko: cakupan,
      });
    }),
  );

  return r;
}
