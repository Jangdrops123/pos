// ============================================================================
// Rute Log In (Tahap 1) + Lupa Password & Kode Pemulihan (Tahap 2)
//
//   POST /masuk          Log In (username/email + password, "Ingat saya")
//   POST /keluar         Keluar (hapus sesi + cookie)
//   GET  /sesi           Cek sesi aktif → identitas + matriks hak akses
//   POST /ganti-sandi    Ganti password sendiri (lama + baru + konfirmasi)
//   GET  /lupa/kanal     Apakah alur mandiri tersedia (email/WhatsApp aktif)
//   POST /lupa           Minta tautan reset (pesan selalu netral)
//   POST /kirim-ulang    Kirim ulang tautan reset
//   POST /reset          Pakai tautan reset → password baru
//   POST /pulihkan       Pakai Kode Pemulihan Admin (tanpa email/WhatsApp)
//   GET  /info           Info ringkas untuk halaman Log In
//
// Aturan keamanan:
//   * Password disimpan sebagai hash bcrypt — tidak pernah teks biasa.
//   * 5x salah → akun terkunci (durasi dari Pengaturan ▸ Keamanan).
//   * Reset: berlaku 30 menit, sekali pakai, maksimal 3x per jam per akun,
//     balasan selalu netral (tidak membocorkan keberadaan akun).
//   * Password berubah → seluruh sesi lama pengguna itu ikut keluar.
// ============================================================================

import crypto from 'node:crypto';
import { Router, type Request, type Response } from 'express';
import { all, get, getSettings, run } from '../db.ts';
import { catatAudit } from '../lib/audit.ts';
import {
  buatSesi,
  cocokSandi,
  konteksDariToken,
  hashSandi,
  hashToken,
  kebijakanSandi,
  hapusSesi,
  hapusSesiPengguna,
  ipDariReq,
  konteksWajib,
  lepasKuki,
  msDariSql,
  pasangKuki,
  perangkatDariUA,
  validasiSandiBaru,
  waktuSql,
} from '../lib/auth.ts';
import { asyncHandler, tolak } from '../lib/http.ts';

const NETRAL = 'Jika akun terdaftar, instruksi reset telah dikirim ke email/WhatsApp terdaftar.';

/** Hash dummy untuk menyamarkan waktu cek akun yang tidak dikenal. */
let hashDummy: string | null = null;

interface BarisPengguna {
  id: number;
  nama: string;
  username: string;
  email: string | null;
  wa: string | null;
  password_hash: string;
  aktif: number;
  wajib_ganti: number;
  gagal: number;
  kunci_sampai: string | null;
  role_nama: string;
}

const SELECT_PENGGUNA = `SELECT u.id, u.nama, u.username, u.email, u.wa, u.password_hash,
        u.aktif, u.wajib_ganti, u.gagal, u.kunci_sampai, r.nama AS role_nama
   FROM users u JOIN roles r ON r.id = u.role_id`;

function angkaSetting(kunci: string, bawaan: number): number {
  const v = Number(getSettings()[kunci]);
  return Number.isFinite(v) && v > 0 ? v : bawaan;
}

/** Payload sesi — dipakai /masuk dan /sesi sehingga bentuknya sama.
 *  Identitas memakai peran ASLI pemilik sesi (k.asli): header `x-peran`
 *  (simulasi peran / hak uji) tidak mengubah "siapa yang masuk" — saat
 *  ganti akun di peramban yang sama, nilai lokal klien tidak boleh
 *  mewarisi peran pengguna sebelumnya (salah halaman awal + salah x-peran). */
export function payloadSesi(k: import('../lib/auth.ts').Konteks): Record<string, unknown> {
  return {
    masuk: true,
    pengguna: {
      id: k.userId,
      nama: k.nama,
      username: k.username,
      peran: k.asli.peranKunci,
      peranNama: k.asli.roleNama,
      admin: k.asli.admin,
      adminUtama: k.adminUtama,
      wajibGanti: k.wajibGanti,
      email: k.email,
      wa: k.wa,
    },
    hak: k.asli.hak,
    khusus: k.asli.khusus,
    cakupanToko: k.asli.cakupanToko,
    sesiMenit: angkaSetting('sesi_menit', 480),
    // Id sesi ini — dipakai panel Keamanan menandai "Sesi ini" agar tidak
    // salah mengeluarkan diri sendiri.
    sesiId: k.sesiId,
  };
}

function cariPengguna(kunci: string): BarisPengguna | undefined {
  const k = kunci.trim().toLowerCase();
  return get<BarisPengguna>(
    `${SELECT_PENGGUNA}
      WHERE lower(trim(u.username)) = ? OR lower(trim(COALESCE(u.email, ''))) = ?
      LIMIT 1`,
    k,
    k,
  );
}

/* ---------------------------- lupa password ----------------------------- */

/** Batas 3x per jam PER identitas yang diketik (akun ada atau tidak). */
const riwayatLupa = new Map<string, number[]>();

function bolehMintaLupa(identitas: string): boolean {
  const kini = Date.now();
  const daftar = (riwayatLupa.get(identitas) ?? []).filter((t) => kini - t < 3_600_000);
  if (daftar.length >= 3) {
    riwayatLupa.set(identitas, daftar);
    return false;
  }
  daftar.push(kini);
  riwayatLupa.set(identitas, daftar);
  return true;
}

function kanalTersedia(): { email: boolean; wa: boolean } {
  const s = getSettings();
  return {
    email: s.smtp_aktif === 'true' && Boolean(s.smtp_host) && Boolean(s.smtp_pengguna),
    wa: s.wa_aktif === 'true' && Boolean(s.wa_nomor_pengirim),
  };
}

function maskEmail(e: string): string {
  const [user, domain] = e.split('@');
  if (!domain) return e;
  return `${user.slice(0, 1)}***@${domain}`;
}

function maskWa(w: string): string {
  const bersih = w.replace(/\D/g, '');
  if (bersih.length < 7) return w;
  return `${bersih.slice(0, 4)}****${bersih.slice(-3)}`;
}

function asalAplikasi(req: Request): string {
  const env = process.env.APP_ORIGIN;
  if (env) return env.replace(/\/$/, '');
  const origin = req.headers.origin;
  if (origin) return origin;
  const ref = req.headers.referer;
  if (ref) {
    try {
      return new URL(ref).origin;
    } catch {
      /* jatuh ke bawah */
    }
  }
  return `http://127.0.0.1:${process.env.API_PORT ?? 3001}`;
}

/**
 * Buat token reset (30 menit, sekali pakai) dan catat pesan keluar.
 * Tautan asli TIDAK disimpan — hanya hash SHA-256-nya; tautan utuh ada di
 * kotak keluar (Pengaturan ▸ Notifikasi) agar Admin meneruskannya pada
 * instalasi yang belum menyambungkan email/WhatsApp.
 */
function kirimTautanReset(req: Request, user: BarisPengguna): void {
  const kanal = kanalTersedia();
  const pilih =
    kanal.email && user.email
      ? { kanal: 'email' as const, tujuan: user.email }
      : kanal.wa && user.wa
        ? { kanal: 'wa' as const, tujuan: user.wa }
        : null;
  if (!pilih) return; // kanal tidak tersedia / kontak belum diisi — tetap netral

  run('DELETE FROM password_resets WHERE kedaluwarsa < ?', waktuSql());
  const token = crypto.randomBytes(24).toString('base64url');
  const tampil = pilih.kanal === 'email' ? maskEmail(pilih.tujuan) : maskWa(pilih.tujuan);
  run(
    `INSERT INTO password_resets (user_id, token_hash, kanal, tujuan, kedaluwarsa)
     VALUES (?, ?, ?, ?, ?)`,
    user.id,
    hashToken(token),
    pilih.kanal,
    tampil,
    waktuSql(new Date(Date.now() + 30 * 60_000)),
  );
  const tautan = `${asalAplikasi(req)}/reset-sandi?token=${encodeURIComponent(token)}`;
  const isi =
    `Halo ${user.nama},\n\n` +
    `Permintaan setel ulang password NusaSuite (username: ${user.username}).\n` +
    `Buka tautan ini untuk membuat password baru: ${tautan}\n` +
    `Tautan berlaku 30 menit dan hanya bisa dipakai sekali.\n` +
    `Bila Anda tidak meminta ini, abaikan pesan ini.`;
  run(
    `INSERT INTO pesan_keluar (jenis, tujuan, isi, status) VALUES ('reset_sandi', ?, ?, 'antre')`,
    tampil,
    isi,
  );
}

/** Pasang password baru, tutup semua sesi lama, catat audit. */
function terapkanPasswordBaru(user: BarisPengguna, sandi: string, alasan: string): number {
  const salah = validasiSandiBaru(sandi);
  if (salah) throw tolak(400, salah);
  run(
    'UPDATE users SET password_hash = ?, wajib_ganti = 0, sandi_diubah_pada = ?, gagal = 0, kunci_sampai = NULL WHERE id = ?',
    hashSandi(sandi),
    waktuSql(),
    user.id,
  );
  const sesiDitutup = hapusSesiPengguna(user.id);
  catatAudit({ userId: user.id, aksi: 'ubah', tabel: 'users', recordId: user.id, alasan });
  return sesiDitutup;
}

/* ------------------------------- router --------------------------------- */

export function routerAuth(): Router {
  const r = Router();

  /* ------------------------------ LOG IN -------------------------------- */

  r.post(
    '/masuk',
    asyncHandler((req, res) => {
      const b = (req.body ?? {}) as { username?: unknown; sandi?: unknown; ingat?: unknown };
      const identitas = String(b.username ?? '').trim();
      const sandi = String(b.sandi ?? '');
      if (!identitas || !sandi) throw tolak(400, 'Username/email dan password wajib diisi.');

      const maks = angkaSetting('masuk_coba_maks', 5);
      const kunciMenit = angkaSetting('masuk_terkunci_menit', 15);
      const u = cariPengguna(identitas);

      if (!u) {
        hashDummy ??= hashSandi(crypto.randomUUID());
        cocokSandi(sandi, hashDummy);
        catatAudit({
          userId: null,
          aksi: 'login',
          tabel: 'users',
          recordId: null,
          alasan: `gagal 1x — akun tidak dikenal (${identitas.slice(0, 60)})`,
        });
        throw tolak(401, 'Username/email atau password salah.');
      }

      const kini = Date.now();
      if (u.kunci_sampai && msDariSql(u.kunci_sampai) > kini) {
        const sisa = Math.max(1, Math.ceil((msDariSql(u.kunci_sampai) - kini) / 60_000));
        throw tolak(403, `Akun terkunci setelah ${maks} kali percobaan salah. Coba lagi dalam ${sisa} menit.`);
      }
      if (u.kunci_sampai) {
        // Masa kunci sudah lewat → hitung percobaan dimulai lagi.
        run('UPDATE users SET kunci_sampai = NULL, gagal = 0 WHERE id = ?', u.id);
        u.gagal = 0;
      }
      if (!u.aktif) throw tolak(403, 'Akun ini dinonaktifkan. Hubungi Admin untuk mengaktifkannya.');

      if (!cocokSandi(sandi, u.password_hash)) {
        const gagal = (Number(u.gagal) || 0) + 1;
        const terkunci = gagal >= maks;
        run(
          'UPDATE users SET gagal = ?, kunci_sampai = ? WHERE id = ?',
          terkunci ? 0 : gagal,
          terkunci ? waktuSql(new Date(Date.now() + kunciMenit * 60_000)) : null,
          u.id,
        );
        catatAudit({
          userId: u.id,
          aksi: 'login',
          tabel: 'users',
          recordId: u.id,
          alasan: terkunci ? `gagal ${gagal}x — akun terkunci ${kunciMenit} menit` : `gagal ${gagal}x`,
        });
        if (terkunci) {
          throw tolak(403, `Akun terkunci ${kunciMenit} menit karena ${maks} kali percobaan salah. Coba lagi nanti.`);
        }
        throw tolak(401, 'Username/email atau password salah.');
      }

      // Berhasil.
      run('UPDATE users SET gagal = 0, kunci_sampai = NULL, login_terakhir = ? WHERE id = ?', waktuSql(), u.id);
      const ingat = b.ingat === true || b.ingat === 'true' || b.ingat === 1;
      const sesi = buatSesi(u.id, {
        ingat,
        perangkat: perangkatDariUA(String(req.headers['user-agent'] ?? '')),
        ip: ipDariReq(req),
      });
      pasangKuki(res, sesi.token, ingat);
      catatAudit({ userId: u.id, aksi: 'login', tabel: 'users', recordId: u.id, alasan: 'berhasil' });

      const konteks = konteksDariToken(req, res, sesi.token);
      if (!konteks) throw tolak(500, 'Gagal menyiapkan sesi. Coba lagi.');
      res.json({ pesan: 'Berhasil masuk.', wajibGanti: u.wajib_ganti === 1, sesi: payloadSesi(konteks) });
    }),
  );

  /* ------------------------------ KELUAR -------------------------------- */

  r.post(
    '/keluar',
    asyncHandler((req, res) => {
      const k = konteksWajib(req);
      hapusSesi(k.token);
      lepasKuki(res);
      catatAudit({ userId: k.userId, aksi: 'logout', tabel: 'users', recordId: k.userId, alasan: 'keluar' });
      res.json({ pesan: 'Anda telah keluar.' });
    }),
  );

  /* ------------------------------- SESI --------------------------------- */

  r.get(
    '/sesi',
    asyncHandler((req, res) => {
      res.json(payloadSesi(konteksWajib(req)));
    }),
  );

  /* --------------------------- GANTI SANDI ------------------------------ */

  r.post(
    '/ganti-sandi',
    asyncHandler((req, res) => {
      const k = konteksWajib(req);
      const b = (req.body ?? {}) as { lama?: unknown; baru?: unknown; konfirmasi?: unknown };
      const lama = String(b.lama ?? '');
      const baru = String(b.baru ?? '');
      const konfirmasi = String(b.konfirmasi ?? '');

      const u = get<BarisPengguna>(`${SELECT_PENGGUNA} WHERE u.id = ?`, k.userId);
      if (!u) throw tolak(401, 'Sesi berakhir. Silakan masuk kembali.');
      if (!cocokSandi(lama, u.password_hash)) throw tolak(400, 'Password lama salah.');
      if (baru !== konfirmasi) throw tolak(400, 'Konfirmasi password baru tidak sama.');
      if (baru === lama) throw tolak(400, 'Password baru harus berbeda dari password lama.');
      const salah = validasiSandiBaru(baru);
      if (salah) throw tolak(400, salah);

      run(
        'UPDATE users SET password_hash = ?, wajib_ganti = 0, sandi_diubah_pada = ?, gagal = 0, kunci_sampai = NULL WHERE id = ?',
        hashSandi(baru),
        waktuSql(),
        u.id,
      );
      const sesiLain = hapusSesiPengguna(u.id, k.token);
      catatAudit({ userId: u.id, aksi: 'ubah', tabel: 'users', recordId: u.id, alasan: 'Ganti password sendiri' });
      res.json({
        pesan:
          sesiLain > 0
            ? `Password diperbarui. ${sesiLain} sesi lama di perangkat lain ikut dikeluarkan.`
            : 'Password diperbarui.',
      });
    }),
  );

  /* --------------------------- LUPA PASSWORD ---------------------------- */

  r.get(
    '/lupa/kanal',
    asyncHandler((_req, res) => {
      const k = kanalTersedia();
      res.json({ tersedia: k.email || k.wa, kanal: k.email ? 'email' : k.wa ? 'wa' : null });
    }),
  );

  const mintaReset = asyncHandler((req: Request, res: Response) => {
    const b = (req.body ?? {}) as { identitas?: unknown };
    const identitas = String(b.identitas ?? '').trim().toLowerCase();
    if (!identitas) throw tolak(400, 'Isi username atau email Anda.');
    if (!bolehMintaLupa(identitas)) {
      throw tolak(429, 'Terlalu banyak permintaan reset. Maksimal 3x per jam — coba lagi nanti.');
    }
    const u = cariPengguna(identitas);
    if (u && u.aktif) kirimTautanReset(req, u);
    // Balasan selalu netral — tidak menyebut apakah akun ada.
    res.json({ pesan: NETRAL });
  });

  r.post('/lupa', mintaReset);
  r.post('/kirim-ulang', mintaReset);

  r.post(
    '/reset',
    asyncHandler((req, res) => {
      const b = (req.body ?? {}) as { token?: unknown; baru?: unknown; konfirmasi?: unknown };
      const token = String(b.token ?? '');
      const baru = String(b.baru ?? '');
      const konfirmasi = String(b.konfirmasi ?? '');
      if (!token) throw tolak(400, 'Tautan reset tidak ditemukan. Minta tautan baru lewat "Lupa password?".');

      const row = get<{ id: number; user_id: number; kedaluwarsa: string; dipakai_pada: string | null }>(
        'SELECT id, user_id, kedaluwarsa, dipakai_pada FROM password_resets WHERE token_hash = ?',
        hashToken(token),
      );
      if (!row || row.dipakai_pada) {
        throw tolak(400, 'Tautan sudah pernah dipakai atau tidak dikenal. Minta tautan baru lewat "Lupa password?".');
      }
      if (msDariSql(row.kedaluwarsa) < Date.now()) {
        throw tolak(400, 'Tautan kedaluwarsa (berlaku 30 menit). Minta tautan baru lewat "Lupa password?".');
      }
      if (baru !== konfirmasi) throw tolak(400, 'Konfirmasi password baru tidak sama.');

      const u = get<BarisPengguna>(`${SELECT_PENGGUNA} WHERE u.id = ?`, row.user_id);
      if (!u) throw tolak(400, 'Akun pada tautan ini sudah tidak ada. Minta tautan baru.');

      run('UPDATE password_resets SET dipakai_pada = ? WHERE id = ?', waktuSql(), row.id);
      const sesiDitutup = terapkanPasswordBaru(u, baru, 'Setel ulang password lewat tautan lupa password');
      res.json({
        pesan: 'Password baru tersimpan. Silakan masuk dengan password baru.',
        sesiDitutup,
        username: u.username,
      });
    }),
  );

  /* ------------------------- KODE PEMULIHAN ----------------------------- */

  r.post(
    '/pulihkan',
    asyncHandler((req, res) => {
      const b = (req.body ?? {}) as { identitas?: unknown; kode?: unknown; baru?: unknown; konfirmasi?: unknown };
      const identitas = String(b.identitas ?? '').trim().toLowerCase();
      const kode = String(b.kode ?? '')
        .trim()
        .toUpperCase()
        .replace(/\s+/g, '');
      const baru = String(b.baru ?? '');
      const konfirmasi = String(b.konfirmasi ?? '');
      if (!identitas || !kode) throw tolak(400, 'Isi username dan Kode Pemulihan.');
      if (!bolehMintaLupa(`pulihkan:${identitas}`)) {
        throw tolak(429, 'Terlalu banyak percobaan. Maksimal 3x per jam — coba lagi nanti.');
      }

      // Kode Pemulihan hanya untuk akun Admin utama (username: admin).
      const u = cariPengguna(identitas);
      const pesanGagal = 'Kode Pemulihan tidak valid atau sudah dipakai.';
      if (!u || u.username.toLowerCase() !== 'admin') throw tolak(400, pesanGagal);

      const kodeRow = get<{ id: number }>(
        'SELECT id FROM recovery_codes WHERE user_id = ? AND kode_hash = ? AND dipakai_pada IS NULL',
        u.id,
        hashToken(kode),
      );
      if (!kodeRow) throw tolak(400, pesanGagal);
      if (baru !== konfirmasi) throw tolak(400, 'Konfirmasi password baru tidak sama.');

      run('UPDATE recovery_codes SET dipakai_pada = ? WHERE id = ?', waktuSql(), kodeRow.id);
      const sesiDitutup = terapkanPasswordBaru(u, baru, 'Setel ulang password memakai Kode Pemulihan');
      res.json({
        pesan: 'Password baru tersimpan. Silakan masuk dengan password baru.',
        sesiDitutup,
        username: u.username,
      });
    }),
  );

  /* ---------------- info singkat untuk halaman Log In ------------------- */

  r.get(
    '/info',
    asyncHandler((_req, res) => {
      const s = getSettings();
      const k = kanalTersedia();
      res.json({
        aplikasi: s['app_nama'] || 'NusaSuite',
        tagline: s['app_tagline'] ?? 'POS · WMS · Akuntansi',
        lupaTersedia: k.email || k.wa,
        kebijakan: kebijakanSandi(),
        kodePemulihan:
          all<{ n: number }>('SELECT COUNT(*) AS n FROM recovery_codes WHERE dipakai_pada IS NULL')[0]?.n ?? 0,
      });
    }),
  );

  return r;
}
